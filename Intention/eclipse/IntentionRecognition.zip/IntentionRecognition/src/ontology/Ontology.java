/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/

/**
 * \file      Ontology.java
 * \author    Anthony Pietromartire \a pietromartire.anthony\@nist.gov
 * \version   1.0
 * \date      29 June 2012
 * \brief     Class for the ontology.
 *
 * \details   This class is used to manipulate the ontology and extract the data in it.  
 */

/**
 * \class 	Ontology.Ontology
 * \brief     Class for the ontology.
 * \details   This class is used to manipulate the ontology and extract the data in it.  
 */

package ontology;



import java.io.File;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

import javax.swing.JOptionPane;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.io.OWLFunctionalSyntaxOntologyFormat;
import org.semanticweb.owlapi.model.AddAxiom;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.model.OWLOntologyStorageException;
import org.semanticweb.owlapi.model.OWLSubClassOfAxiom;
import org.semanticweb.owlapi.model.PrefixManager;
import org.semanticweb.owlapi.model.RemoveAxiom;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.util.DefaultPrefixManager;
import org.semanticweb.owlapi.util.OWLOntologyMerger;
import org.semanticweb.owlapi.vocab.OWL2Datatype;
import org.semanticweb.owlapi.reasoner.*;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Ontology {
	/**
	 * \brief Separator between URL and the class' name in the ontology.
	 */
	private static final char SEPARATOR = '#';
	/**
	 * \brief Path of the ontology.
	 */
	private String path;
	/**
	 * \brief Where we are going to save the file.
	 */
	private String pathSave;
	/**
	 * \brief Our ontology.
	 */
	private OWLOntology ontology;
	/**
	 * \brief Instance of DataProperty.
	 */
	private DataProperty dp;
	/**
	 * \brief Instance of ObjectProperty.
	 */
	private ObjectProperty op;

	/**
	 * \brief Ontology Manager - Used to load the ontology.
	 */
	private OWLOntologyManager manager;


	private String ontology_IRI;
	/**
	 * \brief Constructor \details Constructor of the Ontology class. \param p
	 * Path of the ontology. \param p2 Path where we are going to save the sql
	 * files.
	 */
	public Ontology(String path_) {
		path = path_;
		ontology_IRI= "http://www.semanticweb.org/ontologies/2012/9/Ontology1349984097026.owl";
		ontology = null;
		manager = OWLManager.createOWLOntologyManager();
		try {
			loadOntologyFromPath(path_);
		} catch (OWLOntologyCreationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



	/**
	 * \brief Load the ontology from a file.
	 */
	public void loadFromFile() {
		File file = new File(this.path);
		try {
			// this.ontology = manager.loadOntologyFromOntologyDocument(file);
			// begin merge
			manager.loadOntologyFromOntologyDocument(file).getImports();
			OWLOntologyMerger merger = new OWLOntologyMerger(manager);
			ontology = merger.createMergedOntology(manager, null);
			// end merge
			System.out.println("Loaded ontology: " + this.ontology);

		} catch (OWLOntologyCreationException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, e.getStackTrace());

		}
	}

	/**
	 * \brief Give the owl IRI for the value of a data property. \param unit
	 * unit of the value. \return IRI of the unit.
	 */
	public OWLDatatype getDataPropertyType(String unit) {
		OWLDataFactory df = manager.getOWLDataFactory();
		unit = unit.toLowerCase();
		if (unit.equals("short"))
			return df.getOWLDatatype(OWL2Datatype.XSD_SHORT.getIRI());
		if (unit.equals("unsignedshort"))
			return df.getOWLDatatype(OWL2Datatype.XSD_UNSIGNED_SHORT.getIRI());
		if (unit.equals("integer"))
			return df.getOWLDatatype(OWL2Datatype.XSD_INTEGER.getIRI());
		if (unit.equals("positiveinteger"))
			return df
					.getOWLDatatype(OWL2Datatype.XSD_POSITIVE_INTEGER.getIRI());
		if (unit.equals("negativeinteger"))
			return df
					.getOWLDatatype(OWL2Datatype.XSD_NEGATIVE_INTEGER.getIRI());
		if (unit.equals("nonpositiveinteger"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NON_POSITIVE_INTEGER
					.getIRI());
		if (unit.equals("nonnegativeinteger"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NON_NEGATIVE_INTEGER
					.getIRI());
		if (unit.equals("int"))
			return df.getOWLDatatype(OWL2Datatype.XSD_INT.getIRI());
		if (unit.equals("unsignedint"))
			return df.getOWLDatatype(OWL2Datatype.XSD_UNSIGNED_INT.getIRI());
		if (unit.equals("long"))
			return df.getOWLDatatype(OWL2Datatype.XSD_LONG.getIRI());
		if (unit.equals("unsignedlong"))
			return df.getOWLDatatype(OWL2Datatype.XSD_UNSIGNED_LONG.getIRI());
		if (unit.equals("decimal"))
			return df.getOWLDatatype(OWL2Datatype.XSD_DECIMAL.getIRI());
		if (unit.equals("float"))
			return df.getOWLDatatype(OWL2Datatype.XSD_FLOAT.getIRI());
		if (unit.equals("double"))
			return df.getOWLDatatype(OWL2Datatype.XSD_DOUBLE.getIRI());
		if (unit.equals("string"))
			return df.getOWLDatatype(OWL2Datatype.XSD_STRING.getIRI());
		if (unit.equals("normalizedstring"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NORMALIZED_STRING
					.getIRI());
		if (unit.equals("nmtoken"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NMTOKEN.getIRI());
		if (unit.equals("token"))
			return df.getOWLDatatype(OWL2Datatype.XSD_TOKEN.getIRI());
		if (unit.equals("language"))
			return df.getOWLDatatype(OWL2Datatype.XSD_LANGUAGE.getIRI());
		if (unit.equals("name"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NAME.getIRI());
		if (unit.equals("ncname"))
			return df.getOWLDatatype(OWL2Datatype.XSD_NCNAME.getIRI());
		if (unit.equals("datetime"))
			return df.getOWLDatatype(OWL2Datatype.XSD_DATE_TIME.getIRI());
		if (unit.equals("boolean"))
			return df.getOWLDatatype(OWL2Datatype.XSD_BOOLEAN.getIRI());
		if (unit.equals("hexbinary"))
			return df.getOWLDatatype(OWL2Datatype.XSD_HEX_BINARY.getIRI());
		if (unit.equals("anyuri"))
			return df.getOWLDatatype(OWL2Datatype.XSD_ANY_URI.getIRI());
		else
			return df.getOWLDatatype(OWL2Datatype.XSD_STRING.getIRI());
	}


	/**
	 * \brief Simple getter. \return SEPARATOR
	 */
	public static char getSeparator() {
		return SEPARATOR;
	}

	/**
	 * \brief Simple getter. \return path
	 */
	public String getPath() {
		return path;
	}

	/**
	 * \brief Simple setter. \param path
	 */
	public void setPath(String path) {
		this.path = path;
	}

	/**
	 * \brief Simple getter. \return ontology
	 */
	public OWLOntology getOntology() {
		return ontology;
	}

	/**
	 * \brief Simple setter. \param ontology
	 */
	public void setOntology(OWLOntology ontology) {
		this.ontology = ontology;
	}

	/**
	 * \brief Simple getter. \return manager
	 */
	public OWLOntologyManager getManager() {
		return manager;
	}

	/**
	 * \brief Simple setter. \param manager
	 */
	public void setManager(OWLOntologyManager manager) {
		this.manager = manager;
	}



	/**
	 * \brief Simple getter. \return dp
	 */
	public DataProperty getDp() {
		return dp;
	}

	/**
	 * \brief Simple setter. \param dp
	 */
	public void setDp(DataProperty dp) {
		this.dp = dp;
	}

	/**
	 * \brief Simple getter. \return op
	 */
	public ObjectProperty getOp() {
		return op;
	}

	/**
	 * \brief Simple setter. \param op
	 */
	public void setOp(ObjectProperty op) {
		this.op = op;
	}

	/**
	 * \brief Delete the url before the name of the entity.
	 * \param entity_ Entity to be simplified
	 * \return The name of the entity without the IRI
	 */
	public String cleanIRI(Object entity_) {
		String new_entity = entity_.toString().substring(
				entity_.toString().indexOf(SEPARATOR) + 1,
				entity_.toString().length() - 1);

		return new_entity;
	}

	public void getPropertyValues(OWLNamedIndividual ind, OWLReasoner reasoner){
		OWLDataFactory fac = manager.getOWLDataFactory();
		OWLObjectProperty hasOrderingConstruct = fac.getOWLObjectProperty(IRI
				.create(ontology_IRI+"#hasOrderingConstruct"));

		// Now ask the reasoner for the has_pet property values for Mick
		NodeSet<OWLNamedIndividual> petValuesNodeSet = reasoner
				.getObjectPropertyValues(ind, hasOrderingConstruct);
		Set<OWLNamedIndividual> values = petValuesNodeSet.getFlattened();
		System.out.println("The has_pet property values for Mick are: ");
		for (OWLNamedIndividual indiv : values) {
			System.out.println("    " + indiv);
		}
	}

	public void getIndividuals(OWLClass owlclass,OWLReasoner reasoner){

		NodeSet<OWLNamedIndividual> individualsNodeSet = reasoner.getInstances(owlclass, true);
		// The reasoner returns a NodeSet again. This time the NodeSet contains
		// individuals. Again, we just want the individuals, so get a flattened
		// set.
		Set<OWLNamedIndividual> individuals = individualsNodeSet.getFlattened();
		String cleanedclass = cleanIRI(owlclass);
		System.out.println("Instances of "+ cleanedclass + ":");
		for (OWLNamedIndividual ind : individuals) {
			System.out.println("    " + cleanIRI(ind));
			getPropertyValues(ind, reasoner);
		}
		System.out.println("\n");
	}

	public void loadOntologyFromPath(String path) throws OWLOntologyCreationException{
		OWLDataFactory factory = manager.getOWLDataFactory();
		File file = new File(path);
		ontology = manager.loadOntologyFromOntologyDocument(file);
		System.out.println("Loaded ontology: " + ontology);
		OWLClass intentionClass = factory.getOWLClass(IRI.create(ontology_IRI.concat("#Intention")));

		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(progressMonitor);
		OWLReasoner reasoner = reasonerFactory.createReasoner(ontology, config);
		reasoner.precomputeInferences();
		boolean consistent = reasoner.isConsistent();
		System.out.println("Consistent: " + consistent);
		System.out.println("\n");


		NodeSet<OWLClass> subClses = reasoner.getSubClasses(intentionClass, true);
		Set<OWLClass> clses = subClses.getFlattened();
		System.out.println("Subclasses of Intention: ");
		for (OWLClass cls : clses) {
			System.out.println("    " + cleanIRI(cls));
			if (cleanIRI(cls).equalsIgnoreCase("Kitting")){
				getIndividuals(cls, reasoner);
			}
		}
		System.out.println("\n");
	}


}
