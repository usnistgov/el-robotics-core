package orderingconstruct;

public class OrderingConstruct {

	public OrderingConstruct() {
		// TODO Auto-generated constructor stub
	}

}
