package staterelation;

public class OnTopWithContactStateRelation {
	
	public OnTopWithContactStateRelation() {
	}
	
	private String sr_name;
	
	public void setName(final String name){
		this.sr_name = name;
	}

}