package staterelation;

public class PartiallyInStateRelation {
	public PartiallyInStateRelation() {
	}
	
	private String sr_name;
	
	public void setName(final String name){
		this.sr_name = name;
	}
}