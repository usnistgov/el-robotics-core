/*****************************************************************************
  DISCLAIMER:
  This software was produced by the National Institute of Standards
  and Technology (NIST), an agency of the U.S. government, and by statute is
  not subject to copyright in the United States.  Recipients of this software
  assume all responsibility associated with its operation, modification,
  maintenance, and subsequent redistribution.

  See NIST Administration Manual 4.09.07 b and Appendix I.
*****************************************************************************/
#include "CanonicalRobotCommand.h"
#include "Tools.h"
#include <iostream>
#include <algorithm>

/*!
@brief Auto-generated constructor stub
*/
CanonicalRobotCommand::CanonicalRobotCommand() {
	safe_z = -0.25;
	dwell = 0.05;
	gripper_status = "close";
}
/*!
@brief Auto-generated destructor stub
*/
CanonicalRobotCommand::~CanonicalRobotCommand() {
}

/*!
@brief Given the name of the part, this function returns the pose (@a Point), the Z axis (@a Vector), and the X axis (@a Vector) of the part
@param partName Name of the part

-# Query the table @a SolidObject to retrieve the name of the pose for the part (@a hasSolidObject_PrimaryLocation)
-# Query the table @a PoseLocation to retrieve the name of the point for the part (@a hasPoseLocation_Point)
	- Query the table @a Point to retrieve the coordinates of the part
-# Query the table @a PoseLocation to retrieve the name of the x axis for the part @a hasPoseLocation_XAxis)
	- Query the table @a Vector to retrieve the vector for the x axis
-# Query the table @a PoseLocation to retrieve the name of the z axis for the part @a hasPoseLocation_ZAxis)
	- Query the table @a Vector to retrieve the vector for the z axis
*/
string CanonicalRobotCommand::getKitDesignForKit(string kitName){
	Kit *kit = new Kit(kitName);
	kit->get(kitName);

	string kit_design_name = kit->gethasKit_DesignRef();
	return kit_design_name;
}

/*!
@brief Given the name of the robot, this function returns the PoseLocation of the robot
@param robotName Name of the robot
@return The PoseLocation of the robot from the MySQL Database
*/
Point* CanonicalRobotCommand::getRobotPoseLocation(string robotName){

	//cout << "Robot Name: " << robotName;

	Robot *r = new Robot(robotName);
	r->get(robotName);

	PoseLocation * pLr1 = new PoseLocation(r->gethasSolidObject_PrimaryLocation()->getname());
	pLr1->get(pLr1->getname());
	Vector * xRt1  = pLr1->gethasPoseLocation_XAxis();
	xRt1->get(xRt1->getname());
	Vector * zRt1  = pLr1->gethasPoseLocation_ZAxis();
	zRt1->get(zRt1->getname());
	Point * pR1 = pLr1->gethasPoseLocation_Point();
	pR1->get(pR1->getname());
	//cout<<pR1->getPointID()<<endl;

	double xR1 = pR1->gethasPoint_X();
	double yR1 = pR1->gethasPoint_Y();
	double zR1 = pR1->gethasPoint_Z();

	//cout << "Robot Position: " <<xR1 << ","<< yR1 << ","<< zR1 << endl;
	return pR1;
}

/*!
@brief Given the name of the part, this function returns the pose (@a Point), the Z axis (@a Vector), and the X axis (@a Vector) of the part
@param partName Name of the part

-# Query the table @a SolidObject to retrieve the name of the pose for the part (@a hasSolidObject_PrimaryLocation)
-# Query the table @a PoseLocation to retrieve the name of the point for the part (@a hasPoseLocation_Point)
	- Query the table @a Point to retrieve the coordinates of the part
-# Query the table @a PoseLocation to retrieve the name of the x axis for the part @a hasPoseLocation_XAxis)
	- Query the table @a Vector to retrieve the vector for the x axis
-# Query the table @a PoseLocation to retrieve the name of the z axis for the part @a hasPoseLocation_ZAxis)
	- Query the table @a Vector to retrieve the vector for the z axis
*/
void CanonicalRobotCommand::getPartLocation(string partName){
	Part *part = new Part(partName);
	part->get(partName);

	//--Retrieve hasSolidObject_PrimaryLocation
	PoseLocation * part_loc = new PoseLocation(part->gethasSolidObject_PrimaryLocation()->getname());
	part_loc->get(part_loc->getname());

	//--Retrieve hasPoseLocation_Point
	Point * part_point = part_loc->gethasPoseLocation_Point();

	//--Retrieve hasPoseLocation_XAxis
	Vector * part_x_axis  = part_loc->gethasPoseLocation_XAxis();

	//--Retrieve hasPoseLocation_ZAxis
	Vector * part_z_axis  = part_loc->gethasPoseLocation_ZAxis();

	MoveToTakePart(part_point, part_z_axis, part_x_axis);
}

void CanonicalRobotCommand::MoveToTakePart(Point* point, Vector* z_axis, Vector* x_axis){
	point->get(point->getname());
	double part_point_x = point->gethasPoint_X();
	double part_point_y = point->gethasPoint_Y();
	double part_point_z = point->gethasPoint_Z();

	z_axis->get(z_axis->getname());
	double part_z_axis_x = z_axis->gethasVector_I();
	double part_z_axis_y = z_axis->gethasVector_J();
	double part_z_axis_z = z_axis->gethasVector_K();

	x_axis->get(x_axis->getname());
	double part_x_axis_x = x_axis->gethasVector_I();
	double part_x_axis_y = x_axis->gethasVector_J();
	double part_x_axis_z = x_axis->gethasVector_K();

	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<safe_z<<"}, "
				"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
				"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;

	cout << "Dwell ("<< dwell <<")" << endl;

	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<part_point_z<<"}, "
			"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
			"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;

	cout << "CloseGripper ()" << endl;

	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<safe_z<<"}, "
			"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
			"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;

	cout << "Dwell ("<< dwell <<")" << endl;
}

void CanonicalRobotCommand::MoveToPutPart(Point* point, Vector* z_axis, Vector* x_axis){
	point->get(point->getname());
	double part_point_x = point->gethasPoint_X();
	double part_point_y = point->gethasPoint_Y();
	double part_point_z = point->gethasPoint_Z();

	z_axis->get(z_axis->getname());
	double part_z_axis_x = z_axis->gethasVector_I();
	double part_z_axis_y = z_axis->gethasVector_J();
	double part_z_axis_z = z_axis->gethasVector_K();

	x_axis->get(x_axis->getname());
	double part_x_axis_x = x_axis->gethasVector_I();
	double part_x_axis_y = x_axis->gethasVector_J();
	double part_x_axis_z = x_axis->gethasVector_K();


	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<safe_z<<"}, "
				"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
				"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;

	cout << "Dwell ("<< dwell <<")" << endl;

	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<part_point_z<<"}, "
			"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
			"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;

	cout << "Dwell ("<< dwell <<")" << endl;

	cout << "OpenGripper()" << endl;

	cout << "MoveTo({{"<<part_point_x<<", "<<part_point_y<<", "<<safe_z<<"}, "
			"{"<< part_z_axis_x <<", " << part_z_axis_y << ", " << part_z_axis_z <<"}, "
			"{"<< part_x_axis_x <<", " << part_x_axis_y << ", " << part_x_axis_z <<"}})" << endl;
}

void CanonicalRobotCommand::take_kit_tray(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"take kit tray\")"<< endl;
}

void CanonicalRobotCommand::put_kit_tray(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"put kit tray\")"<< endl;
}

void CanonicalRobotCommand::take_kit(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"take kit\")"<< endl;
}

void CanonicalRobotCommand::put_kit(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"put kit\")"<< endl;
}

/*!
@brief Create the canonical robot commands for the action @a take-part
@param paramList List of parameters for the action @a take-part
*/
void CanonicalRobotCommand::take_part(vector<string> paramList, KittingPlan *kittingplan){
	FileOperator *fileop = new FileOperator;
	int listLength;
	listLength=(int)paramList.size();

	for (vector<string>::size_type i = 0; i < listLength; i++){
		string type;
		type=kittingplan->matchParamType(paramList[i]);
		fileop->stripSpace(type);

		if (!strcmp(type.c_str(),"Part")){
			cout <<"Message (\"take part " << paramList[i] <<"\")"<< endl;

			getPartLocation(paramList[i]);

		}
	}
}

void CanonicalRobotCommand::put_part(vector<string> paramList, KittingPlan *kittingplan){
	FileOperator *fileop = new FileOperator;
	int listLength;
	listLength=(int)paramList.size();
	vector <PartRefAndPose*> part_ref_pose_list;
	string erase_part_name;

	for (vector<string>::size_type i = 0; i < listLength; i++){
		string type;
		type=kittingplan->matchParamType(paramList[i]);
		fileop->stripSpace(type);

		if (!strcmp(type.c_str(),"Part"))
		{
			Part* part = new Part (paramList[i]);
			part->get(paramList[i]);

			cout <<"Message (\"put part " << paramList[i] <<"\")"<< endl;
			string param = paramList[i];
			erase_part_name = param.erase (0,5);

			for (vector<string>::size_type j = 0; j < listLength; j++){
				 string type2;
				type2=kittingplan->matchParamType(paramList[j]);
				fileop->stripSpace(type2);


				if (!strcmp(type2.c_str(),"Kit"))
				{
					Kit* kit = new Kit (paramList[j]);
					kit->get(paramList[j]);
					//cout << "kit_ID: " << kit->getKitID() << endl;
					//cout << "kit_name: " << kit->getname() << endl;
					string kit_desing_name = kit->gethasKit_DesignRef();
					//cout << "kit_design_name: " << kit_desing_name << endl;

					KitDesign *kit_design = new KitDesign(kit_desing_name);
					kit_design->get(kit_desing_name);
					part_ref_pose_list = kit_design->gethadByPartRefAndPose_KitDesign();
				}
			}

			for (int i = 0; i < part_ref_pose_list.size(); i++){
				PartRefAndPose* part_ref_pose_tmp = part_ref_pose_list.at(i);
				string part_ref_pose_part;
				part_ref_pose_part = part_ref_pose_tmp->getname();
				//cout << number->getname() << endl;
				if (std::string::npos != part_ref_pose_part.find(erase_part_name))
				{
					PartRefAndPose* part_ref_pose = new PartRefAndPose (part_ref_pose_part);
					part_ref_pose->get(part_ref_pose_part);

					//--Retrieve hasPoseLocation_Point
					Point * part_ref_pose_point = part_ref_pose->gethasPartRefAndPose_Point();
					/*
					part_ref_pose_point->get(part_ref_pose_point->getname());
					//cout << "part_point: "<<part_ref_pose_point->getname() << endl;
					double part_point_x = part_ref_pose_point->gethasPoint_X();
					double part_point_y = part_ref_pose_point->gethasPoint_Y();
					double part_point_z = part_ref_pose_point->gethasPoint_Z();
					cout << "part_ref_pose_point: ("<<part_point_x<<","<<part_point_y<<","<<part_point_z<<")"<< endl;
					*/

					//--Retrieve hasPartRefAndPose_XAxis
					Vector * part_ref_pose_x_axis  = part_ref_pose->gethasPartRefAndPose_XAxis();
					/*
					part_ref_pose_x_axis->get(part_ref_pose_x_axis->getname());
					//cout << "part_x_axis: "<<part_x_axis->getname() << endl;
					double part_ref_pose_x_axis_x = part_ref_pose_x_axis->gethasVector_I();
					double part_ref_pose_x_axis_y = part_ref_pose_x_axis->gethasVector_J();
					double part_ref_pose_x_axis_z = part_ref_pose_x_axis->gethasVector_K();
					cout << "part_ref_pose_x_axis: ("<<part_ref_pose_x_axis_x<<","<< part_ref_pose_x_axis_y<<","<<part_ref_pose_x_axis_z<<")"<< endl;
					*/

					//--Retrieve hasPartRefAndPose_ZAxis
					Vector * part_ref_pose_z_axis  = part_ref_pose->gethasPartRefAndPose_ZAxis();
					/*
					part_ref_pose_z_axis->get(part_ref_pose_z_axis->getname());
					//cout << "part_z_axis: "<<part_z_axis->getname() << endl;
					double part_ref_pose_z_axis_x = part_ref_pose_z_axis->gethasVector_I();
					double part_ref_pose_z_axis_y = part_ref_pose_z_axis->gethasVector_J();
					double part_ref_pose_z_axis_z = part_ref_pose_z_axis->gethasVector_K();
					cout << "part_ref_pose_z_axis: ("<<part_ref_pose_z_axis_x<<","<<part_ref_pose_z_axis_y<<","<<part_ref_pose_z_axis_z<<")"<< endl;
					*/

					MoveToPutPart(part_ref_pose_point, part_ref_pose_z_axis, part_ref_pose_x_axis);

				}
			}
		}
	}
}

/*!
@brief Create the canonical robot commands for the action @a attach-eff
@param paramList List of parameters

The canonical robot commands for this action are:
*/
void CanonicalRobotCommand::attach_eff(vector<string> paramList,KittingPlan *kittingplan){
	//cout <<endl;
	//cout <<"Message (\"attach endeffector\")"<< endl;
	//FileOperator *fileop = new FileOperator;
	//int listLength;
	//listLength=(int)paramList.size();

	/*
	for (vector<string>::size_type i = 0; i < listLength; i++){
		string type;
		type=kittingplan->matchParamType(paramList[i]);

		fileop->stripSpace(type);
		//cout <<type << endl;
		//type.erase(remove_if(type.begin(), type.end(), isspace), type.end());

		if (!strcmp(type.c_str(),"Robot"))
		{
			cout << type << endl;

			Robot * r = new Robot(paramList[i]);
			r->get(paramList[i]);
			cout << r->gethasRobot_Description()<<endl;
			cout << r->gethasRobot_Id() << endl;
		}

		if (!strcmp(type.c_str(),"VacuumEffectorSingleCup"))
		{
			cout << type << endl;
			cout<< paramList[i] << endl;
			VacuumEffectorSingleCup * r = new VacuumEffectorSingleCup(paramList[i]);
			r->get(paramList[i]);
			cout << r->getVacuumEffectorSingleCupID()<<endl;
		}

		if (!strcmp(type.c_str(),"EndEffectorHolder"))
		{
			cout << type << endl;
			cout<< paramList[i] << endl;
			EndEffectorHolder * r = new EndEffectorHolder(paramList[i]);
			r->get(paramList[i]);
			EndEffectorChangingStation* ech = r->gethadByEndEffectorHolder_ChangingStation();
			ech->get(ech->getname());
			cout << r->gethadByEndEffectorHolder_ChangingStation()->getEndEffectorChangingStationID() << endl;
		}

	}
	*/

	//VacuumEffectorSingleCup * gripper = new VacuumEffectorSingleCup("tray_gripper");
	//cout << gripper->getVacuumEffectorSingleCupID()<<endl;

}

void CanonicalRobotCommand::remove_eff(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"remove endeffector\")"<< endl;
}

/*!
@brief This function inserts a new row of data in the table Kit.
@param paramList List of parameters

The data to be inserted in the table Kit are:
<ul>
<li>KitID: ID of the new Kit.
<li>_NAME: Name of the new Kit.
<li>hasKit_DesignRef: Kit design associated to this Kit.
<li>isKit_Finished: 1 if the Kit is finished, 0 otherwise.
<li>hadByKit_LargeBoxWithKits: The LargeBoxWithKits that is capable of containing this Kit.
<li>hasKit_Tray: Kit Tray associated to this Kit.
</ul>
*/
void CanonicalRobotCommand::create_kit(vector<string> paramList){
	//cout <<endl;
	//cout <<"Message (\"create kit\")"<< endl;
}


/*!
@brief Reads a line of the plan and interprets it into one or more canonical robot commands.

@param action Action to be interpreted
@return A list of commands associated to the action @a action

*/
void CanonicalRobotCommand::actionInterpreter(string actionName,
		vector<string> paramList,
		KittingPlan *kittingplan){

	FileOperator *fileop = new FileOperator;

	//cout << actionName << endl;
	//fileop->readVector(paramList);

	if(actionName == "take-kit-tray")	take_kit_tray(paramList);
	if(actionName == "put-kit-tray") 	put_kit_tray(paramList);
	if(actionName == "take-kit") 		take_kit(paramList);
	if(actionName == "put-kit") 		put_kit(paramList);
	if(actionName == "take-part") 		take_part(paramList, kittingplan);
	if(actionName == "put-part") 		put_part(paramList, kittingplan);
	if(actionName == "attach-eff") 		attach_eff(paramList, kittingplan);
	if(actionName == "remove-eff") 		remove_eff(paramList);
	if(actionName == "create-kit") 		create_kit(paramList);
}

/*!
@brief Read the plan stored in KittingPlan::m_actionParamList and interpret each action

@param kittingplan Instance of KittingPlan

*/
void CanonicalRobotCommand::interpretPlan(KittingPlan *kittingplan){
	int nbAction=0;
	string action("");
	string actionName("");
	vector<string> paramName;

	cout << "InitCanon ()" << endl;
	cout << "OpenGripper ()" << endl;
	for (vector< vector<string> >::size_type u = 0; u < kittingplan->m_actionParamList.size(); u++) {
		actionName=kittingplan->m_actionParamList[u][0];
		nbAction++;
			for (vector<string>::size_type v = 1; v < kittingplan->m_actionParamList[u].size(); v++) {
				//cout << kittingplan->m_actionParamList[u][v] << " ";
				paramName.push_back(kittingplan->m_actionParamList[u][v]);
				//action += kittingplan->m_actionParamList[u][v];
				//action +=" ";
			}
			//cout << actionName << " --> " << action;

			actionInterpreter(actionName, paramName, kittingplan);

			paramName.clear();
			cout << endl;
		}
	cout << "EndCanon (2)" << endl;
	//cout << "Number of Actions: " << nbAction << endl;
	//fileop->readVectorOfVector(kittingplan->m_actionParamList);
}
