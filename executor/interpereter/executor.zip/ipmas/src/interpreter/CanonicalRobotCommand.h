/*
 * CanonicalRobotCommand.h
 *
 *  Created on: Jun 28, 2012
 *      Author: zeid
 */

#ifndef CANONICALROBOTCOMMAND_H_
#define CANONICALROBOTCOMMAND_H_


#include "Tools.h"
#include "KittingPlan.h"

//-- Headers to access data from the database
#include "Kit.h"
#include "KitDesign.h"
#include "Part.h"
#include "PartRefAndPose.h"
#include "PartsTray.h"
#include "Point.h"
#include "PoseLocation.h"
#include "PhysicalLocation.h"
#include "Robot.h"
#include "Vector.h"
#include "KitTray.h"
#include "Structdef.h"



class CanonicalRobotCommand {
public:
	CanonicalRobotCommand();
	virtual ~CanonicalRobotCommand();

	void MoveToTakePart(vector<double> xyz, Vector* z_axis, Vector* x_axis);
	void MoveToPutPart(vector<double> xyz, Vector* z_axis, Vector* x_axis);
	void actionInterpreter(string action,vector<string> paramName,KittingPlan *kittingplan);
	void interpretPlan(KittingPlan *kittingplan);
	void take_kit_tray(vector<string> paramList);
	void put_kit_tray(vector<string> paramList);
	void take_kit(vector<string> paramList);
	void put_kit(vector<string> paramList);
	void take_part(vector<string> paramList,KittingPlan *kittingplan);
	void put_part(vector<string> paramList,KittingPlan *kittingplan);
	void attach_eff(vector<string> paramList,KittingPlan *kittingplan);
	void remove_eff(vector<string> paramList);
	void create_kit(vector<string> paramList, KittingPlan *kittingplan);
	Point* getRobotPoseLocation(string robotName);
	PartLocStruct getPartLocation(string partName);
	PartsTrayLocStruct getPartsTrayLocation(string parts_tray_name);
	KitTrayLocStruct getKitTrayLocation(string kit_tray_name);
	double m_safe_z;
	double m_dwell;
	string m_kit_tray;
};

#endif /* CANONICALROBOTCOMMAND_H_ */
