/*
 * CanonicalRobotCommand.h
 *
 *  Created on: Jun 28, 2012
 *      Author: zeid
 */

#ifndef CANONICALROBOTCOMMAND_H_
#define CANONICALROBOTCOMMAND_H_

#include "Tools.h"
#include "KittingPlan.h"

//-- Headers to access data from the database
#include "Kit.h"
#include "KitDesign.h"
#include "Part.h"
#include "PartRefAndPose.h"
#include "Point.h"
#include "PoseLocation.h"
#include "Robot.h"
#include "Vector.h"





class CanonicalRobotCommand {
public:
	CanonicalRobotCommand();
	virtual ~CanonicalRobotCommand();

	void MoveToTakePart(Point* point, Vector* z_axis, Vector* x_axis);
	void MoveToPutPart(Point* point, Vector* z_axis, Vector* x_axis);
	void actionInterpreter(string action,vector<string> paramName,KittingPlan *kittingplan);
	void interpretPlan(KittingPlan *kittingplan);
	void take_kit_tray(vector<string> paramList);
	void put_kit_tray(vector<string> paramList);
	void take_kit(vector<string> paramList);
	void put_kit(vector<string> paramList);
	void take_part(vector<string> paramList,KittingPlan *kittingplan);
	void put_part(vector<string> paramList,KittingPlan *kittingplan);
	void attach_eff(vector<string> paramList,KittingPlan *kittingplan);
	void remove_eff(vector<string> paramList);
	void create_kit(vector<string> paramList);
	Point* getRobotPoseLocation(string robotName);
	void getPartLocation(string partName);
	string getKitDesignForKit(string kitName);
	double safe_z;
	double dwell;
	string gripper_status;
};

#endif /* CANONICALROBOTCOMMAND_H_ */
