/*
 * Structdef.h
 *
 *  Created on: Aug 24, 2012
 *      Author: zeid
 */

#ifndef STRUCTDEF_H_
#define STRUCTDEF_H_


struct PartLocStruct
{
	Point* point;
	Vector* x_axis;
	Vector* z_axis;
};

struct PartsTrayLocStruct
{
	Point* point;
	Vector* x_axis;
	Vector* z_axis;
};

struct KitTrayLocStruct
{
	Point* point;
	Vector* x_axis;
	Vector* z_axis;
};


#endif /* STRUCTDEF_H_ */
