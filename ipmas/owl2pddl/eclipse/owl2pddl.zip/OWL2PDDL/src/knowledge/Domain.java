/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      Domain.java
 * @brief     Data structure for a PDDL domain file
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Class to represent information of a PDDL domain file
 * 
 * @details Consists of functions that builds a PDDL domain file
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Domain {
	/**
	 * @brief A domain as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/**
	 * @ingroup DP
	 * @brief Data property hasDomain_Variable
	 * 
	 * This data property is used to retrieve all the variables of a domain
	 */
	private String m_hasDomain_Variable;
	/**
	 * @ingroup DP
	 * @brief Data property hasDomain_Requirement
	 * 
	 * This data property is used to retrieve all the requirements of a domain
	 */
	private String m_hasDomain_Requirement;
	/**
	 * @brief List of PDDL negative predicates
	 */
	private static ArrayList<NegativePredicate> m_negative_predicate_list;
	/**
	 * @brief List of PDDL positive predicates
	 */
	private static ArrayList<PositivePredicate> m_positive_predicate_list;
	/**
	 * @brief List of PDDL functions
	 */
	private static ArrayList<Function> m_function_list;
	/**
	 * @brief List of PDDL actions
	 */
	private static ArrayList<Action> m_action_list;
	/**
	 * @brief List of PDDL requirements of a domain
	 */
	private static ArrayList<String> m_requirement_list;
	/**
	 * @brief List of PDDL variables of a domain
	 */
	private static ArrayList<String> m_variable_list;
	/**
	 * @brief class constructor
	 * 
	 * <ul>
	 * <li>set the values for data properties
	 * </ul>
	 */
	public Domain() {
		m_hasDomain_Variable="hasDomain_Variable";
		m_hasDomain_Requirement="hasDomain_Requirement";
	}
	/**
	 * @return the m_domain_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_domain_individual the m_domain_individual to set
	 */
	public void setM_individual(OWLIndividual m_domain_individual) {
		this.m_individual = m_domain_individual;
	}

	/**
	 * @return the m_function_list
	 */
	public ArrayList<Function> getM_function_list() {
		return m_function_list;
	}
	/**
	 * @param m_function_list the m_function_list to set
	 */
	public void setM_function_list(ArrayList<Function> m_function_list) {
		Domain.m_function_list = m_function_list;
	}
	/**
	 * @return the m_action_list
	 */
	public ArrayList<Action> getM_action_list() {
		return m_action_list;
	}
	/**
	 * @param m_action_list the m_action_list to set
	 */
	public void setM_action_list(ArrayList<Action> m_action_list) {
		Domain.m_action_list = m_action_list;
	}
	/**
	 * @return the m_negative_predicate_list
	 */
	public ArrayList<NegativePredicate> getM_negative_predicate_list() {
		return m_negative_predicate_list;
	}
	/**
	 * @param m_negative_predicate_list the m_negative_predicate_list to set
	 */
	public void setM_negative_predicate_list(
			ArrayList<NegativePredicate> m_negative_predicate_list) {
		Domain.m_negative_predicate_list = m_negative_predicate_list;
	}
	/**
	 * @return the m_positive_predicate_list
	 */
	public ArrayList<PositivePredicate> getM_positive_predicate_list() {
		return m_positive_predicate_list;
	}
	/**
	 * @param m_positive_predicate_list the m_positive_predicate_list to set
	 */
	public void setM_positive_predicate_list(
			ArrayList<PositivePredicate> m_positive_predicate_list) {
		Domain.m_positive_predicate_list = m_positive_predicate_list;
	}
	/**
	 * @return the m_DPhasDomain_Variable
	 */
	public String getM_DPhasDomain_Variable() {
		return m_hasDomain_Variable;
	}

	/**
	 * @return the m_DPhasDomain_Requirement
	 */
	public String getM_DPhasDomain_Requirement() {
		return m_hasDomain_Requirement;
	}

	/**
	 * @return the m_requirement_list
	 */
	public ArrayList<String> getM_requirement_list() {
		return m_requirement_list;
	}
	/**
	 * @param m_requirement_list the m_requirement_list to set
	 */
	public void setM_requirement_list(ArrayList<String> m_requirement_list) {
		Domain.m_requirement_list = m_requirement_list;
	}
	/**
	 * @return the m_variable_list
	 */
	public ArrayList<String> getM_variable_list() {
		return m_variable_list;
	}
	/**
	 * @param m_variable_list the m_variable_list to set
	 */
	public void setM_variable_list(ArrayList<String> m_variable_list) {
		Domain.m_variable_list = m_variable_list;
	}

}
