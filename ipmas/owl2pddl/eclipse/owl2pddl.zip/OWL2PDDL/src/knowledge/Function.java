/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      Function.java
 * @brief     Data structure for PDDL functions
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Class to represent a PDDL function
 * 
 * @details Consists of data that are used to build PDDL functions
 * 
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Function {
	/**
	 * @brief A PDDL function as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/**
	 * @brief The reference parameter of a PDDL function
	 */
	private String m_reference_parameter;
	/**
	 * @brief The target parameter of a PDDL function
	 */
	private String m_target_parameter;
	/**
	 * @brief The description of a PDDL function
	 */
	private String m_description;
	/**
	 * @ingroup DP
	 * @brief The object property hasFunction_Description
	 * 
	 * This object property is used to retrieve the description of a PDDL function
	 */
	private String m_hasFunction_Description;
	/**
	 * @ingroup OP
	 * @brief The object property hasFunction_ReferenceParameter
	 * 
	 * This object property is used to retrieve the reference parameter of a PDDL function
	 */
	private String m_hasFunction_ReferenceParameter;
	/**
	 * @ingroup OP
	 * @brief The object property hasFunction_targetParameter
	 * 
	 * This object property is used to retrieve the target parameter of a PDDL function
	 */
	private String m_hasFunction_TargetParameter;
	/**
	 * @brief class constructor
	 */
	public Function() {
		m_hasFunction_Description="hasFunction_Description";
		m_hasFunction_ReferenceParameter="hasFunction_ReferenceParameter";
		m_hasFunction_TargetParameter="hasFunction_TargetParameter";
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}

	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_reference_parameter
	 */
	public String getM_reference_parameter() {
		return m_reference_parameter;
	}
	/**
	 * @param m_reference_parameter the m_reference_parameter to set
	 */
	public void setM_reference_parameter(String m_reference_parameter) {
		this.m_reference_parameter = m_reference_parameter;
	}
	/**
	 * @return the m_target_parameter
	 */
	public String getM_target_parameter() {
		return m_target_parameter;
	}
	/**
	 * @param m_target_parameter the m_target_parameter to set
	 */
	public void setM_target_parameter(String m_target_parameter) {
		this.m_target_parameter = m_target_parameter;
	}
	/**
	 * @return the m_description
	 */
	public String getM_description() {
		return m_description;
	}
	/**
	 * @param m_description the m_description to set
	 */
	public void setM_description(String m_description) {
		this.m_description = m_description;
	}
	/**
	 * @return the m_hasFunction_Description
	 */
	public String getM_hasFunction_Description() {
		return m_hasFunction_Description;
	}

	/**
	 * @return the m_hasFunction_ReferenceParameter
	 */
	public String getM_hasFunction_ReferenceParameter() {
		return m_hasFunction_ReferenceParameter;
	}

	/**
	 * @return the m_hasFunction_TargetParameter
	 */
	public String getM_hasFunction_TargetParameter() {
		return m_hasFunction_TargetParameter;
	}

}
