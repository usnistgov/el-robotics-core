/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      FunctionOperation.java
 * @brief     Data structure for PDDL function operations
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Class to represent a PDDL function operation
 * 
 * @details Consists of data that are used to build PDDL function operations. A PDDL function operation consists of:
 * <ul>
 * <li>an expression
 * <li>a PDDL function
 * <li>a value
 * </ul>
 * An example of a PDDL function operation is: (decrease (quantity-of-parts-in-partstray ?partstray) 1)

 * where:
 * <ul>
 * <li><b>decrease</b> is the expression
 * <li><b>(quantity-of-parts-in-partstray ?partstray)</b> is the function
 * <li><b>1</b> is the value
 * </ul>
 * 
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class FunctionOperation {
	/**
	 * @brief a PDDL function operation as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/**
	 * @brief the PDDL function for the PDDL function operation
	 */
	private String m_function;
	/**
	 * @brief the expression for the PDDL function operation
	 */
	private String m_expression;

	/**
	 * @brief the value for the PDDL function operation
	 */
	private Integer m_value;

	//-- Data properties
	/**
	 * @ingroup DP
	 * @brief data property hasFunctionOperation_Expression
	 * 
	 * This data property is used to retrieve the expression of a PDDL function operation
	 */
	private String m_hasFunctionOperation_Expression;
	/**
	 * @ingroup DP
	 * @brief data property hasFunctionOperation_Value
	 * 
	 * This data property is used to retrieve the value of a PDDL function operation
	 */
	private String m_hasFunctionOperation_Value;
	/**
	 * @brief class constructor
	 */
	public FunctionOperation() {
		m_hasFunctionOperation_Expression="hasFunctionOperation_Expression";
		m_hasFunctionOperation_Value="hasFunctionOperation_Value";
	}
	/**
	 * @return the m_function
	 */
	public String getM_function() {
		return m_function;
	}
	/**
	 * @param m_function the m_function to set
	 */
	public void setM_function(String m_function) {
		this.m_function = m_function;
	}
	/**
	 * @return the m_value
	 */
	public Integer getM_value() {
		return m_value;
	}
	/**
	 * @param m_value the m_value to set
	 */
	public void setM_value(Integer m_value) {
		this.m_value = m_value;
	}
	/**
	 * @return the m_expression
	 */
	public String getM_expression() {
		return m_expression;
	}
	/**
	 * @param m_expression the m_expression to set
	 */
	public void setM_expression(String m_expression) {
		this.m_expression = m_expression;
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_hasFunctionOperation_Value
	 */
	public String getM_hasFunctionOperation_Value() {
		return m_hasFunctionOperation_Value;
	}

	/**
	 * @return the m_hasFunctionOperation_Expression
	 */
	public String getM_hasFunctionOperation_Expression() {
		return m_hasFunctionOperation_Expression;
	}


}
