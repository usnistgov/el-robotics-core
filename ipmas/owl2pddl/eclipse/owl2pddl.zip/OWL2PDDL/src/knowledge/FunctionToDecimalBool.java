/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      FunctionToDecimalBool.java
 * @brief     Data structure for function to decimal comparisons
 */
package knowledge;


/**
 * @brief Class to represent a PDDL FunctionToDecimalBool type
 * 
 * @details Consists of data that are used to build PDDL FunctionToDecimalBool types. A PDDL FunctionToDecimalBool type consists of:
 * <ul>
 * <li>an arithmetic expression
 * <li>a PDDL function
 * <li>a value
 * </ul>
 * An example of a PDDL FunctionToDecimalBool type is: (> (quantity-of-parts-in-partstray ?partstray) 0)

 * where:
 * <ul>
 * <li><b>></b> is the arithmetic expression
 * <li><b>(quantity-of-parts-in-partstray ?partstray)</b> is the function
 * <li><b>0</b> is the value
 * </ul>
 * 
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class FunctionToDecimalBool {
	/**
	 * @brief the PDDL function for the FunctionToDecimalBool type
	 */
	private String F1;
	/**
	 * @brief the decimal for the FunctionToDecimalBool type
	 */
	private String D1;
	/**
	 * @brief the expression for the FunctionToDecimalBool type
	 */
	private String expression;
	/**
	 * @ingroup DP
	 * @brief the data property hasFunctionToDecimalBool_DecimalNumber
	 * 
	 * This data property is used to retrieve the decimal of the FunctionToDecimalBool type
	 */
	private String m_hasFunctionToDecimalBool_DecimalNumber;
	
	/**
	 * @brief class constructor
	 */
	public FunctionToDecimalBool() {
		m_hasFunctionToDecimalBool_DecimalNumber="hasFunctionToDecimalBool_DecimalNumber";
	}


	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}

	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}


	/**
	 * @return the f1
	 */
	public String getF1() {
		return F1;
	}


	/**
	 * @param f1 the f1 to set
	 */
	public void setF1(String f1) {
		F1 = f1;
	}


	/**
	 * @return the decimal
	 */
	public String getD1() {
		return D1;
	}


	/**
	 * @param d1 the decimal to set
	 */
	public void setD1(String d1) {
		D1 = d1;
	}


	/**
	 * @return the m_DP_hasFunctionToDecimalBool_DecimalNumber
	 */
	public String getM_DP_hasFunctionToDecimalBool_DecimalNumber() {
		return m_hasFunctionToDecimalBool_DecimalNumber;
	}
}	





