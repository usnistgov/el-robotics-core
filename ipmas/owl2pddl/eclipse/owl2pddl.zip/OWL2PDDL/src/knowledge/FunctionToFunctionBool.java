/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      FunctionToFunctionBool.java
 * @brief     Data structure for function to function comparisons
 */
package knowledge;


/**
 * @brief Class to represent a PDDL FunctionToFunctionBool type
 * 
 * @details Consists of data that are used to build PDDL FunctionToFunctionBool types. A PDDL FunctionToFunctionBool type consists of:
 * <ul>
 * <li>an arithmetic expression
 * <li>a PDDL function (f1)
 * <li>a PDDL function (f2)
 * </ul>
 * An example of a PDDL FunctionToFunctionBool type is: (<(quantity-of-kits-in-lbwk ?largeboxwithkits) (capacity-of-kits-in-lbwk ?largeboxwithkits))

 * where:
 * <ul>
 * <li><b><</b> is the arithmetic expression
 * <li><b>(quantity-of-kits-in-lbwk ?largeboxwithkits)</b> is a PDDL function (f1)
 * <li><b>(capacity-of-kits-in-lbwk ?largeboxwithkits)</b> is a PDDL function (f2)
 * </ul>
 * 
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class FunctionToFunctionBool {
	/**
	 * @brief the first PDDL function for the FunctionToFunctionBool type
	 */
	private String F1;
	/**
	 * @brief the second PDDL function for the FunctionToFunctionBool type
	 */
	private String F2;
	/**
	 * @brief the expression for the FunctionToFunctionBool type
	 */
	private String expression;
	/**
	 * @brief class constructor
	 */
	public FunctionToFunctionBool() {
	}

	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}
	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}

	/**
	 * @return the f1
	 */
	public String getF1() {
		return F1;
	}

	/**
	 * @param f1 the f1 to set
	 */
	public void setF1(String f1) {
		F1 = f1;
	}

	/**
	 * @return the f2
	 */
	public String getF2() {
		return F2;
	}

	/**
	 * @param f2 the f2 to set
	 */
	public void setF2(String f2) {
		F2 = f2;
	}

}
