/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      GoalOntology.java
 * @brief     Data structure for an OWL goal file
 */
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @brief Class to represent an OWL goal file
 * 
 * @details Consists of data that are used to retrieve information from an OWL goal file
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class GoalOntology extends Ontology {
	/**
	 * @brief reasoner for the OWL goal file
	 */
	private static OWLReasoner m_goalOWLReasoner;
	/**
	 * @brief path to the OWL goal file
	 */
	private static String m_PathToGoalInstanceFile;


	/**
	 * @brief OWLOntology for the goal instance file
	 */
	private static OWLOntology m_OWLGoalInstanceOntology;

	/**
	 * @brief IRI for the OWL goal file
	 */
	private static String m_goal_IRI;

	/**
	 * @brief class constructor
	 * @details The constructor sets the IRI for the goal file
	 */
	public GoalOntology() {
		m_goal_IRI="http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";

	}

	/**
	 * @brief set the reasoner for the OWL goal file
	 */
	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		setM_goalOWLReasoner(reasonerFactory.createReasoner(m_OWLGoalInstanceOntology));
	}

	/**
	 * @brief load the OWL goal ontology from a given path @a myPath
	 * @param myPath path to the OWL goal ontology
	 * @throws MalformedURLException
	 * @throws OWLException
	 */
	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		//String filePath = new File("").getAbsolutePath();
		//System.out.println("filepath: "+filePath);
		//String l_OWLOntologyPath=getM_PathToSoapInstanceFile();
		//File file = new File(filePath.concat("/"+myPath));
		File file = new File(myPath);

		//-- Set the owl file passed as arguments as the current ontology
		setM_OWLGoalInstanceOntology(getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file));
	}

	/**
	 * @brief get an OWLClass from the OWL goal by using a Java string
	 * @param myClassName Class name as a string
	 * @return OWLClass built from @a myClassName
	 */
	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_goal_IRI().concat(myClassName)));
		return myClass;
	}


	/**
	 * @return the m_PathToGoalInstanceFile
	 */
	public static String getM_PathToGoalInstanceFile() {
		return m_PathToGoalInstanceFile;
	}
	/**
	 * @param m_PathToGoalInstanceFile the m_PathToGoalInstanceFile to set
	 */
	public void setM_PathToGoalInstanceFile(
			String m_PathToGoalInstanceFile) {
		GoalOntology.m_PathToGoalInstanceFile = m_PathToGoalInstanceFile;
	}
	/**
	 * @return the m_OWLGoalInstanceOntology
	 */
	public OWLOntology getM_OWLGoalInstanceOntology() {
		return m_OWLGoalInstanceOntology;
	}
	/**
	 * @param m_OWLGoalInstanceOntology the m_OWLGoalInstanceOntology to set
	 */
	public static void setM_OWLGoalInstanceOntology(
			OWLOntology m_OWLGoalInstanceOntology) {
		GoalOntology.m_OWLGoalInstanceOntology = m_OWLGoalInstanceOntology;
	}
	/**
	 * @return the m_goal_IRI
	 */
	public String getM_goal_IRI() {
		return m_goal_IRI;
	}


	/**
	 * @return the m_goalOWLReasoner
	 */
	public OWLReasoner getM_goalOWLReasoner() {
		return m_goalOWLReasoner;
	}

	/**
	 * @param m_goalOWLReasoner the m_goalOWLReasoner to set
	 */
	public static void setM_goalOWLReasoner(OWLReasoner m_goalOWLReasoner) {
		GoalOntology.m_goalOWLReasoner = m_goalOWLReasoner;
	}

}
