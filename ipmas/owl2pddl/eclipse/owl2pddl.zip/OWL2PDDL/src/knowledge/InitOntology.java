/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      InitOntology.java
 * @brief     Data structure for an OWL init file
 */
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @brief Class to represent an OWL init file
 * 
 * @details Consists of data that are used to retrieve information from an OWL init file
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class InitOntology extends Ontology {
	/**
	 * @brief reasoner for the OWL init file
	 */
	private static OWLReasoner m_initOWLReasoner;
	//-- Object properties
	/**
	 * @ingroup OP
	 * @brief build the object property hasEndEffectorChangingStation_EndEffectorHolder
	 */
	private String m_hasEndEffectorChangingStation_EndEffectorHolder;
	/**
	 * @ingroup OP
	 * @brief build the object property hasEndEffectorHolder_EndEffector
	 */
	private String m_hasEndEffectorHolder_EndEffector;
	/**
	 * @ingroup OP
	 * @brief build the object property hasLargeBoxWithEmptyKitTrays_KitTray
	 */
	private String m_hasRobot_EndEffector;
	/**
	 * @ingroup OP
	 * @brief build the object property hasLargeBoxWithEmptyKitTrays_KitTray
	 */
	private String m_hasLargeBoxWithEmptyKitTrays_KitTray;
	/**
	 * @ingroup OP
	 * @brief build the object property hasPartsVessel_Part
	 */
	private String m_hasPartsVessel_Part;
	/**
	 * @ingroup OP
	 * @brief build the object property hasEndEffector_HeldObject
	 */
	private String m_hasEndEffector_HeldObject;
	/**
	 * @ingroup OP
	 * @brief build the object property hasWorkTable_ObjectOnTable
	 */
	private String m_hasWorkTable_ObjectOnTable;
	/**
	 * @ingroup OP
	 * @brief build the data property hasLargeBoxWithKits_Capacity
	 */
	private String m_hasLargeBoxWithKits_Capacity;
	/**
	 * @brief Path to OWL init file
	 */
	private static String m_PathToInitInstanceFile;
	/**
	 * @brief OWLOntology for the OWL init file
	 */
	private static OWLOntology m_OWLInitInstanceOntology;
	/**
	 * @brief IRI for the OWL init file
	 */
	private static String m_init_IRI;
	

	/**
	 * @brief class constructor
	 */
	public InitOntology() {
		m_hasEndEffectorChangingStation_EndEffectorHolder="hasEndEffectorChangingStation_EndEffectorHolder";
		m_hasEndEffectorHolder_EndEffector="hasEndEffectorHolder_EndEffector";
		m_hasRobot_EndEffector="hasRobot_EndEffector";
		m_hasLargeBoxWithEmptyKitTrays_KitTray="hasLargeBoxWithEmptyKitTrays_KitTray";
		m_hasPartsVessel_Part="hasPartsVessel_Part";
		m_hasEndEffector_HeldObject="hasEndEffector_HeldObject";
		m_hasWorkTable_ObjectOnTable="hasWorkTable_ObjectOnTable";
		m_hasLargeBoxWithKits_Capacity="hasLargeBoxWithKits_Capacity";
		
		m_init_IRI="http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";
	}
	/**
	 * @brief set the reasoner for the OWL init file
	 */
	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		setM_initOWLReasoner(reasonerFactory.createReasoner(m_OWLInitInstanceOntology));
	}

	/**
	 * @brief load the OWL goal ontology
	 * @param myPath path to the OWL goal ontology
	 * @throws MalformedURLException
	 * @throws OWLException
	 */
	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		File file = new File(myPath);
		//-- Set the owl file passed as arguments as the current ontology
		setM_OWLInitInstanceOntology(getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file));
	}
	/**
	 * @brief get an OWLClass from the OWL init by using a Java string
	 * @param myClassName Class name as a string
	 * @return OWLClass built from @a myClassName
	 */
	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_init_IRI().concat(myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//progressMonitor);
		return myClass;
	}
	/*
	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_init_IRI().concat(":" + myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//		progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = getM_initOWLReasoner().getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}
	 */

	/**
	 * @return the m_PathToInitInstanceFile
	 */
	public static String getM_PathToInitInstanceFile() {
		return m_PathToInitInstanceFile;
	}
	/**
	 * @param m_PathToInitInstanceFile the m_PathToInitInstanceFile to set
	 */
	public void setM_PathToInitInstanceFile(
			String m_PathToInitInstanceFile) {
		InitOntology.m_PathToInitInstanceFile = m_PathToInitInstanceFile;
	}
	/**
	 * @return the m_OWLInitInstanceOntology
	 */
	public OWLOntology getM_OWLInitInstanceOntology() {
		return m_OWLInitInstanceOntology;
	}
	/**
	 * @param m_OWLInitInstanceOntology the m_OWLInitInstanceOntology to set
	 */
	public static void setM_OWLInitInstanceOntology(
			OWLOntology m_OWLInitInstanceOntology) {
		InitOntology.m_OWLInitInstanceOntology = m_OWLInitInstanceOntology;
	}
	/**
	 * @return the m_init_IRI
	 */
	public String getM_init_IRI() {
		return m_init_IRI;
	}


	/**
	 * @return the m_OP_hasEndEffectorChangingStation_EndEffectorHolder
	 */
	public String getM_OP_hasEndEffectorChangingStation_EndEffectorHolder() {
		return m_hasEndEffectorChangingStation_EndEffectorHolder;
	}

	/**
	 * @return the m_OP_hasRobot_EndEffector
	 */
	public String getM_OP_hasRobot_EndEffector() {
		return m_hasRobot_EndEffector;
	}


	/**
	 * @return the m_OP_hasLargeBoxWithEmptyKitTrays_KitTray
	 */
	public String getM_OP_hasLargeBoxWithEmptyKitTrays_KitTray() {
		return m_hasLargeBoxWithEmptyKitTrays_KitTray;
	}


	/**
	 * @return the m_DP_hasLargeBoxWithKits_Capacity
	 */
	public String getM_DP_hasLargeBoxWithKits_Capacity() {
		return m_hasLargeBoxWithKits_Capacity;
	}

	/**
	 * @return the m_OP_hasPartsVessel_Part
	 */
	public String getM_OP_hasPartsVessel_Part() {
		return m_hasPartsVessel_Part;
	}

	/**
	 * @return the m_OP_hasEndEffectorHolder_EndEffector
	 */
	public String getM_OP_hasEndEffectorHolder_EndEffector() {
		return m_hasEndEffectorHolder_EndEffector;
	}

	/**
	 * @return the m_OP_hasWorkTable_ObjectOnTable
	 */
	public String getM_OP_hasWorkTable_ObjectOnTable() {
		return m_hasWorkTable_ObjectOnTable;
	}

	/**
	 * @return the m_initOWLReasoner
	 */
	public OWLReasoner getM_initOWLReasoner() {
		return m_initOWLReasoner;
	}

	/**
	 * @param m_initOWLReasoner the m_initOWLReasoner to set
	 */
	public static void setM_initOWLReasoner(OWLReasoner m_initOWLReasoner) {
		InitOntology.m_initOWLReasoner = m_initOWLReasoner;
	}

	/**
	 * @return the m_OP_hasEndEffector_HeldObject
	 */
	public String getM_OP_hasEndEffector_HeldObject() {
		return m_hasEndEffector_HeldObject;
	}
}
