/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      NegativePredicate.java
 * @brief     Data structure for a negative predicate
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

/**
 * @brief Class to represent a PDDL negative predicate
 * 
 * @details Consists of data that are used to build PDL negative predicates. A PDDL negative predicate's structure is 
 * not (positive predicate).
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class NegativePredicate extends Predicate {
	/**
	 * @brief A PDDL negative predicate as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/**
	 * @brief A PDDL positive predicate as an OWLNamedIndividual
	 */
	private OWLNamedIndividual m_positive_predicate;
	/**
	 * @brief class constructor
	 */
	public NegativePredicate() {
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_positive_predicate
	 */
	public OWLIndividual getM_positive_predicate() {
		return m_positive_predicate;
	}
	/**
	 * @param m_positive_predicate the m_positive_predicate to set
	 */
	public void setM_positive_predicate(OWLNamedIndividual m_positive_predicate) {
		this.m_positive_predicate = m_positive_predicate;
	}

}
