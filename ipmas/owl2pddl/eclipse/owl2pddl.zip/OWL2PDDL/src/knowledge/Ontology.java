/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      Ontology.java
 * @brief     Data structure for OWL files
 */
package knowledge;


import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLOntologyManager;


/**
 * @brief Class to represent an OWL ontology
 * 
 * @details Consists of data that are used to retrieve information from relevant ontologies.
 * 
 * This class incorporates the data structure that builds relevant object and data properties common to InitOntology 
 * and GoalOntology.
 * 
 * It also contains the data structure that builds relevant classes in order to generate the 
 * domain and problem files.
 * 
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Ontology {
	/**
	 * @brief OWLDataFactory for all ontologies.
	 * @details The OWLDataFactory interface is used for creating entities, class expressions and axioms.
	 */
	private static OWLDataFactory m_OWLDataFactory;
	/**
	 * @brief OWLOntologyManager for all ontologies.
	 * @details n OWLOntologyManager manages a set of ontologies. It is the main point for creating, loading and accessing ontologies.
	 */
	private static OWLOntologyManager m_OWLOntologyManager;
	/**
	 * @brief path for the output domain file
	 */
	private String m_outputPDDLDomainFile;

	/**
	 * @brief IRI for the kittingWorkstationClasses.owl file
	 */
	private String m_kittingWorkstationClasses_IRI;

	//-- Definition of OWL classes
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class SOAP
	 */
	private String m_owl_class_SOAP;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Domain
	 */
	private String m_owl_class_Domain;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Predicate:PositivePredicate
	 */
	private String m_owl_class_PositivePredicate;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Predicate:NegativePredicate
	 */
	private String m_owl_class_NegativePredicate;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Function
	 */
	private String m_owl_class_Function;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class ActionBase
	 */
	private String m_owl_class_ActionBase;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToFunctionEqual
	 */
	private String m_owl_class_FunctionToFunctionEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToFunctionGreater
	 */
	private String m_owl_class_FunctionToFunctionGreater;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToFunctionGreaterOrEqual
	 */
	private String m_owl_class_FunctionToFunctionGreaterOrEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToFunctionLessOrEqual
	 */
	private String m_owl_class_FunctionToFunctionLessOrEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToFunctionLess
	 */
	private String m_owl_class_FunctionToFunctionLess;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionOperation
	 */
	private String m_owl_class_FunctionOperation;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToDecimalEqual
	 */
	private String m_owl_class_FunctionToDecimalEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToDecimalGreater
	 */
	private String m_owl_class_FunctionToDecimalGreater;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToDecimalLess
	 */
	private String m_owl_class_FunctionToDecimalLess;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToDecimalGreaterOrEqual
	 */
	private String m_owl_class_FunctionToDecimalGreaterOrEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class FunctionToDecimalLessOrEqual
	 */
	private String m_owl_class_FunctionToDecimalLessOrEqual;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class EndEffector
	 */
	private String m_owl_class_EndEffector;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class EndEffectorChangingStation
	 */
	private String m_owl_class_EndEffectorChangingStation;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class EndEffectorHolder
	 */
	private String m_owl_class_EndEffectorHolder;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Kit
	 */
	private String m_owl_class_Kit;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class KitTray
	 */
	private String m_owl_class_KitTray;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class LargeBoxWithEmptyKitTrays
	 */
	private String m_owl_class_LargeBoxWithEmptyKitTrays;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class LargeBoxWithKits
	 */
	private String m_owl_class_LargeBoxWithKits;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class PartsTray
	 */
	private String m_owl_class_PartsTray;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Part
	 */
	private String m_owl_class_Part;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class Robot
	 */
	private String m_owl_class_Robot;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class StockKeepingUnit
	 */
	private String m_owl_class_StockKeepingUnit;
	/** @ingroup OWLClasses
	 *  @brief Definition of the OWL class WorkTable
	 */
	private String m_owl_class_WorkTable;

	/** @ingroup OP
	 *  @brief Definition of the object property hasSkuObject_Sku
	 */
	private String m_hasSkuObject_Sku;
	/** @ingroup OP
	 *  @brief Definition of the object property hasLargeBoxWithKits_Kit
	 */
	private String m_hasLargeBoxWithKits_Kit;
	/** @ingroup OP
	 *  @brief Definition of the object property hasStockKeepingUnit_EndEffector
	 */
	private String m_hasStockKeepingUnit_EndEffector;
	/** @ingroup OP
	 *  @brief Definition of the object property hasKit_KitTray
	 */
	private String m_hasKit_KitTray;
	/** @ingroup OP
	 *  @brief Definition of the object property hasSolidObject_PrimaryLocation
	 */
	private String m_hasSolidObject_PrimaryLocation;
	/** @ingroup OP
	 *  @brief Definition of the object property hasKit_Part
	 */
	private String m_hasKit_Part;
	/** @ingroup OP
	 *  @brief Definition of the object property hasPhysicalLocation_RefObject
	 */
	private String m_hasPhysicalLocation_RefObject;
	/**
	 *  @brief Class constructor
	 *  @details The constructor does the following things:
	 *  <ul>
	 *  <li>set the value for each OWL class variable
	 *  <li>set the value for each object property variable
	 *  <li>set the IRI for Ontology.m_kittingWorkstationClasses_IRI
	 *  </ul>
	 */
	public Ontology() {
		//-- Set OWL classes
		m_owl_class_StockKeepingUnit="StockKeepingUnit";
		m_owl_class_EndEffectorChangingStation="EndEffectorChangingStation";
		m_owl_class_Robot="Robot";
		m_owl_class_KitTray="KitTray";
		m_owl_class_LargeBoxWithEmptyKitTrays="LargeBoxWithEmptyKitTrays";
		m_owl_class_LargeBoxWithKits="LargeBoxWithKits";
		m_owl_class_WorkTable="WorkTable";
		m_owl_class_PartsTray="PartsTray";
		m_owl_class_Part="Part";
		m_owl_class_EndEffector="EndEffector";
		m_owl_class_EndEffectorHolder="EndEffectorHolder";
		m_owl_class_Kit="Kit";
		m_owl_class_SOAP="SOAP";
		m_owl_class_Domain="Domain";
		m_owl_class_PositivePredicate="PositivePredicate";
		m_owl_class_NegativePredicate="NegativePredicate";
		m_owl_class_Function="Function";
		m_owl_class_ActionBase="ActionBase";
		m_owl_class_FunctionToFunctionEqual="FunctionToFunctionEqual";
		m_owl_class_FunctionToFunctionGreater="FunctionToFunctionGreater";
		m_owl_class_FunctionToFunctionGreaterOrEqual="FunctionToFunctionGreaterOrEqual";
		m_owl_class_FunctionToFunctionLessOrEqual="FunctionToFunctionLessOrEqual";
		m_owl_class_FunctionToFunctionLess="FunctionToFunctionLess";
		m_owl_class_FunctionOperation="FunctionOperation";
		m_owl_class_FunctionToDecimalEqual="FunctionToDecimalEqual";
		m_owl_class_FunctionToDecimalGreater="FunctionToDecimalGreater";
		m_owl_class_FunctionToDecimalLess="FunctionToDecimalLess";
		m_owl_class_FunctionToDecimalGreaterOrEqual="FunctionToDecimalGreaterOrEqual";
		m_owl_class_FunctionToDecimalLessOrEqual="FunctionToDecimalLessOrEqual";

		//-- Set OWL object properties
		m_hasSkuObject_Sku="hasSkuObject_Sku";
		m_hasLargeBoxWithKits_Kit="hasLargeBoxWithKits_Kit";
		m_hasStockKeepingUnit_EndEffector="hasStockKeepingUnit_EndEffector";
		m_hasKit_KitTray="hasKit_KitTray";
		m_hasSolidObject_PrimaryLocation="hasSolidObject_PrimaryLocation";
		m_hasKit_Part="hasKit_Part";
		m_hasPhysicalLocation_RefObject="hasPhysicalLocation_RefObject";

		//-- Set IRI
		m_kittingWorkstationClasses_IRI="http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";

		setManager();
	}

	/**
	 * @brief Creates an OWL Ontology manager that is configured with standard parsers, storers, etc.
	 */
	public void setManager() {
		this.setM_OWLOntologyManager(OWLManager.createOWLOntologyManager());
	}

	public OWLDataFactory getM_OWLDataFactory() {
		return m_OWLDataFactory;
	}
	/**
	 * @param m_OWLDataFactory the m_OWLDataFactory to set
	 */
	public void setM_OWLDataFactory(OWLDataFactory m_OWLDataFactory) {
		Ontology.m_OWLDataFactory = m_OWLDataFactory;
	}
	/**
	 * @brief build m_OWLDataFactory
	 */
	public void setM_OWLDataFactory() {
		Ontology.m_OWLDataFactory = getM_OWLOntologyManager().getOWLDataFactory();
	}
	/**
	 * @return the m_kittingWorkstationClasses_IRI
	 */
	public String getM_kittingWorkstationClasses_IRI() {
		return m_kittingWorkstationClasses_IRI;
	}

	/**
	 * @return the m_ActionBaseClass
	 */
	public String getM_ActionBaseClass() {
		return m_owl_class_ActionBase;
	}
	/**
	 * @return the m_outputPDDLFile
	 */
	public String getM_outputPDDLDomainFile() {
		return m_outputPDDLDomainFile;
	}
	/**
	 * @param m_outputPDDLFile the m_outputPDDLFile to set
	 */
	public void setM_outputPDDLDomainFile(String m_outputPDDLFile) {
		this.m_outputPDDLDomainFile = m_outputPDDLFile;
	}
	/**
	 * @return the m_owl_class_Robot
	 */
	public String getM_owl_class_Robot() {
		return m_owl_class_Robot;
	}
	/**
	 * @return the m_owl_class_EndEffectorChangingStation
	 */
	public String getM_owl_class_EndEffectorChangingStation() {
		return m_owl_class_EndEffectorChangingStation;
	}

	/**
	 * @return the m_owl_class_KitTray
	 */
	public String getM_owl_class_KitTray() {
		return m_owl_class_KitTray;
	}
	/**
	 * @return the m_owl_class_LargeBoxWithEmptyKitTrays
	 */
	public String getM_owl_class_LargeBoxWithEmptyKitTrays() {
		return m_owl_class_LargeBoxWithEmptyKitTrays;
	}
	/**
	 * @return the m_owl_class_LargeBoxWithKits
	 */
	public String getM_owl_class_LargeBoxWithKits() {
		return m_owl_class_LargeBoxWithKits;
	}

	/**
	 * @return the m_owl_class_WorkTable
	 */
	public String getM_owl_class_WorkTable() {
		return m_owl_class_WorkTable;
	}
	/**
	 * @return the m_owl_class_PartsTray
	 */
	public String getM_owl_class_PartsTray() {
		return m_owl_class_PartsTray;
	}
	/**
	 * @return the m_owl_class_Part
	 */
	public String getM_owl_class_Part() {
		return m_owl_class_Part;
	}
	/**
	 * @return the m_owl_class_EndEffectorHolder
	 */
	public String getM_owl_class_EndEffectorHolder() {
		return m_owl_class_EndEffectorHolder;
	}

	/**
	 * @return the m_owl_class_EndEffector
	 */
	public String getM_owl_class_EndEffector() {
		return m_owl_class_EndEffector;
	}

	/**
	 * @return the m_owl_class_Kit
	 */
	public String getM_owl_class_Kit() {
		return m_owl_class_Kit;
	}

	/**
	 * @return the m_owl_class_SOAP
	 */
	public String getM_owl_class_SOAP() {
		return m_owl_class_SOAP;
	}
	/**
	 * @return the m_owl_class_Domain
	 */
	public String getM_owl_class_Domain() {
		return m_owl_class_Domain;
	}
	/**
	 * @return the m_owl_class_PositivePredicate
	 */
	public String getM_owl_class_PositivePredicate() {
		return m_owl_class_PositivePredicate;
	}
	/**
	 * @return the m_owl_class_NegativePredicate
	 */
	public String getM_owl_class_NegativePredicate() {
		return m_owl_class_NegativePredicate;
	}
	/**
	 * @return the m_owl_class_Function
	 */
	public String getM_owl_class_Function() {
		return m_owl_class_Function;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionEqual
	 */
	public String getM_owl_class_FunctionToFunctionEqual() {
		return m_owl_class_FunctionToFunctionEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionGreater
	 */
	public String getM_owl_class_FunctionToFunctionGreater() {
		return m_owl_class_FunctionToFunctionGreater;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionGreaterOrEqual
	 */
	public String getM_owl_class_FunctionToFunctionGreaterOrEqual() {
		return m_owl_class_FunctionToFunctionGreaterOrEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionLessOrEqual
	 */
	public String getM_owl_class_FunctionToFunctionLessOrEqual() {
		return m_owl_class_FunctionToFunctionLessOrEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionLess
	 */
	public String getM_owl_class_FunctionToFunctionLess() {
		return m_owl_class_FunctionToFunctionLess;
	}

	/**
	 * @return the m_owl_class_FunctionOperation
	 */
	public String getM_owl_class_FunctionOperation() {
		return m_owl_class_FunctionOperation;
	}

	/**
	 * @return the m_OWLOntologyManager
	 */
	public OWLOntologyManager getM_OWLOntologyManager() {
		return m_OWLOntologyManager;
	}

	/**
	 * @param m_OWLOntologyManager the m_OWLOntologyManager to set
	 */
	public static void setM_OWLOntologyManager(OWLOntologyManager m_OWLOntologyManager) {
		Ontology.m_OWLOntologyManager = m_OWLOntologyManager;
	}

	/**
	 * @return the m_OP_hasSkuObject_Sku
	 */
	public String getM_OP_hasSkuObject_Sku() {
		return m_hasSkuObject_Sku;
	}

	/**
	 * @return the m_OP_hasStockKeepingUnit_EndEffector
	 */
	public String getM_OP_hasStockKeepingUnit_EndEffector() {
		return m_hasStockKeepingUnit_EndEffector;
	}

	/**
	 * @return the m_OP_hasKit_KitTray
	 */
	public String getM_OP_hasKit_KitTray() {
		return m_hasKit_KitTray;
	}

	/**
	 * @return the m_OP_hasKit_Part
	 */
	public String getM_OP_hasKit_Part() {
		return m_hasKit_Part;
	}

	/**
	 * @return the m_OP_hasSolidObject_PrimaryLocation
	 */
	public String getM_OP_hasSolidObject_PrimaryLocation() {
		return m_hasSolidObject_PrimaryLocation;
	}

	/**
	 * @return the m_OP_hasPhysicalLocation_RefObject
	 */
	public String getM_OP_hasPhysicalLocation_RefObject() {
		return m_hasPhysicalLocation_RefObject;
	}


	/**
	 * @return the m_owl_class_FunctionToDecimalEqual
	 */
	public String getM_owl_class_FunctionToDecimalEqual() {
		return m_owl_class_FunctionToDecimalEqual;
	}


	/**
	 * @return the m_owl_class_FunctionToDecimalGreater
	 */
	public String getM_owl_class_FunctionToDecimalGreater() {
		return m_owl_class_FunctionToDecimalGreater;
	}


	/**
	 * @return the m_owl_class_FunctionToDecimalLess
	 */
	public String getM_owl_class_FunctionToDecimalLess() {
		return m_owl_class_FunctionToDecimalLess;
	}


	/**
	 * @return the m_owl_class_FunctionToDecimalGreaterOrEqual
	 */
	public String getM_owl_class_FunctionToDecimalGreaterOrEqual() {
		return m_owl_class_FunctionToDecimalGreaterOrEqual;
	}


	/**
	 * @return the m_owl_class_FunctionToDecimalLessOrEqual
	 */
	public String getM_owl_class_FunctionToDecimalLessOrEqual() {
		return m_owl_class_FunctionToDecimalLessOrEqual;
	}


	/**
	 * @return the m_owl_class_StockKeepingUnit
	 */
	public String getM_owl_class_StockKeepingUnit() {
		return m_owl_class_StockKeepingUnit;
	}

	/**
	 * @return the m_OP_hasLargeBoxWithKits_Kit
	 */
	public String getM_OP_hasLargeBoxWithKits_Kit() {
		return m_hasLargeBoxWithKits_Kit;
	}
}
