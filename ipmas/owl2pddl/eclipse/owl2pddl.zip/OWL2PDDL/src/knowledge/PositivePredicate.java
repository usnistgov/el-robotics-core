/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      PositivePredicate.java
 * @brief     Data structure for PDDL positive predicates.
 * @details PositivePredicate extends Predicate.
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Class to represent a PDDL predicate
 * 
 * @details Consists of data that are used to build PDL predicates. A PDDL predicate consists of:
 * <ul>
 * <li>1 reference parameter
 * <li>0 or 1 target parameter
 * </ul>
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class PositivePredicate extends Predicate {
	/**
	 * @brief A PDDL predicate as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/** @ingroup DP
	 *  @brief Data property hasPositivePredicate_Description
	 */
	private String m_hasPositivePredicate_Description;
	/** @ingroup OP
	 *  @brief Object property m_hasPositivePredicate_ReferenceParameter
	 */
	private String m_hasPositivePredicate_ReferenceParameter;
	/** @ingroup OP
	 *  @brief Object property m_hasPositivePredicate_TargetParameter
	 */
	private String m_hasPositivePredicate_TargetParameter;
	/**
	 * @brief class constructor
	 * @details The constructor sets the value for each object and data property
	 */
	public PositivePredicate() {
		m_hasPositivePredicate_ReferenceParameter="hasPositivePredicate_ReferenceParameter";
		m_hasPositivePredicate_TargetParameter="hasPositivePredicate_TargetParameter";
		m_hasPositivePredicate_Description="hasPositivePredicate_Description";
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_hasPositivePredicate_Description
	 */
	public String getM_hasPositivePredicate_Description() {
		return m_hasPositivePredicate_Description;
	}

	/**
	 * @return the m_hasPositivePredicate_ReferenceParameter
	 */
	public String getM_hasPositivePredicate_ReferenceParameter() {
		return m_hasPositivePredicate_ReferenceParameter;
	}

	/**
	 * @return the m_hasPositivePredicate_TargetParameter
	 */
	public String getM_hasPositivePredicate_TargetParameter() {
		return m_hasPositivePredicate_TargetParameter;
	}

}
