/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      Precondition.java
 * @brief     Data structure for PDDL preconditions
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Class to represent PDDL preconditions
 * 
 * @details A PDDL predicate may consist of a combination of the following:
 * <ul>
 * <li>Predicate types
 * <li>Function types
 * <li>FunctionOperation types
 * <li>FunctionToDecimalBool types
 * <li>FunctionToFunctionBool types
 * </ul>
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Precondition {
	/**
	 * @brief A PDDL precondition as an OWLIndividual
	 */
	private OWLIndividual m_individual;
	/**
	 * @brief A list of String.
	 * @details Each string is the name of a predicate
	 */
	private ArrayList<String> m_predicate_list;
	/**
	 * @brief A list of FunctionToFunctionBool type
	 */
	private ArrayList<FunctionToFunctionBool> m_f2f_list;
	/**
	 * @brief A list of FunctionToDecimalBool type
	 */
	private ArrayList<FunctionToDecimalBool> m_f2d_list;
	/**
	 * @brief A list of FunctionOperation type
	 */
	private ArrayList<FunctionOperation> m_function_operation_list;


	/**
	 * @brief Class constructor
	 */
	public Precondition() {
		m_predicate_list = new ArrayList<String>();
		m_f2f_list = new ArrayList<FunctionToFunctionBool>();
		m_f2d_list = new ArrayList<FunctionToDecimalBool>();
		m_function_operation_list = new ArrayList<FunctionOperation>();
	}

	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}


	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}

	/**
	 * @return the m_predicate_list
	 */
	public ArrayList<String> getM_predicate_list() {
		return m_predicate_list;
	}

	/**
	 * @param m_predicate_list the m_predicate_list to set
	 */
	public void setM_predicate_list(ArrayList<String> m_predicate_list) {
		this.m_predicate_list = m_predicate_list;
	}

	/**
	 * @return the m_f2f_list
	 */
	public ArrayList<FunctionToFunctionBool> getM_f2f_list() {
		return m_f2f_list;
	}

	/**
	 * @param m_f2f_list the m_f2f_list to set
	 */
	public void setM_f2f_list(ArrayList<FunctionToFunctionBool> m_f2f_list) {
		this.m_f2f_list = m_f2f_list;
	}

	/**
	 * @return the m_function_operation_list
	 */
	public ArrayList<FunctionOperation> getM_function_operation_list() {
		return m_function_operation_list;
	}

	/**
	 * @param m_function_operation_list the m_function_operation_list to set
	 */
	public void setM_function_operation_list(
			ArrayList<FunctionOperation> m_function_operation_list) {
		this.m_function_operation_list = m_function_operation_list;
	}

	/**
	 * @return the m_f2d_list
	 */
	public ArrayList<FunctionToDecimalBool> getM_f2d_list() {
		return m_f2d_list;
	}

	/**
	 * @param m_f2d_list the m_f2d_list to set
	 */
	public void setM_f2d_list(ArrayList<FunctionToDecimalBool> m_f2d_list) {
		this.m_f2d_list = m_f2d_list;
	}

}
