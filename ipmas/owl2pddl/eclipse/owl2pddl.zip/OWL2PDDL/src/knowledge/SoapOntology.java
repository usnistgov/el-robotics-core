/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      SoapOntology.java
 * @brief     Data structure for the OWL SOAP file
 */
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @brief Class to represent the OWL SOAP file
 * 
 * @details Consists of data that are used to retrieve information from the OWL SOAP file. The SOAP ontology extends
 * the Java class Ontology
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class SoapOntology extends Ontology {
	private static OWLReasoner m_soapOWLReasoner;
	/**
	 * @brief Path to owl soap instance file
	 */
	private static String m_PathToSoapInstanceFile;

	/**
	 * @brief OWLOntology for the soap instance file
	 */
	private static OWLOntology m_OWLSoapInstanceOntology;
	/**
	 * @brief IRI for soapClasses.owl
	 */
	private static String m_soapClasses_IRI;
	/**
	 * @brief IRI for soapInstances.owl
	 */
	private String m_soapInstances_IRI;

	/**
	 * @brief class constructor
	 */
	public SoapOntology() {
		// TODO Auto-generated constructor stub
		setM_soapClasses_IRI("http://www.nist.gov/el/ontologies/soapClasses.owl#");
		setM_soapInstances_IRI("http://www.nist.gov/el/ontologies/soapInstances.owl#");
	}

	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(progressMonitor);
		//setM_soapOWLReasoner(reasonerFactory.createReasoner(m_OWLSoapInstanceOntology));
		SoapOntology.m_soapOWLReasoner = reasonerFactory.createReasoner(m_OWLSoapInstanceOntology);
	}
	/**
	 * @brief load an OWL file located at @a myPath
	 * @param myPath location of the OWL file
	 */
	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		File file = new File(myPath);

		//-- Set the owl file passed as arguments as the current ontology
		SoapOntology.m_OWLSoapInstanceOntology=getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file);
	}
	/**
	 * @brief build an OWL class from a given String
	 * @details This function creates an OWL class from the String parameter @a myClassName. 
	 * @param myClassName The OWL class as a String
	 * @return OWL class built from the parameter @a myClassName
	 */
	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_soapClasses_IRI().concat(myClassName)));
		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//progressMonitor);
		return myClass;
	}

	/**
	 * @brief retrieve OWL sub classes from a given OWL class (@a myClassName)
	 * @details This function first creates an OWL class from the String parameter @a myClassName. Then, 
	 * the built OWL class is used to retrieve sub classes via getM_soapOWLReasoner().getSubClasses(myClass, true).
	 * @param myClassName The OWL class for which sub classes are to be found
	 * @return A NodeSet<OWLClass> that contains sub classes of @a myClassName
	 */
	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_soapClasses_IRI().concat(":" + myClassName)));
		NodeSet<OWLClass> subclasses_of_myClass = getM_soapOWLReasoner().getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}

	/**
	 * @return the m_PathToSoapInstanceFile
	 */
	public static String getM_PathToSoapInstanceFile() {
		return m_PathToSoapInstanceFile;
	}

	/**
	 * @param m_PathToSoapInstanceFile the m_PathToSoapInstanceFile to set
	 */
	public void setM_PathToSoapInstanceFile(String m_PathToSoapInstanceFile) {
		SoapOntology.m_PathToSoapInstanceFile = m_PathToSoapInstanceFile;
	}

	/**
	 * @return the m_OWLSoapInstanceOntology
	 */
	public OWLOntology getM_OWLSoapInstanceOntology() {
		return m_OWLSoapInstanceOntology;
	}

	/**
	 * @param m_OWLSoapInstanceOntology the m_OWLSoapInstanceOntology to set
	 */
	public static void setM_OWLSoapInstanceOntology(
			OWLOntology m_OWLSoapInstanceOntology) {
		SoapOntology.m_OWLSoapInstanceOntology = m_OWLSoapInstanceOntology;
	}

	/**
	 * @return the m_soapClasses_IRI
	 */
	public String getM_soapClasses_IRI() {
		return m_soapClasses_IRI;
	}

	/**
	 * @param m_soapClasses_IRI the m_soapClasses_IRI to set
	 */
	public static void setM_soapClasses_IRI(String m_soapClasses_IRI) {
		SoapOntology.m_soapClasses_IRI = m_soapClasses_IRI;
	}

	/**
	 * @return the m_soapInstances_IRI
	 */
	public String getM_soapInstances_IRI() {
		return m_soapInstances_IRI;
	}

	/**
	 * @param m_soapInstances_IRI the m_soapInstances_IRI to set
	 */
	public void setM_soapInstances_IRI(String m_soapInstances_IRI) {
		this.m_soapInstances_IRI = m_soapInstances_IRI;
	}

	/**
	 * @return the m_soapOWLReasoner
	 */
	public OWLReasoner getM_soapOWLReasoner() {
		return m_soapOWLReasoner;
	}


}