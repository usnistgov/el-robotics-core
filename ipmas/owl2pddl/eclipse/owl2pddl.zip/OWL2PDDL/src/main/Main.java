/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
\mainpage OWL2PDDL tool

The OWL2PDDL tool is a Java-based application that is capable of reading multiple OWL files to generate PDDL domain and problem files.<br>
The PDDL domain file is generated from the SOAP instance file.<br>
The PDDL problem file is generated from the Init and Goal instance files.
*/
/**
 * \defgroup OWLClasses Definition of OWL classes
 */
/**
 * \defgroup OP Definition of object properties
 */
/**
 * \defgroup DP Definition of data properties
 */
/**
 * \defgroup domain_file Java functions used to create the PDDL domain file
 */
/**
 * \defgroup problem_file Java functions used to create the PDDL problem file
 */
/**
 * @file Main.java
 * @brief contains the main function of the project   
 */
package main;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLException;

import tools.Mapper;
import tools.PathSetter;
import tools.Reader;
import tools.Writer;

import knowledge.GoalOntology;
import knowledge.InitOntology;
import knowledge.Ontology;
import knowledge.SOAP;
import knowledge.SoapOntology;
/**
 * @brief Class that contains the main function of the project
 * 
 * @details The different steps used in the project are:
 * <ol>
 * <li>get paths: EnvVariableSetter.getEnvironmentVariable(String)
 * <ul>
 * <li>The SOAP instance file
 * <li>The Init instance file
 * <li>The Goal instance file
 * <li>The output of the PDDL domain file
 * <li>The ouput of the PDDL problem file
 * </ul>
 * <li>set paths: EnvVariableSetter.EnvVariableSetter()
 * <li>parse SOAP OWL instance file: Reader.parseSOAP(OWLClass)
 * <li>write PDDL domain file: Writer.writeDomainFile(Ontology,SOAP)
 * <li>parse Init and Goal OWL instance files: Mapper.Mapper(SoapOntology,InitOntology,GoalOntology,SOAP)
 * <li>write PDDL problem file: Writer.writeProblemFile(String,String)
 * </ol>
 * \dot
 * digraph G {
 * writeproblem [shape=box,style=filled,color= olivedrab,label="write PDDL problem file"];
 * writedomain [shape=box,style=filled,color=lightblue,label="write PDDL domain file"];
 * main [shape=box];
 * main -> "get paths" -> "set paths"->"parse SOAP OWL file" -> writedomain;
 * "set paths" -> "parse Init OWL file";
 * "parse Init OWL file"->writeproblem;
 * "set paths" -> "parse Goal OWL file"->writeproblem;
 * }
 * \enddot

 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Main {
	public static void main (String[] args) throws MalformedURLException, OWLException, FileNotFoundException, UnsupportedEncodingException {
		if (args.length==1) {
			if (args[0].compareTo("--h")==0){
				System.out.println("\n\n-------------------------------------------------------------------------------------------------------");
				System.out.println("Author: Zeid Kootbally");
				System.out.println("Email: zeid.kootbally@nist.gov");
				System.out.println("National Institute of Standards and Technology");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("This tool reads OWL files and generates PDDL domain and problem files.");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("Usage: java -jar owl2pddl.jar");
				System.out.println("-------------------------------------------------------------------------------------------------------");
			}	
			else{
				System.out.println("\n\n-------------------------------------------------------------------------------------------------------");
				System.out.println("Author: Zeid Kootbally");
				System.out.println("Email: zeid.kootbally@nist.gov");
				System.out.println("National Institute of Standards and Technology");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("This tool reads OWL files and generates PDDL domain and problem files.");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("					ERROR: Unknown argument(s).");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("Usage: java -jar owl2pddl.jar");
				System.out.println("-------------------------------------------------------------------------------------------------------");
			}
		}
		else{
			PathSetter myParser = new PathSetter();
			String owlSoapInstance = myParser.getM_soapInstancePath();
			String owlInitInstance = myParser.getM_initInstancePath();
			String owlGoalInstance = myParser.getM_goalInstancePath();
			String pddlDomain = myParser.getM_domainPath();
			String pddlProblem = myParser.getM_problemPath();

			final SoapOntology mySoapOntology = new SoapOntology();
			mySoapOntology.setM_PathToSoapInstanceFile(owlSoapInstance);
			mySoapOntology.setM_outputPDDLDomainFile(pddlDomain);
		
			mySoapOntology.loadOntologyFromPath(owlSoapInstance);
			mySoapOntology.setReasoner();
			mySoapOntology.setM_OWLDataFactory(mySoapOntology.getM_OWLOntologyManager().getOWLDataFactory());
			
			OWLClass SoapOWLClass = mySoapOntology.getClass(mySoapOntology.getM_owl_class_SOAP()); 

			final Reader myReader = new Reader(mySoapOntology);
			final Writer myWriter = new Writer();
			//-- Parse the Soap ontology starting at SoapClass
			SOAP mySoap = myReader.parseSOAP(SoapOWLClass);
			//-- Display what we have parsed so far
			//myReader.displaySoap(myOntology, mySoap);
			myWriter.writeDomainFile(mySoapOntology, mySoap);


			final InitOntology myInitOntology = new InitOntology();
			myInitOntology.setM_PathToInitInstanceFile(owlInitInstance);
			myInitOntology.loadOntologyFromPath(owlInitInstance);
			myInitOntology.setReasoner();
			myInitOntology.setM_OWLDataFactory(myInitOntology.getM_OWLOntologyManager().getOWLDataFactory());

			final GoalOntology myGoalOntology = new GoalOntology();
			myGoalOntology.setM_PathToGoalInstanceFile(owlGoalInstance);
			myGoalOntology.loadOntologyFromPath(owlGoalInstance);
			myGoalOntology.setReasoner();
			myGoalOntology.setM_OWLDataFactory(myGoalOntology.getM_OWLOntologyManager().getOWLDataFactory());

			Mapper myMapper = new Mapper(mySoapOntology,myInitOntology,myGoalOntology,mySoap);
			myMapper.buildProblemFile();
			myWriter.writeProblemFile(myMapper.getM_problem(), pddlProblem);
		}			
	}
}
