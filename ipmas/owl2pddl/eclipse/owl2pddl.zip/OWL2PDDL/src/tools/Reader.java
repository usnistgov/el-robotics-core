/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
/**
 * @file      Reader.java
 * @brief     Data structure to read information from ontologies and store it in memory
 */
package tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.FunctionOperation;
import knowledge.FunctionToDecimalBool;
import knowledge.FunctionToFunctionBool;
import knowledge.NegativePredicate;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.SOAP;
import knowledge.SoapOntology;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

/**
 * @brief Functions that reads ontologies and stores relevant information in memory.
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Reader {
	private SoapOntology m_SoapOntology;
	private OWLDataFactory m_OWLDataFactory;
	private OWLReasoner m_OWLReasoner;
	private Cleaner m_cleaner;

	/**
	 * @brief Customized constructor
	 */
	public Reader(SoapOntology mySoapOntology) {
		setM_SoapOntology(mySoapOntology);
		m_OWLDataFactory=getM_SoapOntology().getM_OWLDataFactory();
		m_OWLReasoner=getM_SoapOntology().getM_soapOWLReasoner();
		m_cleaner = new Cleaner();
	}

	/**
	 * @brief Builds a list of PositivePredicate type given the OWL class of the positive predicate
	 * @param myPositivePredicateClass The OWL Class of the positive predicate
	 * @return A list of positive predicates
	 */
	private ArrayList<PositivePredicate> parsePositivePredicate(OWLClass myPositivePredicateClass) {
		
		ArrayList<PositivePredicate> l_positive_predicate_list = new ArrayList<PositivePredicate>();

		// -- Instances of the class PositivePredicate
		// -- Setting the flag to false in getInstances(myClass, false)
		// retrieves instances in subclasses of myClass
		// -- setting the flag to true retrieves only instances of the class
		// (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> positivePredicateNodeSet = m_OWLReasoner
				.getInstances(myPositivePredicateClass, false);

		if (!positivePredicateNodeSet.isEmpty()){
			for (OWLNamedIndividual positivePredicate : positivePredicateNodeSet
					.getFlattened()) {
				// -- Create an instance of PositivePredicate
				PositivePredicate myPositivePredicate = new PositivePredicate();
				// -- Set the OWLIndividual
				myPositivePredicate.setM_individual(positivePredicate);
				// -- Set the default reference to empty
				// -- This way allows us to have a value set for the reference
				// parameter
				myPositivePredicate.setM_reference_parameter("");
				// -- Set the default target to empty
				// -- This way allows us to have a value set for the target
				// parameter
				myPositivePredicate.setM_target_parameter("");
				// -- Set the default description to empty
				// -- This way allows us to have a value set for the description
				myPositivePredicate.setM_description("");

				// -- Get all the data properties for each positive predicate
				Map<OWLDataPropertyExpression, Set<OWLLiteral>> positive_predicate_map = positivePredicate
						.getDataPropertyValues(getM_SoapOntology()
								.getM_OWLSoapInstanceOntology());

				// -- build the data properties we need to look for
				OWLDataProperty owldp_reference = m_OWLDataFactory
						.getOWLDataProperty(IRI.create(getM_SoapOntology()
								.getM_soapClasses_IRI()
								.concat(myPositivePredicate
										.getM_hasPositivePredicate_ReferenceParameter())));

				OWLDataProperty owldp_target = m_OWLDataFactory
						.getOWLDataProperty(IRI.create(getM_SoapOntology()
								.getM_soapClasses_IRI()
								.concat(myPositivePredicate
										.getM_hasPositivePredicate_TargetParameter())));

				OWLDataProperty owldp_description = m_OWLDataFactory
						.getOWLDataProperty(IRI.create(getM_SoapOntology()
								.getM_soapClasses_IRI()
								.concat(myPositivePredicate
										.getM_hasPositivePredicate_Description())));

				// -- Assign the reference parameter
				if (positive_predicate_map.get(owldp_reference) != null) {
					for (OWLLiteral d : positive_predicate_map.get(owldp_reference)) {
						myPositivePredicate.setM_reference_parameter(d.getLiteral()
								.toString());
					}
				}

				// -- Assign the target parameter
				if (positive_predicate_map.get(owldp_target) != null) {
					for (OWLLiteral d : positive_predicate_map.get(owldp_target)) {
						myPositivePredicate.setM_target_parameter(d.getLiteral()
								.toString());
					}
				}

				// -- Assign the description
				if (positive_predicate_map.get(owldp_description) != null) {
					for (OWLLiteral d : positive_predicate_map
							.get(owldp_description)) {
						myPositivePredicate.setM_description(d.getLiteral()
								.toString());
					}
				}
				l_positive_predicate_list.add(myPositivePredicate);
			}
		}
		return l_positive_predicate_list;
	}

	/**
	 * @brief Builds a list of NegativePredicate type given the OWL class of the negative predicate
	 * @param myNegativePredicateClass The OWL Class of the negative predicate
	 * @return A list of negative predicates
	 */
	private ArrayList<NegativePredicate> parseNegativePredicate(OWLClass myNegativePredicateClass) {
		
		ArrayList<NegativePredicate> l_negative_predicate_list = new ArrayList<NegativePredicate>();

		// -- Instances of the class NegativePredicate
		// -- Setting the flag to false in getInstances(myClass, false)
		// retrieves instances in subclasses of myClass
		// -- setting the flag to true only retrieves direct instances (not the
		// ones in subclasses)
		NodeSet<OWLNamedIndividual> owlni_negative_predicate_nodeset = m_OWLReasoner
				.getInstances(myNegativePredicateClass, false);
		for (OWLNamedIndividual owlni_negative_predicate : owlni_negative_predicate_nodeset
				.getFlattened()) {
			// -- Create an instance of NegativePredicate
			NegativePredicate predicate = new NegativePredicate();
			// -- Set the OWLIndividual
			predicate.setM_individual(owlni_negative_predicate);

			// -- Get the parent OWL class for owlni_negative_predicate
			// -- This is necessary to build the object property
			Set<OWLClassExpression> predicateClass = owlni_negative_predicate
					.getTypes(getM_SoapOntology()
							.getM_OWLSoapInstanceOntology());

			// -- build the object property based on the class of
			// predicateInstance
			OWLObjectProperty owl_op_positivePredicate = m_OWLDataFactory
					.getOWLObjectProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							+ "has"
							+ m_cleaner.cleanIRI(predicateClass)
							+ "_PositivePredicate"));

			NodeSet<OWLNamedIndividual> owlni_positive_predicate_nodeset = m_OWLReasoner
					.getObjectPropertyValues(owlni_negative_predicate,
							owl_op_positivePredicate);
			for (OWLNamedIndividual owlni_positive_predicate : owlni_positive_predicate_nodeset
					.getFlattened())
				predicate.setM_positive_predicate(owlni_positive_predicate);

			l_negative_predicate_list.add(predicate);
			// System.out.println("predicate: "+myOntology.cleanIRI(predicateInstance)+" : "+myOntology.cleanIRI(predicateClass));
		}
		return l_negative_predicate_list;
	}

	/**
	 * @brief Builds a list of Function type given the OWL class of the function
	 * @param myFunctionClass The OWL Class of the function
	 * @return A list of functions
	 */
	private ArrayList<Function> parseFunction(OWLClass myFunctionClass) {
		ArrayList<Function> l_function_list = new ArrayList<Function>();

		// -- Instances of the class NegativePredicate
		// -- Setting the flag to false in getInstances(myClass, false)
		// retrieves instances in subclasses of myClass
		// -- setting the flag to true only retrieves direct instances (not the
		// ones in subclasses)
		NodeSet<OWLNamedIndividual> functionNodeSet = m_OWLReasoner
				.getInstances(myFunctionClass, false);
		for (OWLNamedIndividual functionInstance : functionNodeSet
				.getFlattened()) {
			// -- Create an instance of Function
			Function function = new Function();
			// -- Set the OWLIndividual for function
			function.setM_individual(functionInstance);
			// -- Set the default reference to empty
			// -- This way allows us to have a reference parameter, even if it's
			// empty
			function.setM_reference_parameter("");
			// -- Set the default target to empty
			// -- This way allows us to have a target parameter, even if it's
			// empty
			function.setM_target_parameter("");
			// -- Set the default description to empty
			// -- This way allows us to have a description, even if it's empty
			function.setM_description("");

			// -- Get all the data properties for each function
			Map<OWLDataPropertyExpression, Set<OWLLiteral>> function_map = functionInstance
					.getDataPropertyValues(getM_SoapOntology()
							.getM_OWLSoapInstanceOntology());

			// -- build the data properties we need to look for
			// -- Data property to get the reference parameter
			OWLDataProperty reference_dp = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							.concat(function
									.getM_hasFunction_ReferenceParameter())));
			// -- Data property to get the target parameter
			OWLDataProperty target_dp = m_OWLDataFactory.getOWLDataProperty(IRI
					.create(getM_SoapOntology().getM_soapClasses_IRI().concat(
							function.getM_hasFunction_TargetParameter())));
			// -- Data property to get the description
			OWLDataProperty description_dp = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI().concat(
									function.getM_hasFunction_Description())));
			// -- Find and Assign the reference parameter
			if (function_map.get(reference_dp) != null) {
				for (OWLLiteral d : function_map.get(reference_dp)) {
					function.setM_reference_parameter(d.getLiteral().toString());
				}
			}
			// -- Find and assign the target parameter
			if (function_map.get(target_dp) != null) {
				for (OWLLiteral d : function_map.get(target_dp)) {
					function.setM_target_parameter(d.getLiteral().toString());
				}
			}
			// -- Find and assign the description
			if (function_map.get(description_dp) != null) {
				for (OWLLiteral d : function_map.get(description_dp)) {
					function.setM_description(d.getLiteral().toString());
				}
			}
			l_function_list.add(function);
		}
		return l_function_list;
	}

	/**
	 * @brief Find all the requirements for a given Domain
	 * @param myDomain
	 *            The domain for which we are looking the requirements
	 * @return A list of requirements
	 */
	private ArrayList<String> parseDomainRequirement(Domain myDomain) {
		ArrayList<String> l_requirement = new ArrayList<String>();
		OWLDataProperty requirement_dp = m_OWLDataFactory
				.getOWLDataProperty(IRI.create(getM_SoapOntology()
						.getM_soapClasses_IRI().concat(
								myDomain.getM_DPhasDomain_Requirement())));

		OWLIndividual domainIndividual = myDomain.getM_individual();
		Map<OWLDataPropertyExpression, Set<OWLLiteral>> domainDataPropertyValues = domainIndividual
				.getDataPropertyValues(getM_SoapOntology()
						.getM_OWLSoapInstanceOntology());

		if (domainDataPropertyValues.get(requirement_dp) != null) {
			for (OWLLiteral d : domainDataPropertyValues.get(requirement_dp)) {
				// System.out.println(d.getLiteral());
				l_requirement.add(d.getLiteral().toString());
			}
		}
		return l_requirement;
	}

	/**
	 * @brief Find all the variables for a given Domain
	 * @param myDomain
	 *            The domain for which we are looking the variables
	 * @return A list of variables
	 */
	private ArrayList<String> parseDomainVariable(Domain myDomain) {
		ArrayList<String> l_variable = new ArrayList<String>();
		OWLDataProperty variable = m_OWLDataFactory.getOWLDataProperty(IRI
				.create(getM_SoapOntology().getM_soapClasses_IRI().concat(
						myDomain.getM_DPhasDomain_Variable())));

		OWLIndividual domainIndividual = myDomain.getM_individual();
		Map<OWLDataPropertyExpression, Set<OWLLiteral>> domainDataPropertyValues = domainIndividual
				.getDataPropertyValues(getM_SoapOntology()
						.getM_OWLSoapInstanceOntology());

		if (domainDataPropertyValues.get(variable) != null) {
			for (OWLLiteral d : domainDataPropertyValues.get(variable)) {
				// System.out.println(d.getLiteral());
				l_variable.add(d.getLiteral().toString());
			}
		}
		return l_variable;
	}

	/**
	 * @brief Parse the domain and retrieve all the object and data properties
	 * @param mySoap
	 * @param mySoapInstance
	 * @return
	 */
	private Domain parseDomain(SOAP mySoap, OWLNamedIndividual mySoapInstance) {
		OWLClass positivePredicateOWLClass = getM_SoapOntology().getClass(
				getM_SoapOntology().getM_owl_class_PositivePredicate());
		OWLClass negativePredicateOWLClass = getM_SoapOntology().getClass(
				getM_SoapOntology().getM_owl_class_NegativePredicate());
		OWLClass functionOWLClass = getM_SoapOntology().getClass(
				getM_SoapOntology().getM_owl_class_Function());
		OWLClass actionBaseOWLClass = getM_SoapOntology().getClass(
				getM_SoapOntology().getM_ActionBaseClass());
		Domain domain = new Domain();

		String l_OPhasSOAP_Domain = mySoap.getM_OPhasSOAP_Domain();
		OWLObjectProperty owlObjectProperty = m_OWLDataFactory
				.getOWLObjectProperty(IRI.create(getM_SoapOntology()
						.getM_soapClasses_IRI() + l_OPhasSOAP_Domain));
		// System.out.println("Action: "+l_hasAction_Precondition);

		// -- Individuals for "hasDomain_CreateKit"
		NodeSet<OWLNamedIndividual> DomainNodeSet = m_OWLReasoner
				.getObjectPropertyValues(mySoapInstance, owlObjectProperty);
		for (OWLNamedIndividual domainIndividual : DomainNodeSet.getFlattened()) {
			// System.out.println("domain: "+myOntology.cleanIRI(domainIndividual));
			domain.setM_individual(domainIndividual);
			// -- Get the requirements for the domain
			// parseDomainRequirement(myOntology, domain);
			domain.setM_requirement_list(parseDomainRequirement(domain));
			// -- Get the variables for the domain
			domain.setM_variable_list(parseDomainVariable(domain));
			// -- Get the positive predicates
			domain.setM_positive_predicate_list(parsePositivePredicate(positivePredicateOWLClass));
			// -- Get the negative predicates
			domain.setM_negative_predicate_list(parseNegativePredicate(negativePredicateOWLClass));
			// -- Get the functions
			domain.setM_function_list(parseFunction(functionOWLClass));
			// -- Get the actions
			domain.setM_action_list(parseActionBase(actionBaseOWLClass, domain));
			// parseActionBase(actionBaseOWLClass, myOntology, domain);

		}
		return domain;
	}

	/**
	 * @brief Parse the soap ontology starting from the OWL class SOAP.
	 * @param myClass
	 */
	public SOAP parseSOAP(OWLClass myClass) {
		SOAP soap = new SOAP();

		// -- Instances of the class SOAP
		// -- Setting the flag to false in getInstances(myClass, false)
		// retrieves instances in subclasses of myClass
		// -- setting the flag to true only retrieves direct instances (not the
		// ones in subclasses)
		NodeSet<OWLNamedIndividual> owlni_soap_nodeset = m_OWLReasoner
				.getInstances(myClass, true);

		for (OWLNamedIndividual owlni_soap : owlni_soap_nodeset.getFlattened()) {
			soap.setM_individual(owlni_soap);
			// -- Get the domain for soapInstance
			soap.setM_domain(parseDomain(soap, owlni_soap));
		}
		return soap;
	}

	

	private ArrayList<Action> parseActionBase(OWLClass myClass, Domain domain) {
		ArrayList<Action> l_action_list = new ArrayList<Action>();

		// -- Instances of the class ActionBase
		// -- Setting the flag to false in getInstances(myClass, false)
		// retrieves instances in subclasses of myClass
		// -- setting the flag to true only retrieves direct instances (not the
		// ones in subclasses)
		NodeSet<OWLNamedIndividual> ActionBaseNodeSet = m_OWLReasoner
				.getInstances(myClass, false);

		for (OWLNamedIndividual owlni_action : ActionBaseNodeSet.getFlattened()) {
			Action action = new Action();
			action.setM_individual(owlni_action);
			// -- Get the direct class of ActionBaseInstance
			// -- This is used to build the object property "has_<Class of
			// ActionBaseInstance>_Precondition and
			// -- "has_<Class of ActionBaseInstance>_Effect
			Precondition precondition = findPrecondition(owlni_action);
			Effect effect = findEffect(owlni_action);
			ArrayList<String> l_parameter_set = findActionParameterSet(action);

			// -- Set action's parameter_set
			action.setM_parameter_set(l_parameter_set);
			// -- Set action's precondition
			action.setM_action_precondition(precondition);
			// -- Set action's effect
			action.setM_action_effect(effect);
			// -- Add current action to l_action_list
			l_action_list.add(action);
		}
		return l_action_list;
	}

	private ArrayList<String> findActionParameterSet(Action myAction) {
		Map<Integer, String> parameterSet_map = new HashMap<Integer, String>();
		Set<OWLClassExpression> actionClass = myAction.getM_individual()
				.getTypes(getM_SoapOntology().getM_OWLSoapInstanceOntology());
		OWLNamedIndividual action_individual = myAction.getM_individual();

		String l_hasAction_ParameterSet = "has"
				+ m_cleaner.cleanIRI(actionClass)
				+ "_ActionParameterSet";
		// System.out.println("l_hasAction_ParameterSet: "+l_hasAction_ParameterSet);
		OWLObjectProperty owl_op_parameter_set = m_OWLDataFactory
				.getOWLObjectProperty(IRI.create(getM_SoapOntology()
						.getM_soapClasses_IRI() + l_hasAction_ParameterSet));

		NodeSet<OWLNamedIndividual> ActionParameterSetNodeSet = m_OWLReasoner
				.getObjectPropertyValues(action_individual,
						owl_op_parameter_set);

		// -- For each action parameter set for the current action
		for (OWLNamedIndividual oni_parameter_set : ActionParameterSetNodeSet
				.getFlattened()) {

			// System.out.println("action parameter set: "+myOntology.cleanIRI(oni_parameter_set));
			// -- Retrieve the parameter
			// -- Get all the data properties for each function
			Map<OWLDataPropertyExpression, Set<OWLLiteral>> dataPropertyValues = oni_parameter_set
					.getDataPropertyValues(getM_SoapOntology()
							.getM_OWLSoapInstanceOntology());

			// -- build the data properties we need to look for
			OWLDataProperty odp_parameter = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							.concat(myAction
									.getM_OP_hasActionParameterSet_ActionParameter())));
			OWLDataProperty odp_position = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							.concat(myAction
									.getM_OP_hasActionParameterSet_ActionParameterPosition())));

			// -- store the parameter and its position in a Map<Integer,String>
			// -- The map will be read later to place the parameter at the right
			// position in a list
			if (dataPropertyValues.get(odp_parameter) != null) {
				for (OWLLiteral d : dataPropertyValues.get(odp_parameter)) {
					// System.out.println("  +parameter: "+d.getLiteral().toString());
					// -- Get the position
					if (dataPropertyValues.get(odp_position) != null) {
						for (OWLLiteral d1 : dataPropertyValues
								.get(odp_position)) {
							String positionString = d1.getLiteral().toString();
							// -- Convert the string into Integer
							int positionInt = Integer.parseInt(positionString);
							// System.out.println("  +position: "+positionInt);
							parameterSet_map.put(positionInt, d.getLiteral()
									.toString());
							// l_parameter_set.add(positionInt-1,d.getLiteral().toString());

						}
					}

				}
			}

		}
		// return parameterSet_map;

		int map_size = parameterSet_map.size();

		// -- Create an arraylist of size map_size
		ArrayList<String> parameter_list = new ArrayList<String>(map_size);
		// -- Initialize this list
		// for (int i=0; i<map_size; i++){
		// System.out.println("i:"+i);
		// parameter_list.add("");
		// }
		// System.out.println("Size of list 1: "+parameter_list.size());
		// -- Iterate through parameterSet_map and place each parameter at its
		// position in parameter_list
		Iterator<Entry<Integer, String>> it = parameterSet_map.entrySet()
				.iterator();
		while (it.hasNext()) {

			Entry<Integer, String> pairs = it.next();
			parameter_list.add((String) pairs.getValue());
			it.remove(); // avoids a ConcurrentModificationException
		}

		// -- Set action's parameter list
		return (parameter_list);
	}

	/**
	 * @brief Retrieves the precondition OWLNamedIndividual of an action
	 * 
	 * @param myAction The action for which the precondition is retrieved
	 * @return The precondition for the action @a myAction
	 */
	private Precondition findPrecondition(OWLNamedIndividual myAction) {
		Set<OWLClassExpression> actionClass = myAction
				.getTypes(getM_SoapOntology().getM_OWLSoapInstanceOntology());
		String l_soapClasses_IRI = getM_SoapOntology().getM_soapClasses_IRI();
		Precondition precondition = new Precondition();

		// -- Build the object property that points to the precondition
		String l_hasAction_precondition = "has"
				+ m_cleaner.cleanIRI(actionClass) + "_Precondition";
		OWLObjectProperty op_precondition = m_OWLDataFactory
				.getOWLObjectProperty(IRI.create(l_soapClasses_IRI
						+ l_hasAction_precondition));

		// -- Individuals for "hasAction_Precondition"
		NodeSet<OWLNamedIndividual> ActionPreconditionNodeSet = m_OWLReasoner
				.getObjectPropertyValues(myAction, op_precondition);
		for (OWLNamedIndividual named_indiv_precondition : ActionPreconditionNodeSet
				.getFlattened()) {

			precondition.setM_individual(named_indiv_precondition);
			// -- Get the object property values for named_indiv_precondition
			parsePreconditionObjectPropertyValues(precondition);

		}
		return precondition;
	}

	private ArrayList<FunctionToFunctionBool> lookForF2FBool(String superClass_s,String currentClass_s,OWLIndividual d){
		ArrayList<FunctionToFunctionBool> l_f2f_list = new ArrayList<FunctionToFunctionBool>();
		
		
		
		// -----------------------------------------------------
		// -- Look for FunctionToFunctionBool
		// -----------------------------------------------------
		if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionGreaterOrEqual()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionGreater()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionEqual()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionLessOrEqual()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionLess()) == 0) {
			//System.out.println(superClass_s);
			//System.out.println(currentClass_s);
			String expression="";
			FunctionToFunctionBool f2f = new FunctionToFunctionBool();

			//-- Build the object property to get the first function
			String op1 = "has" + currentClass_s + "_F1";
			//-- Create the object property to get the first function
			OWLObjectProperty op_f1 = m_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_SoapOntology().getM_soapClasses_IRI()+ op1));
			NodeSet<OWLNamedIndividual> function1NodeSet = m_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d, op_f1);
			if (!function1NodeSet.isEmpty()){
				for (OWLNamedIndividual function1 : function1NodeSet.getFlattened()) {
					//System.out.println(oni_f1);
					f2f.setF1(m_cleaner.cleanIRI(function1));
				}
			}
			// -- get the second function
			String op2 = "has" + currentClass_s + "_F2";
			OWLObjectProperty op_f2 = m_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_SoapOntology().getM_soapClasses_IRI()+ op2));
			NodeSet<OWLNamedIndividual> function2NodeSet = m_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d, op_f2);
			if (!function2NodeSet.isEmpty()){
				for (OWLNamedIndividual function2 : function2NodeSet.getFlattened()) {
					//System.out.println(oni_f2);
					f2f.setF2(m_cleaner.cleanIRI(function2));
				}
			}

			if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionGreaterOrEqual()) == 0)
				expression=">=";
			else if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionGreater()) == 0)
				expression=">";
			else if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionEqual()) == 0)
				expression="=";
			else if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionLessOrEqual()) == 0)
				expression="<=";
			else if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToFunctionLess()) == 0)
				expression="<";

			f2f.setExpression(expression);

			l_f2f_list.add(f2f);
			//System.out.println(l_f2f_list);
			//System.out.println("list 1");
			//for (int i=0; i<l_f2f_list.size(); i++){
			//	System.out.println(l_f2f_list.get(i).getF1());
			//	System.out.println(l_f2f_list.get(i).getF2());
			//	System.out.println(l_f2f_list.get(i).getExpression());
			//}
			//System.out.println("list 1: "+l_f2f_list);
		}
		return l_f2f_list;
	}
	
	private ArrayList<FunctionOperation> lookForFunctionOperation(String superClass_s,String currentClass_s,OWLIndividual d){
		ArrayList<FunctionOperation> l_function_operation_list = new ArrayList<FunctionOperation>();
		
		if (superClass_s.compareTo(getM_SoapOntology()
				.getM_owl_class_FunctionOperation()) == 0) {
			FunctionOperation function_operation = new FunctionOperation();

			function_operation.setM_individual(d);

			// --Get the function
			// -- Build object predicate
			// hasFunctionOperation_Function
			String oop_s = "has" + currentClass_s + "_Function";
			OWLObjectProperty oop = m_OWLDataFactory
					.getOWLObjectProperty(IRI
							.create(getM_SoapOntology()
									.getM_soapClasses_IRI()
									+ oop_s));
			NodeSet<OWLNamedIndividual> oni_function_nodeset = m_OWLReasoner
					.getObjectPropertyValues(
							(OWLNamedIndividual) d, oop);
			for (OWLNamedIndividual oni_function : oni_function_nodeset
					.getFlattened()) {
				// System.out.println(oni_f1);
				function_operation
				.setM_function(m_cleaner.cleanIRI(oni_function));
			}

			// -- Get all the data properties for
			Map<OWLDataPropertyExpression, Set<OWLLiteral>> dp_values = d
					.getDataPropertyValues(getM_SoapOntology()
							.getM_OWLSoapInstanceOntology());

			// --Get the Value
			// -- build the data properties for Value
			OWLDataProperty dp_value = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							.concat(function_operation
									.getM_hasFunctionOperation_Value())));
			// -- Retrieve the value
			if (dp_values.get(dp_value) != null) {
				for (OWLLiteral owl_literal : dp_values
						.get(dp_value)) {
					String value_s = owl_literal.getLiteral()
							.toString();
					int value_i = Integer.parseInt(value_s);
					function_operation.setM_value(value_i);
				}
			}

			// --Get the Expression
			// -- build the data properties for Expression
			OWLDataProperty dp_expression = m_OWLDataFactory
					.getOWLDataProperty(IRI.create(getM_SoapOntology()
							.getM_soapClasses_IRI()
							.concat(function_operation
									.getM_hasFunctionOperation_Expression())));
			// -- Retrieve the expression
			if (dp_values.get(dp_expression) != null) {
				for (OWLLiteral owl_literal : dp_values
						.get(dp_expression)) {
					String expression_s = owl_literal
							.getLiteral().toString();
					function_operation
					.setM_expression(expression_s);
				}
			}

			l_function_operation_list.add(function_operation);
		}
		
		return l_function_operation_list;
	}
	
	private ArrayList<FunctionToDecimalBool> lookForFunctionToDecimalBool(String superClass_s,String currentClass_s,OWLIndividual d){
		ArrayList<FunctionToDecimalBool> l_f2d_list = new ArrayList<FunctionToDecimalBool>();
		String expression = "";
		
		if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalLess()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalLessOrEqual()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalGreater()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalGreaterOrEqual()) == 0 ||
				superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalEqual()) == 0 ) {
			//System.out.println(d.toStringID());
			FunctionToDecimalBool f2dBool = new FunctionToDecimalBool();
			
			// -- get the function
			String op1 = "has" + currentClass_s + "_F1";
			OWLObjectProperty op_f1 = m_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_SoapOntology().getM_soapClasses_IRI()+ op1));
			NodeSet<OWLNamedIndividual> oni_f1_nodeset = m_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d, op_f1);
			for (OWLNamedIndividual oni_f1 : oni_f1_nodeset
					.getFlattened()) {
				//System.out.println(oni_f1);
				f2dBool.setF1(m_cleaner.cleanIRI(oni_f1));
			}
			// -- get the decimal
			// -- Get all the data properties for
			Map<OWLDataPropertyExpression, Set<OWLLiteral>> dp_values = d.getDataPropertyValues(getM_SoapOntology().getM_OWLSoapInstanceOntology());
			String decimal_dp = f2dBool.getM_DP_hasFunctionToDecimalBool_DecimalNumber();
			OWLDataProperty owl_decimal_dp = m_OWLDataFactory.getOWLDataProperty(IRI.create(getM_SoapOntology().getM_soapClasses_IRI().concat(decimal_dp)));

			// -- Retrieve the decimal
			if (dp_values.get(owl_decimal_dp) != null) {
				for (OWLLiteral owl_literal : dp_values
						.get(owl_decimal_dp)) {
					String decimal_s = owl_literal
							.getLiteral().toString();
					//System.out.println(decimal_s);
					f2dBool.setD1(decimal_s);
				}
			}
			
			//-- Build the expression
			if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalLess()) == 0)
				expression="<";
			else if(superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalLessOrEqual()) == 0)
				expression="<=";
				else if(superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalGreater()) == 0)
					expression=">";
					else if(superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalGreaterOrEqual()) == 0)
						expression=">=";
						else if(superClass_s.compareTo(getM_SoapOntology().getM_owl_class_FunctionToDecimalEqual()) == 0)
							expression="=";
				
			
			// -- Set the expression
			f2dBool.setExpression(expression);

			// -- Add f2fLess to l_f2f_list
			l_f2d_list.add(f2dBool);
		}
		return l_f2d_list;
	}
	
	private void parsePreconditionObjectPropertyValues(
			Precondition myPrecondition) {
		ArrayList<String> l_predicate_list = new ArrayList<String>();
		ArrayList<FunctionToFunctionBool> l_f2f_list = new ArrayList<FunctionToFunctionBool>();
		ArrayList<FunctionToDecimalBool> l_f2d_list = new ArrayList<FunctionToDecimalBool>();
		ArrayList<FunctionOperation> l_function_operation_list = new ArrayList<FunctionOperation>();

		Map<OWLObjectPropertyExpression, Set<OWLIndividual>> precondition_opv = myPrecondition
				.getM_individual().getObjectPropertyValues(
						getM_SoapOntology().getM_OWLSoapInstanceOntology());

		// -- Get all the object property values for precondition_opv
		for (OWLObjectPropertyExpression prop : precondition_opv.keySet()) {

			for (OWLIndividual d : precondition_opv.get(prop)) {
				// Set<OWLClassExpression> myClass =
				// d.getTypes(myOntology.getM_OWLSoapInstanceOntology());
				// System.out.println("\nobject property: "+d.toStringID());

				// get types
				for (OWLClassExpression c : d.getTypes(getM_SoapOntology()
						.getM_OWLSoapInstanceOntology())) {
					OWLClass currentClass = c.asOWLClass();
					String currentClass_s = m_cleaner.cleanIRI(
							c.asOWLClass());
					NodeSet<OWLClass> superClassesNodeSet = m_OWLReasoner
							.getSuperClasses(currentClass, true);

					// System.out.println("class: "+c.asOWLClass().toStringID());
					for (OWLClass oc : superClassesNodeSet.getFlattened()) {
						String superClass_s = m_cleaner.cleanIRI(
								oc.toStringID());

						// System.out.println("super class: "+superClass_s);

						// -----------------------------------------------------
						// -- Add the predicates to l_predicate_list
						// -----------------------------------------------------
						if (superClass_s.compareTo(getM_SoapOntology().getM_owl_class_PositivePredicate()) == 0 || 
								superClass_s.compareTo(getM_SoapOntology().getM_owl_class_NegativePredicate()) == 0) {
							l_predicate_list.add(m_cleaner.cleanIRI(d.toStringID()));
						}

						// -----------------------------------------------------
						// -- Look for FunctionOperation
						// -----------------------------------------------------
						ArrayList<FunctionOperation> myFunctionOperationList = lookForFunctionOperation(superClass_s,currentClass_s,d);
						l_function_operation_list.addAll(myFunctionOperationList);
						
						// -----------------------------------------------------
						// -- Look for FunctionToDecimalBool
						// -----------------------------------------------------
						ArrayList<FunctionToDecimalBool> myFunctionToDecimalList = lookForFunctionToDecimalBool(superClass_s,currentClass_s,d);
						l_f2d_list.addAll(myFunctionToDecimalList);
						
						// -----------------------------------------------------
						// -- Look for FunctionToFunctionBool
						// -----------------------------------------------------
						ArrayList<FunctionToFunctionBool> myFunctionToFunctionBoolList = lookForF2FBool(superClass_s,currentClass_s,d);
						l_f2f_list.addAll(myFunctionToFunctionBoolList);
					}
				}
			}
		}
		myPrecondition.setM_predicate_list(l_predicate_list);
		myPrecondition.setM_f2f_list(l_f2f_list);
		myPrecondition.setM_f2d_list(l_f2d_list);
		myPrecondition.setM_function_operation_list(l_function_operation_list);
	}

	/**
	 * Retrieve the precondition OWLNamedIndividual for the action @a action
	 * 
	 * @param myAction
	 * @return The precondition for the action @a myAction
	 */
	private Effect findEffect(OWLNamedIndividual myAction) {
		Set<OWLClassExpression> actionClass = myAction
				.getTypes(getM_SoapOntology().getM_OWLSoapInstanceOntology());
		String l_soapClasses_IRI = getM_SoapOntology().getM_soapClasses_IRI();
		Effect effect = new Effect();

		// -- Build the object property that points to the effect
		String l_hasAction_effect = "has"
				+ m_cleaner.cleanIRI(actionClass) + "_Effect";
		OWLObjectProperty op_effect = m_OWLDataFactory.getOWLObjectProperty(IRI
				.create(l_soapClasses_IRI + l_hasAction_effect));

		// -- Individuals for "hasAction_Effect"
		NodeSet<OWLNamedIndividual> ActionEffectNodeSet = m_OWLReasoner
				.getObjectPropertyValues(myAction, op_effect);
		for (OWLNamedIndividual named_indiv_effect : ActionEffectNodeSet
				.getFlattened()) {

			effect.setM_individual(named_indiv_effect);
			// -- Get the object property values for named_indiv_effect
			parseEffectObjectPropertyValues(effect);

		}
		return effect;
	}

	private void parseEffectObjectPropertyValues(Effect myEffect) {
		ArrayList<String> l_predicate_list = new ArrayList<String>();
		ArrayList<FunctionToFunctionBool> l_f2f_list = new ArrayList<FunctionToFunctionBool>();
		ArrayList<FunctionToDecimalBool> l_f2d_list = new ArrayList<FunctionToDecimalBool>();
		ArrayList<FunctionOperation> l_function_operation_list = new ArrayList<FunctionOperation>();

		
		Map<OWLObjectPropertyExpression, Set<OWLIndividual>> effect_opv = myEffect
				.getM_individual().getObjectPropertyValues(
						getM_SoapOntology().getM_OWLSoapInstanceOntology());

		// -- Get all the object property values for effect_opv
		for (OWLObjectPropertyExpression prop : effect_opv.keySet()) {

			for (OWLIndividual d : effect_opv.get(prop)) {
				// Set<OWLClassExpression> myClass =
				// d.getTypes(myOntology.getM_OWLSoapInstanceOntology());
				// System.out.println("\nobject property: "+d.toStringID());

				// get types
				for (OWLClassExpression c : d.getTypes(getM_SoapOntology()
						.getM_OWLSoapInstanceOntology())) {
					OWLClass currentClass = c.asOWLClass();
					String currentClass_s = m_cleaner.cleanIRI(
							c.asOWLClass());
					NodeSet<OWLClass> superClassesNodeSet = m_OWLReasoner
							.getSuperClasses(currentClass, true);

					// System.out.println("class: "+c.asOWLClass().toStringID());
					for (OWLClass oc : superClassesNodeSet.getFlattened()) {
						String superClass_s = m_cleaner.cleanIRI(
								oc.toStringID());

						// System.out.println("super class: "+superClass_s);

						// -----------------------------------------------------
						// -- Add the predicates to l_predicate_list
						// -----------------------------------------------------
						if (superClass_s.compareTo(getM_SoapOntology()
								.getM_owl_class_PositivePredicate()) == 0
								|| superClass_s.compareTo(getM_SoapOntology()
										.getM_owl_class_NegativePredicate()) == 0) {
							l_predicate_list.add(m_cleaner.cleanIRI(
									d.toStringID()));
						}

						// -----------------------------------------------------
						// -- Look for FunctionOperation
						// -----------------------------------------------------
						ArrayList<FunctionOperation> myFunctionOperationList = lookForFunctionOperation(superClass_s,currentClass_s,d);
						l_function_operation_list.addAll(myFunctionOperationList);
						
						// -----------------------------------------------------
						// -- Look for FunctionToDecimalBool
						// -----------------------------------------------------
						ArrayList<FunctionToDecimalBool> myFunctionToDecimalList = lookForFunctionToDecimalBool(superClass_s,currentClass_s,d);
						l_f2d_list.addAll(myFunctionToDecimalList);

						// -----------------------------------------------------
						// -- Look for FunctionToFunctionBool
						// -----------------------------------------------------
						ArrayList<FunctionToFunctionBool> myList = lookForF2FBool(superClass_s,currentClass_s,d);
						l_f2f_list.addAll(myList);
					}
				}
			}
		}
		myEffect.setM_predicate_list(l_predicate_list);
		myEffect.setM_f2f_list(l_f2f_list);
		myEffect.setM_f2d_list(l_f2d_list);
		myEffect.setM_function_operation_list(l_function_operation_list);
	}

	/**
	 * @return the m_SoapOntology
	 */
	public SoapOntology getM_SoapOntology() {
		return m_SoapOntology;
	}

	/**
	 * @param m_SoapOntology
	 *            the m_SoapOntology to set
	 */
	public void setM_SoapOntology(SoapOntology m_SoapOntology) {
		this.m_SoapOntology = m_SoapOntology;
	}
}
