var searchData=
[
  ['knowledge',['knowledge',['../namespaceknowledge.html',1,'']]]
];
