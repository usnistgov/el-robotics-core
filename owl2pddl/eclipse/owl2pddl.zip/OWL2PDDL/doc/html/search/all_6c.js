var searchData=
[
  ['loadontologyfrompath',['loadOntologyFromPath',['../classknowledge_1_1_ontology.html#ace0c03f2e23b41a0ee813b570e1d5072',1,'knowledge::Ontology']]],
  ['lookforfunction',['lookForFunction',['../classtools_1_1_writer.html#ac360af7290a15366baa153dbaa03b797',1,'tools::Writer']]],
  ['lookforpositivepredicate',['lookForPositivePredicate',['../classtools_1_1_writer.html#ad9cbc86d32a7126746825d1953d3f4bc',1,'tools::Writer']]]
];
