var searchData=
[
  ['effect',['Effect',['../classknowledge_1_1_effect.html',1,'knowledge']]]
];
