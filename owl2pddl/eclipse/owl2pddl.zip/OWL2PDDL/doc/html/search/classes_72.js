var searchData=
[
  ['reader',['Reader',['../classtools_1_1_reader.html',1,'tools']]]
];
