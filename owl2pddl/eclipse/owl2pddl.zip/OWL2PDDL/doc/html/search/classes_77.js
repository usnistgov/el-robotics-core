var searchData=
[
  ['writer',['Writer',['../classtools_1_1_writer.html',1,'tools']]]
];
