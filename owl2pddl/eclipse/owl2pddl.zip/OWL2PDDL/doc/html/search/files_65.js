var searchData=
[
  ['effect_2ejava',['Effect.java',['../_effect_8java.html',1,'']]]
];
