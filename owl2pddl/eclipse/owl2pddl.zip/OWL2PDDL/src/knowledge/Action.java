/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLNamedIndividual;

/*! Class to represent PDDL actions */
/**
 * @author zeid
 *
 */
public class Action {
	/**
	 * @brief Object property hasActionParameterSet_ActionParameter
	 */
	private String m_OP_hasActionParameterSet_ActionParameter;
	/**
	 * @brief Object property hasActionParameterSet_ActionParameterPosition
	 */
	private String m_OP_hasActionParameterSet_ActionParameterPosition;

	/**
	 * @brief Action's precondition 
	 */
	private static OWLNamedIndividual m_precondition;
	/**
	 * @brief Action's effect
	 */
	private static OWLNamedIndividual m_effect;
	private OWLNamedIndividual m_individual;
	private Precondition m_action_precondition;
	private Effect m_action_effect;
	private ArrayList<String> m_parameter_set;
	/**
	 * 
	 */
	public Action() {
		m_parameter_set = new ArrayList<String>();
		setM_OP_hasActionParameterSet_ActionParameter("hasActionParameterSet_ActionParameter");
		setM_OP_hasActionParameterSet_ActionParameterPosition("hasActionParameterSet_ActionParameterPosition");
	}
	/**
	 * @return the m_precondition
	 */
	public static OWLNamedIndividual getM_precondition() {
		return m_precondition;
	}
	/**
	 * @param m_precondition the m_precondition to set
	 */
	public static void setM_precondition(OWLNamedIndividual m_precondition) {
		Action.m_precondition = m_precondition;
	}
	/**
	 * @return the m_effect
	 */
	public static OWLNamedIndividual getM_effect() {
		return m_effect;
	}
	/**
	 * @param m_effect the m_effect to set
	 */
	public static void setM_effect(OWLNamedIndividual m_effect) {
		Action.m_effect = m_effect;
	}


	/**
	 * @return the m_action_precondition
	 */
	public Precondition getM_action_precondition() {
		return m_action_precondition;
	}
	/**
	 * @param m_action_precondition the m_action_precondition to set
	 */
	public void setM_action_precondition(Precondition m_action_precondition) {
		this.m_action_precondition = m_action_precondition;
	}
	/**
	 * @return the m_action_effect
	 */
	public Effect getM_action_effect() {
		return m_action_effect;
	}
	/**
	 * @param m_action_effect the m_action_effect to set
	 */
	public void setM_action_effect(Effect m_action_effect) {
		this.m_action_effect = m_action_effect;
	}
	/**
	 * @return the m_individual
	 */
	public OWLNamedIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLNamedIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_parameter_set
	 */
	public ArrayList<String> getM_parameter_set() {
		return m_parameter_set;
	}
	/**
	 * @param m_parameter_set the m_parameter_set to set
	 */
	public void setM_parameter_set(ArrayList<String> m_parameter_set) {
		this.m_parameter_set = m_parameter_set;
	}
	/**
	 * @return the m_OP_hasActionParameterSet_ActionParameter
	 */
	public String getM_OP_hasActionParameterSet_ActionParameter() {
		return m_OP_hasActionParameterSet_ActionParameter;
	}
	/**
	 * @param m_OP_hasActionParameterSet_ActionParameter the m_OP_hasActionParameterSet_ActionParameter to set
	 */
	public void setM_OP_hasActionParameterSet_ActionParameter(
			String m_OP_hasActionParameterSet_ActionParameter) {
		this.m_OP_hasActionParameterSet_ActionParameter = m_OP_hasActionParameterSet_ActionParameter;
	}
	/**
	 * @return the m_OP_hasActionParameterSet_ActionParameterPosition
	 */
	public String getM_OP_hasActionParameterSet_ActionParameterPosition() {
		return m_OP_hasActionParameterSet_ActionParameterPosition;
	}
	/**
	 * @param m_OP_hasActionParameterSet_ActionParameterPosition the m_OP_hasActionParameterSet_ActionParameterPosition to set
	 */
	public void setM_OP_hasActionParameterSet_ActionParameterPosition(
			String m_OP_hasActionParameterSet_ActionParameterPosition) {
		this.m_OP_hasActionParameterSet_ActionParameterPosition = m_OP_hasActionParameterSet_ActionParameterPosition;
	}

}
