/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Domain {
	private OWLIndividual m_individual;

	private String m_DPhasDomain_Variable;
	private String m_DPhasDomain_Requirement;

	private static ArrayList<NegativePredicate> m_negative_predicate_list;
	private static ArrayList<PositivePredicate> m_positive_predicate_list;
	private static ArrayList<Function> m_function_list;
	private static ArrayList<Action> m_action_list;
	private static ArrayList<String> m_requirement_list;
	private static ArrayList<String> m_variable_list;
	/**
	 * 
	 */
	public Domain() {
		setM_DPhasDomain_Requirement("hasDomain_Requirement");
		setM_DPhasDomain_Variable("hasDomain_Variable");
	}
	/**
	 * @return the m_domain_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_domain_individual the m_domain_individual to set
	 */
	public void setM_individual(OWLIndividual m_domain_individual) {
		this.m_individual = m_domain_individual;
	}

	/**
	 * @return the m_function_list
	 */
	public ArrayList<Function> getM_function_list() {
		return m_function_list;
	}
	/**
	 * @param m_function_list the m_function_list to set
	 */
	public void setM_function_list(ArrayList<Function> m_function_list) {
		Domain.m_function_list = m_function_list;
	}
	/**
	 * @return the m_action_list
	 */
	public ArrayList<Action> getM_action_list() {
		return m_action_list;
	}
	/**
	 * @param m_action_list the m_action_list to set
	 */
	public void setM_action_list(ArrayList<Action> m_action_list) {
		Domain.m_action_list = m_action_list;
	}
	/**
	 * @return the m_negative_predicate_list
	 */
	public ArrayList<NegativePredicate> getM_negative_predicate_list() {
		return m_negative_predicate_list;
	}
	/**
	 * @param m_negative_predicate_list the m_negative_predicate_list to set
	 */
	public void setM_negative_predicate_list(
			ArrayList<NegativePredicate> m_negative_predicate_list) {
		Domain.m_negative_predicate_list = m_negative_predicate_list;
	}
	/**
	 * @return the m_positive_predicate_list
	 */
	public ArrayList<PositivePredicate> getM_positive_predicate_list() {
		return m_positive_predicate_list;
	}
	/**
	 * @param m_positive_predicate_list the m_positive_predicate_list to set
	 */
	public void setM_positive_predicate_list(
			ArrayList<PositivePredicate> m_positive_predicate_list) {
		Domain.m_positive_predicate_list = m_positive_predicate_list;
	}
	/**
	 * @return the m_DPhasDomain_Variable
	 */
	public String getM_DPhasDomain_Variable() {
		return m_DPhasDomain_Variable;
	}
	/**
	 * @param m_DPhasDomain_Variable the m_DPhasDomain_Variable to set
	 */
	public void setM_DPhasDomain_Variable(String m_DPhasDomain_Variable) {
		this.m_DPhasDomain_Variable = m_DPhasDomain_Variable;
	}
	/**
	 * @return the m_DPhasDomain_Requirement
	 */
	public String getM_DPhasDomain_Requirement() {
		return m_DPhasDomain_Requirement;
	}
	/**
	 * @param m_DPhasDomain_Requirement the m_DPhasDomain_Requirement to set
	 */
	public void setM_DPhasDomain_Requirement(String m_DPhasDomain_Requirement) {
		this.m_DPhasDomain_Requirement = m_DPhasDomain_Requirement;
	}
	/**
	 * @return the m_requirement_list
	 */
	public ArrayList<String> getM_requirement_list() {
		return m_requirement_list;
	}
	/**
	 * @param m_requirement_list the m_requirement_list to set
	 */
	public void setM_requirement_list(ArrayList<String> m_requirement_list) {
		Domain.m_requirement_list = m_requirement_list;
	}
	/**
	 * @return the m_variable_list
	 */
	public ArrayList<String> getM_variable_list() {
		return m_variable_list;
	}
	/**
	 * @param m_variable_list the m_variable_list to set
	 */
	public void setM_variable_list(ArrayList<String> m_variable_list) {
		Domain.m_variable_list = m_variable_list;
	}

}
