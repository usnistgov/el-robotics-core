/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class FunctionOperation {
	private OWLIndividual m_individual;
	private String m_function;
	private Integer m_value;
	private String m_expression;

	//-- Data properties
	private String m_hasFunctionOperation_Value;
	private String m_hasFunctionOperation_Expression;
	/**
	 * 
	 */
	public FunctionOperation() {
		// TODO Auto-generated constructor stub
		setM_hasFunctionOperation_Expression("hasFunctionOperation_Expression");
		setM_hasFunctionOperation_Value("hasFunctionOperation_Value");
	}
	/**
	 * @return the m_function
	 */
	public String getM_function() {
		return m_function;
	}
	/**
	 * @param m_function the m_function to set
	 */
	public void setM_function(String m_function) {
		this.m_function = m_function;
	}
	/**
	 * @return the m_value
	 */
	public Integer getM_value() {
		return m_value;
	}
	/**
	 * @param m_value the m_value to set
	 */
	public void setM_value(Integer m_value) {
		this.m_value = m_value;
	}
	/**
	 * @return the m_expression
	 */
	public String getM_expression() {
		return m_expression;
	}
	/**
	 * @param m_expression the m_expression to set
	 */
	public void setM_expression(String m_expression) {
		this.m_expression = m_expression;
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_hasFunctionOperation_Value
	 */
	public String getM_hasFunctionOperation_Value() {
		return m_hasFunctionOperation_Value;
	}
	/**
	 * @param m_hasFunctionOperation_Value the m_hasFunctionOperation_Value to set
	 */
	public void setM_hasFunctionOperation_Value(
			String m_hasFunctionOperation_Value) {
		this.m_hasFunctionOperation_Value = m_hasFunctionOperation_Value;
	}
	/**
	 * @return the m_hasFunctionOperation_Expression
	 */
	public String getM_hasFunctionOperation_Expression() {
		return m_hasFunctionOperation_Expression;
	}
	/**
	 * @param m_hasFunctionOperation_Expression the m_hasFunctionOperation_Expression to set
	 */
	public void setM_hasFunctionOperation_Expression(
			String m_hasFunctionOperation_Expression) {
		this.m_hasFunctionOperation_Expression = m_hasFunctionOperation_Expression;
	}

}
