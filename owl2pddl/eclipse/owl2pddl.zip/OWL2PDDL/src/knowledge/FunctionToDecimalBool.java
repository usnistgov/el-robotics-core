/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;


/**
 * @author zeid
 *
 */
public class FunctionToDecimalBool {
	private String F1;
	private String D1;
	private String expression;
	private String m_DP_hasFunctionToDecimalBool_DecimalNumber="hasFunctionToDecimalBool_DecimalNumber";
	
	/**
	 * 
	 */
	public FunctionToDecimalBool() {
		// TODO Auto-generated constructor stub
		setM_DP_hasFunctionToDecimalBool_DecimalNumber(m_DP_hasFunctionToDecimalBool_DecimalNumber);
	}


	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}

	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}


	/**
	 * @return the f1
	 */
	public String getF1() {
		return F1;
	}


	/**
	 * @param f1 the f1 to set
	 */
	public void setF1(String f1) {
		F1 = f1;
	}


	/**
	 * @return the a1
	 */
	public String getD1() {
		return D1;
	}


	/**
	 * @param a1 the a1 to set
	 */
	public void setD1(String d1) {
		D1 = d1;
	}


	/**
	 * @return the m_DP_hasFunctionToDecimalBool_DecimalNumber
	 */
	public String getM_DP_hasFunctionToDecimalBool_DecimalNumber() {
		return m_DP_hasFunctionToDecimalBool_DecimalNumber;
	}


	/**
	 * @param m_DP_hasFunctionToDecimalBool_DecimalNumber the m_DP_hasFunctionToDecimalBool_DecimalNumber to set
	 */
	public void setM_DP_hasFunctionToDecimalBool_DecimalNumber(
			String m_DP_hasFunctionToDecimalBool_DecimalNumber) {
		this.m_DP_hasFunctionToDecimalBool_DecimalNumber = m_DP_hasFunctionToDecimalBool_DecimalNumber;
	}
}	





