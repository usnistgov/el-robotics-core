/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToDecimalGreater extends FunctionToDecimalBool {

	/**
	 * 
	 */
	public FunctionToDecimalGreater() {
		// TODO Auto-generated constructor stub
	}

}
