/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToDecimalLessOrEqual extends FunctionToDecimalBool {

	/**
	 * 
	 */
	public FunctionToDecimalLessOrEqual() {
		// TODO Auto-generated constructor stub
	}

}
