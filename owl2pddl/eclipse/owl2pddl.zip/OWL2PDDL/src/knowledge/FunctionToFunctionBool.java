/**
 * 
 */
package knowledge;


/**
 * @author zeid
 *
 */
public class FunctionToFunctionBool {
	private String F1;
	private String F2;
	private String expression;
	/**
	 * 
	 */
	public FunctionToFunctionBool() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}
	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}

	/**
	 * @return the f1
	 */
	public String getF1() {
		return F1;
	}

	/**
	 * @param f1 the f1 to set
	 */
	public void setF1(String f1) {
		F1 = f1;
	}

	/**
	 * @return the f2
	 */
	public String getF2() {
		return F2;
	}

	/**
	 * @param f2 the f2 to set
	 */
	public void setF2(String f2) {
		F2 = f2;
	}

}
