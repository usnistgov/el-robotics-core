/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToFunctionEqual extends FunctionToFunctionBool {

	/**
	 * 
	 */
	public FunctionToFunctionEqual() {
		// TODO Auto-generated constructor stub
	}

}
