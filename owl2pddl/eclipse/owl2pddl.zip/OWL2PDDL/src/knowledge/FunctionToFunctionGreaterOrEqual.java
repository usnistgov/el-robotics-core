/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToFunctionGreaterOrEqual extends FunctionToFunctionBool {

	/**
	 * 
	 */
	public FunctionToFunctionGreaterOrEqual() {
		// TODO Auto-generated constructor stub
	}

}
