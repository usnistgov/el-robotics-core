/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToFunctionLess extends FunctionToFunctionBool {

	/**
	 * 
	 */
	public FunctionToFunctionLess() {
		// TODO Auto-generated constructor stub
	}

}
