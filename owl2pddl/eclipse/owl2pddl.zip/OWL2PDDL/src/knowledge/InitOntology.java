/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @author zeid
 *
 */
public class InitOntology extends Ontology {
	private static OWLReasoner m_initOWLReasoner;
	//-- Object properties
	private String m_OP_hasEndEffectorChangingStation_EndEffectorHolder="hasEndEffectorChangingStation_EndEffectorHolder";
	private String m_OP_hasEndEffectorHolder_EndEffector="hasEndEffectorHolder_EndEffector";
	private String m_OP_hasRobot_EndEffector="hasRobot_EndEffector";
	private String m_OP_hasLargeBoxWithEmptyKitTrays_KitTray="hasLargeBoxWithEmptyKitTrays_KitTray";
	
	private String m_OP_hasPartsVessel_Part="hasPartsVessel_Part";
	private String m_OP_hasEndEffector_HeldObject="hasEndEffector_HeldObject";


	private String m_OP_hasWorkTable_ObjectOnTable="hasWorkTable_ObjectOnTable";
	//-- Data properties
	private String m_DP_hasLargeBoxWithKits_Capacity="hasLargeBoxWithKits_Capacity";

	/**
	 * @brief Path to owl init instance file
	 */
	private static String m_PathToInitInstanceFile;
	/**
	 * @brief OWLOntology for the init instance file
	 */
	private static OWLOntology m_OWLInitInstanceOntology;
	/**
	 * 
	 */
	/**
	 * @brief IRI for init.owl
	 */
	private static String m_init_IRI;


	public InitOntology() {
		// TODO Auto-generated constructor stub
		setM_init_IRI("http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#");
		setM_OP_hasEndEffectorChangingStation_EndEffectorHolder(m_OP_hasEndEffectorChangingStation_EndEffectorHolder);
		setM_OP_hasRobot_EndEffector(m_OP_hasRobot_EndEffector);
		setM_OP_hasLargeBoxWithEmptyKitTrays_KitTray(m_OP_hasLargeBoxWithEmptyKitTrays_KitTray);
		
		setM_OP_hasPartsVessel_Part(m_OP_hasPartsVessel_Part);
		setM_OP_hasEndEffector_HeldObject(m_OP_hasEndEffector_HeldObject);
		setM_OP_hasEndEffectorHolder_EndEffector(m_OP_hasEndEffectorHolder_EndEffector);
		setM_OP_hasWorkTable_ObjectOnTable(m_OP_hasWorkTable_ObjectOnTable);
		setM_DP_hasLargeBoxWithKits_Capacity(m_DP_hasLargeBoxWithKits_Capacity);
	}

	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		setM_initOWLReasoner(reasonerFactory.createReasoner(m_OWLInitInstanceOntology));
	}

	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		String filePath = new File("").getAbsolutePath();
		//System.out.println("filepath: "+filePath);
		//String l_OWLOntologyPath=getM_PathToSoapInstanceFile();
		//File file = new File(filePath.concat("/"+myPath));
		File file = new File(myPath);

		//-- Set the owl file passed as arguments as the current ontology
		setM_OWLInitInstanceOntology(getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file));
	}

	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_init_IRI().concat(myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//progressMonitor);
		return myClass;
	}

	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_init_IRI().concat(":" + myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//		progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = getM_initOWLReasoner().getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}


	/**
	 * @return the m_PathToInitInstanceFile
	 */
	public static String getM_PathToInitInstanceFile() {
		return m_PathToInitInstanceFile;
	}
	/**
	 * @param m_PathToInitInstanceFile the m_PathToInitInstanceFile to set
	 */
	public void setM_PathToInitInstanceFile(
			String m_PathToInitInstanceFile) {
		InitOntology.m_PathToInitInstanceFile = m_PathToInitInstanceFile;
	}
	/**
	 * @return the m_OWLInitInstanceOntology
	 */
	public OWLOntology getM_OWLInitInstanceOntology() {
		return m_OWLInitInstanceOntology;
	}
	/**
	 * @param m_OWLInitInstanceOntology the m_OWLInitInstanceOntology to set
	 */
	public static void setM_OWLInitInstanceOntology(
			OWLOntology m_OWLInitInstanceOntology) {
		InitOntology.m_OWLInitInstanceOntology = m_OWLInitInstanceOntology;
	}
	/**
	 * @return the m_init_IRI
	 */
	public String getM_init_IRI() {
		return m_init_IRI;
	}
	/**
	 * @param m_init_IRI the m_init_IRI to set
	 */
	public static void setM_init_IRI(String m_init_IRI) {
		InitOntology.m_init_IRI = m_init_IRI;
	}

	/**
	 * @return the m_OP_hasEndEffectorChangingStation_EndEffectorHolder
	 */
	public String getM_OP_hasEndEffectorChangingStation_EndEffectorHolder() {
		return m_OP_hasEndEffectorChangingStation_EndEffectorHolder;
	}

	/**
	 * @param m_OP_hasEndEffectorChangingStation_EndEffectorHolder the m_OP_hasEndEffectorChangingStation_EndEffectorHolder to set
	 */
	public void setM_OP_hasEndEffectorChangingStation_EndEffectorHolder(
			String m_OP_hasEndEffectorChangingStation_EndEffectorHolder) {
		this.m_OP_hasEndEffectorChangingStation_EndEffectorHolder = m_OP_hasEndEffectorChangingStation_EndEffectorHolder;
	}

	/**
	 * @return the m_OP_hasRobot_EndEffector
	 */
	public String getM_OP_hasRobot_EndEffector() {
		return m_OP_hasRobot_EndEffector;
	}

	/**
	 * @param m_OP_hasRobot_EndEffector the m_OP_hasRobot_EndEffector to set
	 */
	public void setM_OP_hasRobot_EndEffector(String m_OP_hasRobot_EndEffector) {
		this.m_OP_hasRobot_EndEffector = m_OP_hasRobot_EndEffector;
	}

	/**
	 * @return the m_OP_hasLargeBoxWithEmptyKitTrays_KitTray
	 */
	public String getM_OP_hasLargeBoxWithEmptyKitTrays_KitTray() {
		return m_OP_hasLargeBoxWithEmptyKitTrays_KitTray;
	}

	/**
	 * @param m_OP_hasLargeBoxWithEmptyKitTrays_KitTray the m_OP_hasLargeBoxWithEmptyKitTrays_KitTray to set
	 */
	public void setM_OP_hasLargeBoxWithEmptyKitTrays_KitTray(
			String m_OP_hasLargeBoxWithEmptyKitTrays_KitTray) {
		this.m_OP_hasLargeBoxWithEmptyKitTrays_KitTray = m_OP_hasLargeBoxWithEmptyKitTrays_KitTray;
	}


	/**
	 * @return the m_DP_hasLargeBoxWithKits_Capacity
	 */
	public String getM_DP_hasLargeBoxWithKits_Capacity() {
		return m_DP_hasLargeBoxWithKits_Capacity;
	}

	/**
	 * @param m_DP_hasLargeBoxWithKits_Capacity the m_DP_hasLargeBoxWithKits_Capacity to set
	 */
	public void setM_DP_hasLargeBoxWithKits_Capacity(
			String m_DP_hasLargeBoxWithKits_Capacity) {
		this.m_DP_hasLargeBoxWithKits_Capacity = m_DP_hasLargeBoxWithKits_Capacity;
	}

	/**
	 * @return the m_OP_hasPartsVessel_Part
	 */
	public String getM_OP_hasPartsVessel_Part() {
		return m_OP_hasPartsVessel_Part;
	}

	/**
	 * @param m_OP_hasPartsVessel_Part the m_OP_hasPartsVessel_Part to set
	 */
	public void setM_OP_hasPartsVessel_Part(String m_OP_hasPartsVessel_Part) {
		this.m_OP_hasPartsVessel_Part = m_OP_hasPartsVessel_Part;
	}

	/**
	 * @return the m_OP_hasEndEffectorHolder_EndEffector
	 */
	public String getM_OP_hasEndEffectorHolder_EndEffector() {
		return m_OP_hasEndEffectorHolder_EndEffector;
	}

	/**
	 * @param m_OP_hasEndEffectorHolder_EndEffector the m_OP_hasEndEffectorHolder_EndEffector to set
	 */
	public void setM_OP_hasEndEffectorHolder_EndEffector(
			String m_OP_hasEndEffectorHolder_EndEffector) {
		this.m_OP_hasEndEffectorHolder_EndEffector = m_OP_hasEndEffectorHolder_EndEffector;
	}

	/**
	 * @return the m_OP_hasWorkTable_ObjectOnTable
	 */
	public String getM_OP_hasWorkTable_ObjectOnTable() {
		return m_OP_hasWorkTable_ObjectOnTable;
	}

	/**
	 * @param m_OP_hasWorkTable_ObjectOnTable the m_OP_hasWorkTable_ObjectOnTable to set
	 */
	public void setM_OP_hasWorkTable_ObjectOnTable(
			String m_OP_hasWorkTable_ObjectOnTable) {
		this.m_OP_hasWorkTable_ObjectOnTable = m_OP_hasWorkTable_ObjectOnTable;
	}

	/**
	 * @return the m_initOWLReasoner
	 */
	public OWLReasoner getM_initOWLReasoner() {
		return m_initOWLReasoner;
	}

	/**
	 * @param m_initOWLReasoner the m_initOWLReasoner to set
	 */
	public static void setM_initOWLReasoner(OWLReasoner m_initOWLReasoner) {
		InitOntology.m_initOWLReasoner = m_initOWLReasoner;
	}

	/**
	 * @return the m_OP_hasEndEffector_HeldObject
	 */
	public String getM_OP_hasEndEffector_HeldObject() {
		return m_OP_hasEndEffector_HeldObject;
	}

	/**
	 * @param m_OP_hasEndEffector_HeldObject the m_OP_hasEndEffector_HeldObject to set
	 */
	public void setM_OP_hasEndEffector_HeldObject(
			String m_OP_hasEndEffector_HeldObject) {
		this.m_OP_hasEndEffector_HeldObject = m_OP_hasEndEffector_HeldObject;
	}
}
