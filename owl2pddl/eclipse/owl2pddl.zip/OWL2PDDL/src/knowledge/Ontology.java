package knowledge;

import java.io.File;
import java.net.MalformedURLException;
import java.text.Normalizer;
import java.text.Normalizer.Form;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Ontology {
	private static OWLDataFactory m_OWLDataFactory;

	private static OWLOntologyManager m_OWLOntologyManager;
	private String m_outputPDDLFile;
	private String m_kittingWorkstationClasses_IRI;

	//-- OWL classes
	private String m_owl_class_SOAP;
	private String m_owl_class_Domain;
	private String m_owl_class_PositivePredicate;
	private String m_owl_class_NegativePredicate;
	private String m_owl_class_Function;
	private String m_owl_class_ActionBase;
	private String m_owl_class_FunctionToFunctionEqual;
	private String m_owl_class_FunctionToFunctionGreater;
	private String m_owl_class_FunctionToFunctionGreaterOrEqual;
	private String m_owl_class_FunctionToFunctionLessOrEqual;
	private String m_owl_class_FunctionToFunctionLess;
	private String m_owl_class_FunctionOperation;
	private String m_owl_class_FunctionToDecimalEqual;
	private String m_owl_class_FunctionToDecimalGreater;
	private String m_owl_class_FunctionToDecimalLess;
	private String m_owl_class_FunctionToDecimalGreaterOrEqual;
	private String m_owl_class_FunctionToDecimalLessOrEqual;

	private String m_owl_class_Robot;
	private String m_owl_class_EndEffectorChangingStation;
	private String m_owl_class_KitTray;
	private String m_owl_class_LargeBoxWithEmptyKitTrays;
	private String m_owl_class_LargeBoxWithKits;
	private String m_owl_class_WorkTable;
	private String m_owl_class_PartsTray;
	private String m_owl_class_Part;
	private String m_owl_class_EndEffector;
	private String m_owl_class_EndEffectorHolder;
	private String m_owl_class_Kit;
	private String m_owl_class_StockKeepingUnit = "StockKeepingUnit";

	private String m_OP_hasSkuObject_Sku="hasSkuObject_Sku";
	private String m_OP_hasLargeBoxWithKits_Kit="hasLargeBoxWithKits_Kit";
	private String m_OP_hasStockKeepingUnit_EndEffector="hasStockKeepingUnit_EndEffector";
	private String m_OP_hasKit_KitTray="hasKit_KitTray";
	private String m_OP_hasSolidObject_PrimaryLocation="hasSolidObject_PrimaryLocation";
	private String m_OP_hasKit_Part="hasKit_Part";
	private String m_OP_hasPhysicalLocation_RefObject="hasPhysicalLocation_RefObject";

	public Ontology() {
		setM_kittingWorkstationClasses_IRI("http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#");
		setM_owl_class_Robot("Robot");
		setM_owl_class_EndEffectorChangingStation("EndEffectorChangingStation");
		setM_owl_class_KitTray("KitTray");
		setM_owl_class_LargeBoxWithEmptyKitTrays("LargeBoxWithEmptyKitTrays");
		setM_owl_class_LargeBoxWithKits("LargeBoxWithKits");
		setM_owl_class_WorkTable("WorkTable");
		setM_owl_class_PartsTray("PartsTray");
		setM_owl_class_Part("Part");
		setM_owl_class_EndEffector("EndEffector");
		setM_owl_class_EndEffectorHolder("EndEffectorHolder");
		setM_owl_class_Kit("Kit");
		setM_owl_class_StockKeepingUnit(m_owl_class_StockKeepingUnit);
		setM_owl_class_SOAP("SOAP");
		setM_owl_class_Domain("Domain");
		setM_owl_class_PositivePredicate("PositivePredicate");
		setM_owl_class_NegativePredicate("NegativePredicate");
		setM_owl_class_Function("Function");
		setM_ActionBaseClass("ActionBase");
		setM_owl_class_FunctionToFunctionEqual("FunctionToFunctionEqual");
		setM_owl_class_FunctionToFunctionLessOrEqual("FunctionToFunctionLessOrEqual");
		setM_owl_class_FunctionToFunctionGreaterOrEqual("FunctionToFunctionGreaterOrEqual");
		setM_owl_class_FunctionToFunctionGreater("FunctionToFunctionGreater");
		setM_owl_class_FunctionToFunctionLess("FunctionToFunctionLess");
		setM_owl_class_FunctionOperation("FunctionOperation");
		setM_owl_class_FunctionToDecimalEqual("FunctionToDecimalEqual");
		setM_owl_class_FunctionToDecimalGreater("FunctionToDecimalGreater");
		setM_owl_class_FunctionToDecimalLess("FunctionToDecimalLess");
		setM_owl_class_FunctionToDecimalGreaterOrEqual("FunctionToDecimalGreaterOrEqual");
		setM_owl_class_FunctionToDecimalLessOrEqual("FunctionToDecimalLessOrEqual");
		setM_OP_hasSolidObject_PrimaryLocation(m_OP_hasSolidObject_PrimaryLocation);
		setM_OP_hasSkuObject_Sku(m_OP_hasSkuObject_Sku);
		setM_OP_hasStockKeepingUnit_EndEffector(m_OP_hasStockKeepingUnit_EndEffector);
		setM_OP_hasKit_KitTray(m_OP_hasKit_KitTray);
		setM_OP_hasKit_Part(m_OP_hasKit_Part);
		setM_OP_hasPhysicalLocation_RefObject(m_OP_hasPhysicalLocation_RefObject);
		setM_OP_hasLargeBoxWithKits_Kit(m_OP_hasLargeBoxWithKits_Kit);


		setManager();
	}

	/**
	 * @brief Creates an OWL Ontology manager that is configured with standard parsers, storers, etc.
	 */
	public void setManager() {
		this.setM_OWLOntologyManager(OWLManager.createOWLOntologyManager());
	}

	public OWLDataFactory getM_OWLDataFactory() {
		return m_OWLDataFactory;
	}

	public void setM_OWLDataFactory(OWLDataFactory m_OWLDataFactory) {
		Ontology.m_OWLDataFactory = m_OWLDataFactory;
	}

	public void setM_OWLDataFactory() {
		Ontology.m_OWLDataFactory = getM_OWLOntologyManager().getOWLDataFactory();
	}




	public String getM_kittingWorkstationClasses_IRI() {
		return m_kittingWorkstationClasses_IRI;
	}

	public void setM_kittingWorkstationClasses_IRI(
			String m_kittingWorkstationClasses_IRI) {
		this.m_kittingWorkstationClasses_IRI = m_kittingWorkstationClasses_IRI;
	}



	/**
	 * @return the m_ActionBaseClass
	 */
	public String getM_ActionBaseClass() {
		return m_owl_class_ActionBase;
	}

	/**
	 * @param m_ActionBaseClass the m_ActionBaseClass to set
	 */
	public void setM_ActionBaseClass(String m_ActionBaseClass) {
		this.m_owl_class_ActionBase = m_ActionBaseClass;
	}

	public String getM_outputPDDLFile() {
		return m_outputPDDLFile;
	}

	public void setM_outputPDDLFile(String m_outputPDDLFile) {
		this.m_outputPDDLFile = m_outputPDDLFile;
	}

	public String getM_owl_class_Robot() {
		return m_owl_class_Robot;
	}

	public void setM_owl_class_Robot(String m_owl_class_Robot) {
		this.m_owl_class_Robot = m_owl_class_Robot;
	}

	public String getM_owl_class_EndEffectorChangingStation() {
		return m_owl_class_EndEffectorChangingStation;
	}

	public void setM_owl_class_EndEffectorChangingStation(
			String m_owl_class_EndEffectorChangingStation) {
		this.m_owl_class_EndEffectorChangingStation = m_owl_class_EndEffectorChangingStation;
	}

	public String getM_owl_class_KitTray() {
		return m_owl_class_KitTray;
	}

	public void setM_owl_class_KitTray(String m_owl_class_KitTray) {
		this.m_owl_class_KitTray = m_owl_class_KitTray;
	}

	public String getM_owl_class_LargeBoxWithEmptyKitTrays() {
		return m_owl_class_LargeBoxWithEmptyKitTrays;
	}

	public void setM_owl_class_LargeBoxWithEmptyKitTrays(
			String m_owl_class_LargeBoxWithEmptyKitTrays) {
		this.m_owl_class_LargeBoxWithEmptyKitTrays = m_owl_class_LargeBoxWithEmptyKitTrays;
	}

	public String getM_owl_class_LargeBoxWithKits() {
		return m_owl_class_LargeBoxWithKits;
	}

	public void setM_owl_class_LargeBoxWithKits(
			String m_owl_class_LargeBoxWithKits) {
		this.m_owl_class_LargeBoxWithKits = m_owl_class_LargeBoxWithKits;
	}

	public String getM_owl_class_WorkTable() {
		return m_owl_class_WorkTable;
	}

	public void setM_owl_class_WorkTable(String m_owl_class_WorkTable) {
		this.m_owl_class_WorkTable = m_owl_class_WorkTable;
	}

	public String getM_owl_class_PartsTray() {
		return m_owl_class_PartsTray;
	}

	public void setM_owl_class_PartsTray(String m_owl_class_PartsTray) {
		this.m_owl_class_PartsTray = m_owl_class_PartsTray;
	}

	public String getM_owl_class_Part() {
		return m_owl_class_Part;
	}

	public void setM_owl_class_Part(String m_owl_class_Part) {
		this.m_owl_class_Part = m_owl_class_Part;
	}

	public String getM_owl_class_EndEffectorHolder() {
		return m_owl_class_EndEffectorHolder;
	}

	public void setM_owl_class_EndEffectorHolder(
			String m_owl_class_EndEffectorHolder) {
		this.m_owl_class_EndEffectorHolder = m_owl_class_EndEffectorHolder;
	}

	public String getM_owl_class_EndEffector() {
		return m_owl_class_EndEffector;
	}

	public void setM_owl_class_EndEffector(String m_owl_class_EndEffector) {
		this.m_owl_class_EndEffector = m_owl_class_EndEffector;
	}


	
	public String getM_owl_class_Kit() {
		return m_owl_class_Kit;
	}

	public void setM_owl_class_Kit(String m_owl_class_Kit) {
		this.m_owl_class_Kit = m_owl_class_Kit;
	}


	public String getM_owl_class_SOAP() {
		return m_owl_class_SOAP;
	}

	public void setM_owl_class_SOAP(String m_owl_class_SOAP) {
		this.m_owl_class_SOAP = m_owl_class_SOAP;
	}

	public String getM_owl_class_Domain() {
		return m_owl_class_Domain;
	}

	public void setM_owl_class_Domain(String m_owl_class_Domain) {
		this.m_owl_class_Domain = m_owl_class_Domain;
	}

	public String getM_owl_class_PositivePredicate() {
		return m_owl_class_PositivePredicate;
	}

	public void setM_owl_class_PositivePredicate(
			String m_owl_class_PositivePredicate) {
		this.m_owl_class_PositivePredicate = m_owl_class_PositivePredicate;
	}

	public String getM_owl_class_NegativePredicate() {
		return m_owl_class_NegativePredicate;
	}

	public void setM_owl_class_NegativePredicate(
			String m_owl_class_NegativePredicate) {
		this.m_owl_class_NegativePredicate = m_owl_class_NegativePredicate;
	}

	public String getM_owl_class_Function() {
		return m_owl_class_Function;
	}

	public void setM_owl_class_Function(String m_owl_class_Function) {
		this.m_owl_class_Function = m_owl_class_Function;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionEqual
	 */
	public String getM_owl_class_FunctionToFunctionEqual() {
		return m_owl_class_FunctionToFunctionEqual;
	}

	/**
	 * @param m_owl_class_FunctionToFunctionEqual the m_owl_class_FunctionToFunctionEqual to set
	 */
	public void setM_owl_class_FunctionToFunctionEqual(
			String m_owl_class_FunctionToFunctionEqual) {
		this.m_owl_class_FunctionToFunctionEqual = m_owl_class_FunctionToFunctionEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionGreater
	 */
	public String getM_owl_class_FunctionToFunctionGreater() {
		return m_owl_class_FunctionToFunctionGreater;
	}

	/**
	 * @param m_owl_class_FunctionToFunctionGreater the m_owl_class_FunctionToFunctionGreater to set
	 */
	public void setM_owl_class_FunctionToFunctionGreater(
			String m_owl_class_FunctionToFunctionGreater) {
		this.m_owl_class_FunctionToFunctionGreater = m_owl_class_FunctionToFunctionGreater;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionGreaterOrEqual
	 */
	public String getM_owl_class_FunctionToFunctionGreaterOrEqual() {
		return m_owl_class_FunctionToFunctionGreaterOrEqual;
	}

	/**
	 * @param m_owl_class_FunctionToFunctionGreaterOrEqual the m_owl_class_FunctionToFunctionGreaterOrEqual to set
	 */
	public void setM_owl_class_FunctionToFunctionGreaterOrEqual(
			String m_owl_class_FunctionToFunctionGreaterOrEqual) {
		this.m_owl_class_FunctionToFunctionGreaterOrEqual = m_owl_class_FunctionToFunctionGreaterOrEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionLessOrEqual
	 */
	public String getM_owl_class_FunctionToFunctionLessOrEqual() {
		return m_owl_class_FunctionToFunctionLessOrEqual;
	}

	/**
	 * @param m_owl_class_FunctionToFunctionLessOrEqual the m_owl_class_FunctionToFunctionLessOrEqual to set
	 */
	public void setM_owl_class_FunctionToFunctionLessOrEqual(
			String m_owl_class_FunctionToFunctionLessOrEqual) {
		this.m_owl_class_FunctionToFunctionLessOrEqual = m_owl_class_FunctionToFunctionLessOrEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToFunctionLess
	 */
	public String getM_owl_class_FunctionToFunctionLess() {
		return m_owl_class_FunctionToFunctionLess;
	}

	/**
	 * @param m_owl_class_FunctionToFunctionLess the m_owl_class_FunctionToFunctionLess to set
	 */
	public void setM_owl_class_FunctionToFunctionLess(
			String m_owl_class_FunctionToFunctionLess) {
		this.m_owl_class_FunctionToFunctionLess = m_owl_class_FunctionToFunctionLess;
	}

	/**
	 * @return the m_owl_class_FunctionOperation
	 */
	public String getM_owl_class_FunctionOperation() {
		return m_owl_class_FunctionOperation;
	}

	/**
	 * @param m_owl_class_FunctionOperation the m_owl_class_FunctionOperation to set
	 */
	public void setM_owl_class_FunctionOperation(
			String m_owl_class_FunctionOperation) {
		this.m_owl_class_FunctionOperation = m_owl_class_FunctionOperation;
	}

	/**
	 * @return the m_OWLOntologyManager
	 */
	public OWLOntologyManager getM_OWLOntologyManager() {
		return m_OWLOntologyManager;
	}

	/**
	 * @param m_OWLOntologyManager the m_OWLOntologyManager to set
	 */
	public static void setM_OWLOntologyManager(OWLOntologyManager m_OWLOntologyManager) {
		Ontology.m_OWLOntologyManager = m_OWLOntologyManager;
	}

	/**
	 * @return the m_OP_hasSkuObject_Sku
	 */
	public String getM_OP_hasSkuObject_Sku() {
		return m_OP_hasSkuObject_Sku;
	}

	/**
	 * @param m_OP_hasSkuObject_Sku the m_OP_hasSkuObject_Sku to set
	 */
	public void setM_OP_hasSkuObject_Sku(String m_OP_hasSkuObject_Sku) {
		this.m_OP_hasSkuObject_Sku = m_OP_hasSkuObject_Sku;
	}

	/**
	 * @return the m_OP_hasStockKeepingUnit_EndEffector
	 */
	public String getM_OP_hasStockKeepingUnit_EndEffector() {
		return m_OP_hasStockKeepingUnit_EndEffector;
	}

	/**
	 * @param m_OP_hasStockKeepingUnit_EndEffector the m_OP_hasStockKeepingUnit_EndEffector to set
	 */
	public void setM_OP_hasStockKeepingUnit_EndEffector(
			String m_OP_hasStockKeepingUnit_EndEffector) {
		this.m_OP_hasStockKeepingUnit_EndEffector = m_OP_hasStockKeepingUnit_EndEffector;
	}
	/**
	 * @return the m_OP_hasKit_KitTray
	 */
	public String getM_OP_hasKit_KitTray() {
		return m_OP_hasKit_KitTray;
	}

	/**
	 * @param m_OP_hasKit_KitTray the m_OP_hasKit_KitTray to set
	 */
	public void setM_OP_hasKit_KitTray(String m_OP_hasKit_KitTray) {
		this.m_OP_hasKit_KitTray = m_OP_hasKit_KitTray;
	}

	/**
	 * @return the m_OP_hasKit_Part
	 */
	public String getM_OP_hasKit_Part() {
		return m_OP_hasKit_Part;
	}

	/**
	 * @param m_OP_hasKit_Part the m_OP_hasKit_Part to set
	 */
	public void setM_OP_hasKit_Part(String m_OP_hasKit_Part) {
		this.m_OP_hasKit_Part = m_OP_hasKit_Part;
	}
	/**
	 * @return the m_OP_hasSolidObject_PrimaryLocation
	 */
	public String getM_OP_hasSolidObject_PrimaryLocation() {
		return m_OP_hasSolidObject_PrimaryLocation;
	}

	/**
	 * @param m_OP_hasSolidObject_PrimaryLocation the m_OP_hasSolidObject_PrimaryLocation to set
	 */
	public void setM_OP_hasSolidObject_PrimaryLocation(
			String m_OP_hasSolidObject_PrimaryLocation) {
		this.m_OP_hasSolidObject_PrimaryLocation = m_OP_hasSolidObject_PrimaryLocation;
	}
	/**
	 * @return the m_OP_hasPhysicalLocation_RefObject
	 */
	public String getM_OP_hasPhysicalLocation_RefObject() {
		return m_OP_hasPhysicalLocation_RefObject;
	}

	/**
	 * @param m_OP_hasPhysicalLocation_RefObject the m_OP_hasPhysicalLocation_RefObject to set
	 */
	public void setM_OP_hasPhysicalLocation_RefObject(
			String m_OP_hasPhysicalLocation_RefObject) {
		this.m_OP_hasPhysicalLocation_RefObject = m_OP_hasPhysicalLocation_RefObject;
	}

	/**
	 * @return the m_owl_class_FunctionToDecimalEqual
	 */
	public String getM_owl_class_FunctionToDecimalEqual() {
		return m_owl_class_FunctionToDecimalEqual;
	}

	/**
	 * @param m_owl_class_FunctionToDecimalEqual the m_owl_class_FunctionToDecimalEqual to set
	 */
	public void setM_owl_class_FunctionToDecimalEqual(
			String m_owl_class_FunctionToDecimalEqual) {
		this.m_owl_class_FunctionToDecimalEqual = m_owl_class_FunctionToDecimalEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToDecimalGreater
	 */
	public String getM_owl_class_FunctionToDecimalGreater() {
		return m_owl_class_FunctionToDecimalGreater;
	}

	/**
	 * @param m_owl_class_FunctionToDecimalGreater the m_owl_class_FunctionToDecimalGreater to set
	 */
	public void setM_owl_class_FunctionToDecimalGreater(
			String m_owl_class_FunctionToDecimalGreater) {
		this.m_owl_class_FunctionToDecimalGreater = m_owl_class_FunctionToDecimalGreater;
	}

	/**
	 * @return the m_owl_class_FunctionToDecimalLess
	 */
	public String getM_owl_class_FunctionToDecimalLess() {
		return m_owl_class_FunctionToDecimalLess;
	}

	/**
	 * @param m_owl_class_FunctionToDecimalLess the m_owl_class_FunctionToDecimalLess to set
	 */
	public void setM_owl_class_FunctionToDecimalLess(
			String m_owl_class_FunctionToDecimalLess) {
		this.m_owl_class_FunctionToDecimalLess = m_owl_class_FunctionToDecimalLess;
	}

	/**
	 * @return the m_owl_class_FunctionToDecimalGreaterOrEqual
	 */
	public String getM_owl_class_FunctionToDecimalGreaterOrEqual() {
		return m_owl_class_FunctionToDecimalGreaterOrEqual;
	}

	/**
	 * @param m_owl_class_FunctionToDecimalGreaterOrEqual the m_owl_class_FunctionToDecimalGreaterOrEqual to set
	 */
	public void setM_owl_class_FunctionToDecimalGreaterOrEqual(
			String m_owl_class_FunctionToDecimalGreaterOrEqual) {
		this.m_owl_class_FunctionToDecimalGreaterOrEqual = m_owl_class_FunctionToDecimalGreaterOrEqual;
	}

	/**
	 * @return the m_owl_class_FunctionToDecimalLessOrEqual
	 */
	public String getM_owl_class_FunctionToDecimalLessOrEqual() {
		return m_owl_class_FunctionToDecimalLessOrEqual;
	}

	/**
	 * @param m_owl_class_FunctionToDecimalLessOrEqual the m_owl_class_FunctionToDecimalLessOrEqual to set
	 */
	public void setM_owl_class_FunctionToDecimalLessOrEqual(
			String m_owl_class_FunctionToDecimalLessOrEqual) {
		this.m_owl_class_FunctionToDecimalLessOrEqual = m_owl_class_FunctionToDecimalLessOrEqual;
	}

	/**
	 * @return the m_owl_class_StockKeepingUnit
	 */
	public String getM_owl_class_StockKeepingUnit() {
		return m_owl_class_StockKeepingUnit;
	}

	/**
	 * @param m_owl_class_StockKeepingUnit the m_owl_class_StockKeepingUnit to set
	 */
	public void setM_owl_class_StockKeepingUnit(
			String m_owl_class_StockKeepingUnit) {
		this.m_owl_class_StockKeepingUnit = m_owl_class_StockKeepingUnit;
	}

	/**
	 * @return the m_OP_hasLargeBoxWithKits_Kit
	 */
	public String getM_OP_hasLargeBoxWithKits_Kit() {
		return m_OP_hasLargeBoxWithKits_Kit;
	}

	/**
	 * @param m_OP_hasLargeBoxWithKits_Kit the m_OP_hasLargeBoxWithKits_Kit to set
	 */
	public void setM_OP_hasLargeBoxWithKits_Kit(
			String m_OP_hasLargeBoxWithKits_Kit) {
		this.m_OP_hasLargeBoxWithKits_Kit = m_OP_hasLargeBoxWithKits_Kit;
	}
}
