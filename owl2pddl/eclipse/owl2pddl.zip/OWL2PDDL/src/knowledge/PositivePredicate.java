/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class PositivePredicate extends Predicate {
	private OWLIndividual m_individual;
	private String m_hasPositivePredicate_Description;
	private String m_hasPositivePredicate_ReferenceParameter;
	private String m_hasPositivePredicate_TargetParameter;
	/**
	 * 
	 */
	public PositivePredicate() {
		// TODO Auto-generated constructor stub
		setM_hasPositivePredicate_ReferenceParameter("hasPositivePredicate_ReferenceParameter");
		setM_hasPositivePredicate_TargetParameter("hasPositivePredicate_TargetParameter");
		setM_hasPositivePredicate_Description("hasPositivePredicate_Description");
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_hasPositivePredicate_Description
	 */
	public String getM_hasPositivePredicate_Description() {
		return m_hasPositivePredicate_Description;
	}
	/**
	 * @param m_hasPositivePredicate_Description the m_hasPositivePredicate_Description to set
	 */
	public void setM_hasPositivePredicate_Description(
			String m_hasPositivePredicate_Description) {
		this.m_hasPositivePredicate_Description = m_hasPositivePredicate_Description;
	}
	/**
	 * @return the m_hasPositivePredicate_ReferenceParameter
	 */
	public String getM_hasPositivePredicate_ReferenceParameter() {
		return m_hasPositivePredicate_ReferenceParameter;
	}
	/**
	 * @param m_hasPositivePredicate_ReferenceParameter the m_hasPositivePredicate_ReferenceParameter to set
	 */
	public void setM_hasPositivePredicate_ReferenceParameter(
			String m_hasPositivePredicate_ReferenceParameter) {
		this.m_hasPositivePredicate_ReferenceParameter = m_hasPositivePredicate_ReferenceParameter;
	}
	/**
	 * @return the m_hasPositivePredicate_TargetParameter
	 */
	public String getM_hasPositivePredicate_TargetParameter() {
		return m_hasPositivePredicate_TargetParameter;
	}
	/**
	 * @param m_hasPositivePredicate_TargetParameter the m_hasPositivePredicate_TargetParameter to set
	 */
	public void setM_hasPositivePredicate_TargetParameter(
			String m_hasPositivePredicate_TargetParameter) {
		this.m_hasPositivePredicate_TargetParameter = m_hasPositivePredicate_TargetParameter;
	}

}
