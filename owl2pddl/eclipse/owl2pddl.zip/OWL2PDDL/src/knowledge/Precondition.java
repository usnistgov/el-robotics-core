/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Precondition {
	private OWLIndividual m_individual;
	private ArrayList<String> m_predicate_list = new ArrayList<String>();
	private ArrayList<FunctionToFunctionBool> m_f2f_list = new ArrayList<FunctionToFunctionBool>();
	private ArrayList<FunctionOperation> m_function_operation_list = new ArrayList<FunctionOperation>();


	/**
	 * 
	 */
	public Precondition() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}


	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}

	/**
	 * @return the m_predicate_list
	 */
	public ArrayList<String> getM_predicate_list() {
		return m_predicate_list;
	}

	/**
	 * @param m_predicate_list the m_predicate_list to set
	 */
	public void setM_predicate_list(ArrayList<String> m_predicate_list) {
		this.m_predicate_list = m_predicate_list;
	}

	/**
	 * @return the m_f2f_list
	 */
	public ArrayList<FunctionToFunctionBool> getM_f2f_list() {
		return m_f2f_list;
	}

	/**
	 * @param m_f2f_list the m_f2f_list to set
	 */
	public void setM_f2f_list(ArrayList<FunctionToFunctionBool> m_f2f_list) {
		this.m_f2f_list = m_f2f_list;
	}

	/**
	 * @return the m_function_operation_list
	 */
	public ArrayList<FunctionOperation> getM_function_operation_list() {
		return m_function_operation_list;
	}

	/**
	 * @param m_function_operation_list the m_function_operation_list to set
	 */
	public void setM_function_operation_list(
			ArrayList<FunctionOperation> m_function_operation_list) {
		this.m_function_operation_list = m_function_operation_list;
	}

}
