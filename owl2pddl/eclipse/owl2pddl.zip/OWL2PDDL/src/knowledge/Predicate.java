/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import java.util.ArrayList;

/**
 * @author zeid
 *
 */
public class Predicate {

	private String m_reference_parameter;
	private String m_target_parameter;
	private String m_description;

	/**
	 * 
	 */
	public Predicate() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the m_reference_parameter
	 */
	public String getM_reference_parameter() {
		return m_reference_parameter;
	}
	/**
	 * @param m_reference_parameter the m_reference_parameter to set
	 */
	public void setM_reference_parameter(String m_reference_parameter) {
		this.m_reference_parameter = m_reference_parameter;
	}
	/**
	 * @return the m_target_parameter
	 */
	public String getM_target_parameter() {
		return m_target_parameter;
	}
	/**
	 * @param m_target_parameter the m_target_parameter to set
	 */
	public void setM_target_parameter(String m_target_parameter) {
		this.m_target_parameter = m_target_parameter;
	}



	/**
	 * @return the m_description
	 */
	public String getM_description() {
		return m_description;
	}

	/**
	 * @param m_description the m_description to set
	 */
	public void setM_description(String m_description) {
		this.m_description = m_description;
	}


}
