/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Soap {
	private OWLIndividual m_individual;
	private Domain m_domain;

	private String m_OPhasSOAP_Domain = "hasSOAP_Domain";
	/**
	 * 
	 */
	public Soap() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}

	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}

	/**
	 * @return the m_OPhasSOAP_Domain
	 */
	public String getM_OPhasSOAP_Domain() {
		return m_OPhasSOAP_Domain;
	}

	/**
	 * @param m_OPhasSOAP_Domain the m_OPhasSOAP_Domain to set
	 */
	public void setM_OPhasSOAP_Domain(String m_OPhasSOAP_Domain) {
		this.m_OPhasSOAP_Domain = m_OPhasSOAP_Domain;
	}


	/**
	 * @return the m_domain
	 */
	public Domain getM_domain() {
		return m_domain;
	}


	/**
	 * @param m_domain the m_domain to set
	 */
	public void setM_domain(Domain m_domain) {
		this.m_domain = m_domain;
	}

}
