/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @author zeid
 *
 */
public class SoapOntology extends Ontology {
	private static OWLReasoner m_soapOWLReasoner;
	/**
	 * @brief Path to owl soap instance file
	 */
	private static String m_PathToSoapInstanceFile;

	/**
	 * @brief OWLOntology for the soap instance file
	 */
	private static OWLOntology m_OWLSoapInstanceOntology;
	/**
	 * @brief IRI for soapClasses.owl
	 */
	private static String m_soapClasses_IRI;

	private String m_soapInstances_IRI;

	/**
	 * 
	 */
	public SoapOntology() {
		// TODO Auto-generated constructor stub
		setM_soapClasses_IRI("http://www.nist.gov/el/ontologies/soapClasses.owl#");
		setM_soapInstances_IRI("http://www.nist.gov/el/ontologies/soapInstances.owl#");
	}

	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		setM_soapOWLReasoner(reasonerFactory.createReasoner(m_OWLSoapInstanceOntology));
	}

	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		String filePath = new File("").getAbsolutePath();
		//System.out.println("filepath: "+filePath);
		//String l_OWLOntologyPath=getM_PathToSoapInstanceFile();
		//File file = new File(filePath.concat("/"+myPath));
		File file = new File(myPath);

		//-- Set the owl file passed as arguments as the current ontology
		setM_OWLSoapInstanceOntology(getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file));
	}

	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_soapClasses_IRI().concat(myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//progressMonitor);
		return myClass;
	}

	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_soapClasses_IRI().concat(":" + myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//		progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = getM_soapOWLReasoner().getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}

	/**
	 * @return the m_PathToSoapInstanceFile
	 */
	public static String getM_PathToSoapInstanceFile() {
		return m_PathToSoapInstanceFile;
	}

	/**
	 * @param m_PathToSoapInstanceFile the m_PathToSoapInstanceFile to set
	 */
	public void setM_PathToSoapInstanceFile(String m_PathToSoapInstanceFile) {
		SoapOntology.m_PathToSoapInstanceFile = m_PathToSoapInstanceFile;
	}

	/**
	 * @return the m_OWLSoapInstanceOntology
	 */
	public OWLOntology getM_OWLSoapInstanceOntology() {
		return m_OWLSoapInstanceOntology;
	}

	/**
	 * @param m_OWLSoapInstanceOntology the m_OWLSoapInstanceOntology to set
	 */
	public static void setM_OWLSoapInstanceOntology(
			OWLOntology m_OWLSoapInstanceOntology) {
		SoapOntology.m_OWLSoapInstanceOntology = m_OWLSoapInstanceOntology;
	}

	/**
	 * @return the m_soapClasses_IRI
	 */
	public String getM_soapClasses_IRI() {
		return m_soapClasses_IRI;
	}

	/**
	 * @param m_soapClasses_IRI the m_soapClasses_IRI to set
	 */
	public static void setM_soapClasses_IRI(String m_soapClasses_IRI) {
		SoapOntology.m_soapClasses_IRI = m_soapClasses_IRI;
	}

	/**
	 * @return the m_soapInstances_IRI
	 */
	public String getM_soapInstances_IRI() {
		return m_soapInstances_IRI;
	}

	/**
	 * @param m_soapInstances_IRI the m_soapInstances_IRI to set
	 */
	public void setM_soapInstances_IRI(String m_soapInstances_IRI) {
		this.m_soapInstances_IRI = m_soapInstances_IRI;
	}

	/**
	 * @return the m_soapOWLReasoner
	 */
	public OWLReasoner getM_soapOWLReasoner() {
		return m_soapOWLReasoner;
	}

	/**
	 * @param m_soapOWLReasoner the m_soapOWLReasoner to set
	 */
	public static void setM_soapOWLReasoner(OWLReasoner m_soapOWLReasoner) {
		SoapOntology.m_soapOWLReasoner = m_soapOWLReasoner;
	}

}
