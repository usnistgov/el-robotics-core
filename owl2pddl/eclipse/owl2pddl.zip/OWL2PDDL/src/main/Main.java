package main;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.NodeSet;

import tools.Mapper;
import tools.Parser;
import tools.Reader;
import tools.Writer;

import knowledge.Domain;
import knowledge.GoalOntology;
import knowledge.InitOntology;
import knowledge.Ontology;
import knowledge.Soap;
import knowledge.SoapOntology;

public class Main {
	public static void main (String[] args) throws MalformedURLException, OWLException, FileNotFoundException, UnsupportedEncodingException {
		if (args.length==1) {
			if (args[0].compareTo("--h")==0){
				System.out.println("\n\n-------------------------------------------------------------------------------------------------------");
				System.out.println("Author: Zeid Kootbally");
				System.out.println("Email: zeid.kootbally@nist.gov");
				System.out.println("National Institute of Standards and Technology");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("This tool reads OWL files and generates PDDL domain and problem files.");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("Usage: java -jar owl2pddl.jar");
				System.out.println("-------------------------------------------------------------------------------------------------------");
			}	
			else{
				System.out.println("\n\n-------------------------------------------------------------------------------------------------------");
				System.out.println("Author: Zeid Kootbally");
				System.out.println("Email: zeid.kootbally@nist.gov");
				System.out.println("National Institute of Standards and Technology");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("This tool reads OWL files and generates PDDL domain and problem files.");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("					ERROR: Unknown argument(s).");
				System.out.println("-------------------------------------------------------------------------------------------------------");
				System.out.println("Usage: java -jar owl2pddl.jar");
				System.out.println("-------------------------------------------------------------------------------------------------------");
			}
		}
		else{
			Parser myParser = new Parser();
			String owlSoapInstance = myParser.getM_soapInstancePath();
			String owlInitInstance = myParser.getM_initInstancePath();
			String owlGoalInstance = myParser.getM_goalInstancePath();
			String pddlDomain = myParser.getM_domainPath();
			String pddlProblem = myParser.getM_problemPath();

			final SoapOntology mySoapOntology = new SoapOntology();
			mySoapOntology.setM_PathToSoapInstanceFile(owlSoapInstance);
			mySoapOntology.setM_outputPDDLFile(pddlDomain);
			//myOntology.setManager();
			mySoapOntology.loadOntologyFromPath(owlSoapInstance);
			mySoapOntology.setReasoner();
			mySoapOntology.setM_OWLDataFactory(mySoapOntology.getM_OWLOntologyManager().getOWLDataFactory());
			OWLClass SoapOWLClass = mySoapOntology.getClass(mySoapOntology.getM_owl_class_SOAP()); 

			final Reader myReader = new Reader(mySoapOntology);
			final Writer myWriter = new Writer();
			//-- Parse the Soap ontology starting at SoapClass
			Soap mySoap = myReader.parseSOAP(SoapOWLClass);
			//-- Display what we have parsed so far
			//myReader.displaySoap(myOntology, mySoap);
			myWriter.writeDomain(mySoapOntology, mySoap);


			final InitOntology myInitOntology = new InitOntology();
			myInitOntology.setM_PathToInitInstanceFile(owlInitInstance);
			myInitOntology.loadOntologyFromPath(owlInitInstance);
			myInitOntology.setReasoner();
			myInitOntology.setM_OWLDataFactory(myInitOntology.getM_OWLOntologyManager().getOWLDataFactory());

			final GoalOntology myGoalOntology = new GoalOntology();
			myGoalOntology.setM_PathToGoalInstanceFile(owlGoalInstance);
			myGoalOntology.loadOntologyFromPath(owlGoalInstance);
			myGoalOntology.setReasoner();
			myGoalOntology.setM_OWLDataFactory(myGoalOntology.getM_OWLOntologyManager().getOWLDataFactory());

			Mapper myMapper = new Mapper(mySoapOntology,myInitOntology,myGoalOntology,mySoap);
			myMapper.mapProblemFile();
			myWriter.writeProblem(myMapper.getM_problem(), pddlProblem);
		}			
	}
}
