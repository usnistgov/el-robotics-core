/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package tools;

import java.text.Normalizer;
import java.text.Normalizer.Form;

/**
 * @brief Tools that are useful to clean OWL entities (object properties, data properties, classes, and individuals) by keeping only relevant data.
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 */
public class Cleaner {
	private static final char m_SEPARATOR = '#';
	private static final char m_SEPARATOR_DATAPROPERTY = '"';
	/**
	 * 
	 */
	public Cleaner() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @brief Returns an OWL entity (object properties and individuals)  without the IRI
	 * 
	 * @details For example, if @a entity = [<http://www.semanticweb.org/ontologies/2013/0/soap.owl#Kitting>], this function returns @a Kitting. 
	 * 
	 * This function operates as follows: 
	 * <ul>
	 * <li>Identify the index of the separator @a SEPARATOR
	 * <li>Keep only what is after the SEPARATOR
	 * <li>Remove characters that are not alphanumeric 
	 * </ul>
	 * @param entity Entity to be trimmed 
	 * @return Entity without the IRI
	 */
	public String cleanIRI(Object entity) {
		int index = entity.toString().indexOf(m_SEPARATOR);
		String new_entity = entity.toString().substring(index + 1);
		String normalized = Normalizer.normalize(new_entity.toString(),
				Form.NFD);
		String result = normalized.replaceAll("[^A-Za-z0-9-_]", "");

		return (result);
	}
	/**
	 * @brief Returns an OWL data property without the IRI
	 * 
	 * @details Only the string that is between quotes is returned
	 * @param entity Entity to be trimmed 
	 * @return Entity without the IRI
	 */
	public String cleanIRIDataProperty(Object entity) {
		int firstOccurrence = entity.toString().indexOf(m_SEPARATOR_DATAPROPERTY);
		int lastOccurrence = entity.toString().lastIndexOf(m_SEPARATOR_DATAPROPERTY);
		String new_entity = entity.toString().substring(firstOccurrence+1,lastOccurrence);
		return (new_entity);
	}
}
