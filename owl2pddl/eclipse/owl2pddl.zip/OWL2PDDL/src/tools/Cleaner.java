/**
 * 
 */
package tools;

import java.text.Normalizer;
import java.text.Normalizer.Form;

/**
 * @author zeid
 *
 */
public class Cleaner {
	private static final char m_SEPARATOR = '#';
	private static final char m_SEPARATOR_DATAPROPERTY = '"';
	/**
	 * 
	 */
	public Cleaner() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * \brief Return the name of the entity without the IRI
	 * 
	 * For example, if @a entity =
	 * [<http://www.semanticweb.org/ontologies/2013/0/soap.owl#Kitting>], this
	 * function returns @a Kitting. This function operates as follows: -
	 * Identify the index of the separator @a SEPARATOR - Keep only what is
	 * after the SEPARATOR - Remove characters that are not alphanumeric \param
	 * entity Entity to be trimmed \return The name of the entity without the
	 * IRI
	 */
	public String cleanIRI(Object entity) {
		int index = entity.toString().indexOf(m_SEPARATOR);
		String new_entity = entity.toString().substring(index + 1);
		String normalized = Normalizer.normalize(new_entity.toString(),
				Form.NFD);
		String result = normalized.replaceAll("[^A-Za-z0-9-_]", "");

		return (result);
	}
	
	public String cleanIRIDataProperty(Object entity) {
		int firstOccurrence = entity.toString().indexOf(m_SEPARATOR_DATAPROPERTY);
		int lastOccurrence = entity.toString().lastIndexOf(m_SEPARATOR_DATAPROPERTY);
		String new_entity = entity.toString().substring(firstOccurrence+1,lastOccurrence);
		return (new_entity);
	}
}
