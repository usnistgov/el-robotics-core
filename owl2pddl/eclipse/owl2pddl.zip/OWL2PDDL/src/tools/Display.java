/**
 * 
 */
package tools;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;

import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.FunctionOperation;
import knowledge.FunctionToFunctionBool;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.Soap;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Display {
	private Cleaner m_cleaner;
	/**
	 * 
	 */
	public Display() {
		m_cleaner = new Cleaner();
	}

	public void displayVariables(ArrayList<String> myList) {
		System.out
		.println("\n-----------------Domain Variables ----------------");
		for (int i = 0; i < myList.size(); i++)
			System.out.println("  " + myList.get(i));
	}

	public void displayRequirements(ArrayList<String> myList) {
		System.out
		.println("\n-----------------Domain Requirements ----------------");
		for (int i = 0; i < myList.size(); i++)
			System.out.println("  " + myList.get(i));
	}

	public void displayFunctions(ArrayList<Function> myList) {
		System.out.println("\n-----------------Functions ----------------");
		for (int i = 0; i < myList.size(); i++) {
			Function function = myList.get(i);

			if (!function.getM_target_parameter().isEmpty()) {
				System.out.println(" "
						+ function.getM_description()
						+ "\n "
						+ m_cleaner.cleanIRI(
								function.getM_individual()) + "("
								+ function.getM_reference_parameter() + ","
								+ function.getM_target_parameter() + ")");
			} else {
				System.out.println(" "
						+ function.getM_description()
						+ "\n "
						+ m_cleaner.cleanIRI(
								function.getM_individual()) + "("
								+ function.getM_reference_parameter() + ")");
			}
		}
	}

	public void displayPositivePredicates(ArrayList<PositivePredicate> myList) {
		System.out
		.println("\n-----------------Positive Predicates ----------------");
		for (int i = 0; i < myList.size(); i++) {
			PositivePredicate positivePredicate = myList.get(i);

			if (!positivePredicate.getM_target_parameter().isEmpty()) {
				System.out.println(" "
						+ positivePredicate.getM_description()
						+ "\n  "
						+ m_cleaner.cleanIRI(
								positivePredicate.getM_individual()) + "("
								+ positivePredicate.getM_reference_parameter() + ","
								+ positivePredicate.getM_target_parameter() + ")");
			} else {
				System.out.println(" "
						+ positivePredicate.getM_description()
						+ "\n  "
						+ m_cleaner.cleanIRI(
								positivePredicate.getM_individual()) + "("
								+ positivePredicate.getM_reference_parameter() + ")");
			}
		}
	}

	public void displaySoap(Soap mySoap) {
		OWLIndividual soapIndividual = mySoap.getM_individual();
		System.out.println("Soap: "
				+ m_cleaner.cleanIRI(soapIndividual));
		Domain domain = mySoap.getM_domain();
		System.out.println(" +Domain: "
				+ m_cleaner.cleanIRI(domain.getM_individual()));

		displayVariables(domain.getM_variable_list());
		displayRequirements(domain.getM_requirement_list());
		displayFunctions(domain.getM_function_list());
		displayPositivePredicates(domain.getM_positive_predicate_list());
		displayAction(domain);
	}

	public void displayPrecondition(Precondition myPrecondition) {
		System.out.println("\n +precondition: "
				+ m_cleaner.cleanIRI(myPrecondition.getM_individual()));
		ArrayList<String> l_predicate_list = myPrecondition
				.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myPrecondition
				.getM_f2f_list();
		ArrayList<FunctionOperation> l_function_operation_list = myPrecondition
				.getM_function_operation_list();

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				System.out.println("   +predicate: " + l_predicate_list.get(k));
			}
		}

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				System.out.println("   +f2fbool: " + f1 + " " + expression
						+ " " + f2);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				System.out.println("   +fop: " + l_expression + " "
						+ l_function + " " + l_value);
			}
		}
	}

	public void displayEffect(Effect myEffect) {
		System.out.println("+effect: "
				+ m_cleaner.cleanIRI(myEffect.getM_individual()));
		ArrayList<String> l_predicate_list = myEffect.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myEffect.getM_f2f_list();
		ArrayList<FunctionOperation> l_function_operation_list = myEffect
				.getM_function_operation_list();

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				System.out.println("   +predicate: " + l_predicate_list.get(k));
			}
		}

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				System.out.println("   +f2fbool: " + f1 + " " + expression
						+ " " + f2);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				System.out.println("   +fop: " + l_expression + " "
						+ l_function + " " + l_value);
			}
		}
	}

	/**
	 * @brief Display actions
	 * @param myOntology
	 * @param myDomain
	 */
	public void displayAction(Domain myDomain) {
		System.out.print("\n-----------------Actions----------------");
		// -- Display the list of parameters
		ArrayList<Action> l_action_list = myDomain.getM_action_list();
		for (int i = 0; i < l_action_list.size(); i++) {
			Action action = l_action_list.get(i);
			System.out.print("\n"
					+ m_cleaner.cleanIRI(action.getM_individual())
					+ "(");
			ArrayList<String> parameter_set_list = action.getM_parameter_set();
			// System.out.println("(");
			for (int j = 0; j < parameter_set_list.size(); j++) {
				if (j == parameter_set_list.size() - 1)
					System.out.print(parameter_set_list.get(j) + ")");
				else
					System.out.print(parameter_set_list.get(j) + ",");
			}
			displayPrecondition(action.getM_action_precondition());
			displayEffect(action.getM_action_effect());
		}
	}

	public void displayDataPropertyValuesMap(Map mp) {
		Iterator it = mp.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry) it.next();
			System.out.println(m_cleaner.cleanIRI(pairs.getKey())
					+ " = "
					+ m_cleaner.cleanIRIDataProperty(pairs.getValue()));
			it.remove(); // avoids a ConcurrentModificationException
		}
	}
}
