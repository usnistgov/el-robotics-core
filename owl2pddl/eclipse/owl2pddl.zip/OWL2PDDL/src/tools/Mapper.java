/**
 * 
 */
package tools;

import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

import knowledge.Domain;
import knowledge.GoalOntology;
import knowledge.InitOntology;
import knowledge.Ontology;
import knowledge.Soap;
import knowledge.SoapOntology;

/**
 * @author zeid
 *
 */
public class Mapper {
	private SoapOntology m_SoapOntology;
	private InitOntology m_InitOntology;
	private GoalOntology m_GoalOntology;
	private Soap m_Soap;

	private String m_objects_section;
	private String m_init_section;
	private String m_goal_section;
	private String m_problem;

	private static final char m_SEPARATOR = '#';
	private static final char m_SEPARATOR_DATAPROPERTY = '"';

	//-- This map is used to collect the different SKUs of parts that go in the final kit
	private Map<String, Collection<String>> m_kit_skuPart_map = new HashMap<String, Collection<String>>();

	/**
	 * 
	 */
	public Mapper(SoapOntology mySoapOntology, InitOntology myInitOntology,GoalOntology myGoalOntology, Soap mySoap) {
		// TODO Auto-generated constructor stub
		setM_SoapOntology(mySoapOntology);
		setM_InitOntology(myInitOntology);
		setM_GoalOntology(myGoalOntology);
		setM_Soap(mySoap);

	}

	public void map_endeffector_location_robot(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffector
		OWLClass endEffectorClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffector()); 
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.getInstances(endEffectorClass, false);
		if (!endEffectorNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffector,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type Robot
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
										getClass(getM_InitOntology().getM_owl_class_Robot())))==0){
									l_init_section=l_init_section+"		(endeffector-location-robot "+
											cleanIRI(endEffector)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}


	/**
	 * @brief mapper to build the predicates endeffectorholder-location and endeffectorchangingstation-contains-endeffectorholder
	 * EndEffectorHolder --> part_gripper_holder --> hasSolidObject_PrimaryLocation --> part_gripper_holder_pose --> hasPhysicalLocation_RefObject --> changing_station_1
	 */
	public void map_EndEffectorHolder_Location(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffectorHolder
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorHolder()); 
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.getInstances(endEffectorHolderClass, false);
		if (!endEffectorHolderNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffectorHolder get PrimaryLocation
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffectorHolder,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type EndEffectorChangingStation
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
										getClass(getM_InitOntology().getM_owl_class_EndEffectorChangingStation())))==0){
									l_init_section=l_init_section+"		(endeffectorholder-location "+
											cleanIRI(endEffectorHolder)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Map the predicate endeffectorchangingstation_contains_endeffectorholder to the init owl file
	 */
	public void map_endeffectorchangingstation_contains_endeffectorholder(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffectorChangingStation
		OWLClass endEffectorChangingStationClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorChangingStation()); 
		NodeSet<OWLNamedIndividual> endEffectorChangingStationNodeSet = l_OWLReasoner_Init.getInstances(endEffectorChangingStationClass, false);

		if (!endEffectorChangingStationNodeSet.isEmpty()){
			//-- Build the object property hasEndEffectorChangingStation_EndEffectorHolder
			OWLObjectProperty OP_hasEndEffectorChangingStation_EndEffectorHolder = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasEndEffectorChangingStation_EndEffectorHolder()));
			//-- for each EndEffectorChangingStation get EndEffectorHolder
			for (OWLNamedIndividual endEffectorChangingStation : endEffectorChangingStationNodeSet.getFlattened()){
				//-- get individuals for hasEndEffectorChangingStation_EndEffectorHolder
				NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffectorChangingStation,OP_hasEndEffectorChangingStation_EndEffectorHolder);
				if (!endEffectorHolderNodeSet.isEmpty()){
					for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened()) {
						l_init_section=l_init_section+"		(endeffectorchangingstation-contains-endeffectorholder "+
								cleanIRI(endEffectorChangingStation)+
								" "+
								cleanIRI(endEffectorHolder)+
								")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_with_endeffector(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						l_init_section=l_init_section+"		(robot-with-endeffector "+
								cleanIRI(robot)+
								" "+
								cleanIRI(endEffector)+
								")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_with_no_endeffector(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);

				if (endEffectorNodeSet.isEmpty()){
					l_init_section=l_init_section+"		(robot-with-no-endeffector "+
							cleanIRI(robot)+
							")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_on_worktable_kit(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_WorkTable()); 
		NodeSet<OWLNamedIndividual> workTableNodeSet = l_OWLReasoner_Init.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()){
			//-- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(workTable,OP_hasWorkTable_ObjectOnTable);
				if (!solidObjectNodeSet.isEmpty()){
					for (OWLNamedIndividual solidObject : solidObjectNodeSet.getFlattened()){
						Set<OWLClassExpression> solidObjectClass = solidObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
						if(cleanIRI(solidObjectClass).
								compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit())))==0){
							l_init_section=l_init_section+"		(on-worktable-kit "+
									cleanIRI(workTable)+
									" "+
									cleanIRI(solidObject)+
									")\n";
						}
					}



				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_on_worktable_kittray(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_WorkTable()); 
		NodeSet<OWLNamedIndividual> workTableNodeSet = l_OWLReasoner_Init.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()){
			//-- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(workTable,OP_hasWorkTable_ObjectOnTable);
				if (!solidObjectNodeSet.isEmpty()){
					for (OWLNamedIndividual solidObject : solidObjectNodeSet.getFlattened()){
						Set<OWLClassExpression> solidObjectClass = solidObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
						if(cleanIRI(solidObjectClass).
								compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray())))==0){
							l_init_section=l_init_section+"		(on-worktable-kittray "+
									cleanIRI(workTable)+
									" "+
									cleanIRI(solidObject)+
									")\n";
						}
					}



				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_kit_location_lbwk_init(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Init.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kit,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type LargeBoxWithKits
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
										getClass(getM_InitOntology().getM_owl_class_LargeBoxWithKits())))==0){
									l_init_section=l_init_section+"		(kit-location-lbwk "+
											cleanIRI(kit)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_kit_location_lbwk_goal(){
		OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_GoalOntology().getM_OWLDataFactory();
		String l_goal_section = getM_goal_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_GoalOntology().getM_goal_IRI() + 
							getM_GoalOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Goal.
						getObjectPropertyValues(kit,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
							getM_GoalOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Goal.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type LargeBoxWithKits
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_GoalOntology().getM_OWLGoalInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_GoalOntology().
										getClass(getM_GoalOntology().getM_owl_class_LargeBoxWithKits())))==0){
									l_goal_section=l_goal_section+"		(kit-location-lbwk "+
											cleanIRI(kit)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_goal_section(l_goal_section);
	}

	public void map_kit_location_robot(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Init.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kit,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type Robot
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
										getClass(getM_InitOntology().getM_owl_class_Robot())))==0){
									l_init_section=l_init_section+"		(kit-location-robot "+
											cleanIRI(kit)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	public void map_kit_location_worktable(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Init.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(
					IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));

			//-- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
				//-- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kit,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){
						//-- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){
								//-- get only refObject that is of type WorkTable
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
										getClass(getM_InitOntology().getM_owl_class_WorkTable())))==0){
									l_init_section=l_init_section+"		(kit-location-worktable "+
											cleanIRI(kit)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief mapper to build the predicate part-not-searched
	 */
	public void map_part_not_searched(){
		String l_init_section = getM_init_section();
		l_init_section=l_init_section+"		(part-not-searched)\n";
		setM_init_section(l_init_section);
	}
	/**
	 * @brief mapper to build the predicate lbwekt-not-empty
	 */
	public void map_lbwekt_not_empty(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class LargeBoxWithEmptyKitTrays
		OWLClass LargeBoxWithEmptyKitTraysClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithEmptyKitTrays()); 
		NodeSet<OWLNamedIndividual> largeBoxWithEmptyKitTraysNodeSet = l_OWLReasoner_Init.getInstances(LargeBoxWithEmptyKitTraysClass, false);

		if (!largeBoxWithEmptyKitTraysNodeSet.isEmpty()){
			//-- Build the object property hasLargeBoxWithEmptyKitTrays_KitTray
			OWLObjectProperty OP_hasLargeBoxWithEmptyKitTrays_KitTray = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasLargeBoxWithEmptyKitTrays_KitTray()));
			for (OWLNamedIndividual largeBoxWithEmptyKitTrays : largeBoxWithEmptyKitTraysNodeSet.getFlattened()){
				//-- get individuals for hasLargeBoxWithEmptyKitTrays_KitTray
				NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(largeBoxWithEmptyKitTrays,OP_hasLargeBoxWithEmptyKitTrays_KitTray);
				if (!kitTrayNodeSet.isEmpty()){
					l_init_section=l_init_section+"		(lbwekt-not-empty "+
							cleanIRI(largeBoxWithEmptyKitTrays)+
							")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief mapper to build the predicate lbwk-not-full
	 * 
	 * Get all the kit trays in the workstation
	 * Make sure all the kit trays are not in the lbwk
	 */
	public void map_lbwk_not_full(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();
		//-- Capacity of the LargeBoxWithKits
		int lbwkCapacity=0;
		//-- Number of kits currently in the LargeBoxWithKits
		int kitInLbwk=0;

		//-- Get each individual from the OWL class LargeBoxWithKits
		OWLClass LargeBoxWithKitsClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithKits()); 
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = l_OWLReasoner_Init.getInstances(LargeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()){
			//-- Build the data property hasLargeWithKits_Capacity
			OWLDataProperty DP_hasLargeWithKits_Capacity = l_OWLDataFactory.getOWLDataProperty(IRI.create(getM_InitOntology().getM_init_IRI()+		
					getM_InitOntology().getM_DP_hasLargeBoxWithKits_Capacity()));
			//-- Build the object property hasLargeWithKits_Kit
			OWLObjectProperty OP_hasLargeWithKits_Kit = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasLargeWithKits_Kit()));
			//System.out.println(DP_hasLargeWithKits_Capacity);
			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet.getFlattened()){	
				//-- Get all the data properties for each LargeBoxWithKits
				Map<OWLDataPropertyExpression,Set<OWLLiteral>> largeBoxWithKitsMap = 
						largeBoxWithKits.getDataPropertyValues(getM_InitOntology().getM_OWLInitInstanceOntology());

				//-- Find the capacity
				if(largeBoxWithKitsMap.get(DP_hasLargeWithKits_Capacity) != null) {
					for(OWLLiteral d : largeBoxWithKitsMap.get(DP_hasLargeWithKits_Capacity)) {
						//System.out.println(cleanIRIDataProperty(d));
						//-- Convert the result into an Integer
						lbwkCapacity=Integer.parseInt(cleanIRIDataProperty(d));
					}
				}

				//-- Check how many kits are in the LargeBoxWithKits
				NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(largeBoxWithKits,OP_hasLargeWithKits_Kit);
				if (!kitNodeSet.isEmpty()){
					for (OWLNamedIndividual kit : kitNodeSet.getFlattened())
						kitInLbwk++;
				}

				//-- Compare lbwkCapacity and kitInLbwk
				//-- If lbwkCapacity!=kitInLbwk then largeBoxWithKits is not full
				if (lbwkCapacity>kitInLbwk || lbwkCapacity<kitInLbwk){
					l_init_section=l_init_section+"		(lbwk-not-full "+
							cleanIRI(largeBoxWithKits)+
							")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}


	/**
	 * @brief mapper to build the predicate partstray-not-empty
	 * Get all the parts trays
	 * For each part tray, check there is at least one Part using the object predicate hasPartsVessel_Part
	 */
	public void map_partstray_not_empty(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class PartsTray
		OWLClass partsTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray()); 
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.getInstances(partsTrayClass, false);
		if (!partsTrayNodeSet.isEmpty()){
			//-- Build the object property hasPartsVessel_Part
			OWLObjectProperty OP_hasPartsVessel_Part = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasPartsVessel_Part()));
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(partsTray,OP_hasPartsVessel_Part);
				//-- If the NodeSet is not empty, it means there is at least 1 part in the parts tray
				if (!partNodeSet.isEmpty()){
					l_init_section=l_init_section+"		(partstray-not-empty "+
							cleanIRI(partsTray)+
							")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_partstray_has_part(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class PartsTray
		OWLClass partsTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray()); 
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()){
			//-- Build the object property hasPartsVessel_Part
			OWLObjectProperty OP_hasPartsVessel_Part = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasPartsVessel_Part()));
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(partsTray,OP_hasPartsVessel_Part);
				if (!partNodeSet.isEmpty()){
					for (OWLNamedIndividual part : partNodeSet.getFlattened()){
						l_init_section=l_init_section+"		(partstray-has-part  "+ cleanIRI(partsTray)+" "+cleanIRI(part)+")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate endeffector-location-endeffectorholder
	 * EndEffector --> part_gripper --> hasSolidObject_PrimaryLocation --> part_gripper_pose --> hasPhysicalLocation_RefObject --> part_gripper_holder
	 */
	public void map_endeffector_location_endeffectorholder(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffector
		OWLClass endEffectorClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffector()); 
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.getInstances(endEffectorClass, false);

		if (!endEffectorNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffector,OP_hasSolidObject_PrimaryLocation);


				if (!locationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual location : locationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(location,OP_hasPhysicalLocation_RefObject);
						if (!endEffectorHolderNodeSet.isEmpty()){
							for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened()){	
								//-- check if  endEffectorHolder is from the OWL Class EndEffectorHolder
								Set<OWLClassExpression> endEffectorHolderClass = endEffectorHolder.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(endEffectorHolderClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorHolder())))==0){
									l_init_section=l_init_section+"		(endeffector-location-endeffectorholder "+
											cleanIRI(endEffector)+
											" "+
											cleanIRI(endEffectorHolder)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief mapper to build the predicate endeffectorholder-holds-endeffector
	 */
	public void map_endeffectorholder_holds_endeffector(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffectorHolder
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorHolder()); 
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.getInstances(endEffectorHolderClass, false);

		if (!endEffectorHolderNodeSet.isEmpty()){
			//-- Build the object property hasEndEffectorHolder_EndEffector
			OWLObjectProperty OP_hasEndEffectorHolder_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasEndEffectorHolder_EndEffector()));
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffectorHolder,OP_hasEndEffectorHolder_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						l_init_section=l_init_section+"		(endeffectorholder-holds-endeffector "+
								cleanIRI(endEffectorHolder)+
								" "+
								cleanIRI(endEffector)+
								")\n";
					}	
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_endeffectorholder_empty(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class EndEffectorHolder
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorHolder()); 
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.getInstances(endEffectorHolderClass, false);

		if (!endEffectorHolderNodeSet.isEmpty()){
			//-- Build the object property hasEndEffectorHolder_EndEffector
			OWLObjectProperty OP_hasEndEffectorHolder_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasEndEffectorHolder_EndEffector()));
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(endEffectorHolder,OP_hasEndEffectorHolder_EndEffector);
				if (endEffectorNodeSet.isEmpty()){
					l_init_section=l_init_section+"		(endeffectorholder-empty "+ cleanIRI(endEffectorHolder)+")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate worktable-empty
	 */
	public void map_worktable_empty(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_WorkTable()); 
		NodeSet<OWLNamedIndividual> workTableNodeSet = l_OWLReasoner_Init.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()){
			//-- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(workTable,OP_hasWorkTable_ObjectOnTable);
				if (solidObjectNodeSet.isEmpty()){
					l_init_section=l_init_section+"		(worktable-empty "+
							cleanIRI(workTable)+
							")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}


	/**
	 * @brief mapper to build the predicate kittray-location-lbwekt
	 * KitTray --> kit_tray_1 --> hasSolidObject_PrimaryLocation --> kit_tray_1_pose --> hasPhysicalLocation_RefObject --> empty_kit_tray_supply
	 */
	public void map_kittray_location_lbwekt(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray()); 
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kitTray,OP_hasSolidObject_PrimaryLocation);


				if (!locationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual location : locationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> largeBoxWithEmptyKitTraysNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(location,OP_hasPhysicalLocation_RefObject);
						if (!largeBoxWithEmptyKitTraysNodeSet.isEmpty()){
							for (OWLNamedIndividual largeBoxWithEmptyKitTrays : largeBoxWithEmptyKitTraysNodeSet.getFlattened()){	
								//-- check if  largeBoxWithEmptyKitTrays is from the OWL Class LargeBoxWithEmptyKitTrays
								Set<OWLClassExpression> largeBoxWithEmptyKitTraysClass = largeBoxWithEmptyKitTrays.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(largeBoxWithEmptyKitTraysClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithEmptyKitTrays())))==0){
									l_init_section=l_init_section+"		(kittray-location-lbwekt "+
											cleanIRI(kitTray)+
											" "+
											cleanIRI(largeBoxWithEmptyKitTrays)+
											")\n";
								}
							}
						}
					}
				}
			}
		}


		setM_init_section(l_init_section);
	}

	public void map_kittray_location_robot(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray()); 
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kitTray,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){	
								//-- check if  refObject is from the OWL Class Robot
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).
										compareTo(cleanIRI(getM_InitOntology().
												getClass(getM_InitOntology().
														getM_owl_class_Robot())))==0){
									l_init_section=l_init_section+"		(kittray-location-robot "+
											cleanIRI(kitTray)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_kittray_location_worktable(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray()); 
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kitTray,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){	
								//-- check if  refObject is from the OWL Class WorkTable
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).
										compareTo(cleanIRI(getM_InitOntology().
												getClass(getM_InitOntology().
														getM_owl_class_WorkTable())))==0){
									l_init_section=l_init_section+"		(kittray-location-worktable "+
											cleanIRI(kitTray)+
											" "+
											cleanIRI(refObject)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate part-location-partstray
	 * Part --> part_a_1 --> hasSolidObject_PrimaryLocation --> part_a_1_pose --> hasPhysicalLocation_RefObject --> part_a_tray
	 */
	public void map_part_location_partstray(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(part,OP_hasSolidObject_PrimaryLocation);
				if (!locationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual location : locationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(location,OP_hasPhysicalLocation_RefObject);
						if (!partsTrayNodeSet.isEmpty()){
							for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()){	
								//-- check if  largeBoxWithEmptyKitTrays is from the OWL Class LargeBoxWithEmptyKitTrays
								Set<OWLClassExpression> partsTrayClass = partsTray.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(partsTrayClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray())))==0){
									l_init_section=l_init_section+"		(part-location-partstray "+
											cleanIRI(part)+
											" "+
											cleanIRI(partsTray)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_part_location_kit(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(part,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){	
								//-- check if  refObject is of type Kit
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit())))==0){
									l_init_section=l_init_section+"		(part-location-kit "+cleanIRI(part)+" "+cleanIRI(refObject)+")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_part_location_robot(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(part,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> refObjectNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()){
							for (OWLNamedIndividual refObject : refObjectNodeSet.getFlattened()){	
								//-- check if  refObject is of type Robot or EndEffector
								Set<OWLClassExpression> refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot())))==0){
									l_init_section=l_init_section+"		(part-location-robot "+cleanIRI(part)+" "+cleanIRI(refObject)+")\n";
								} //-- The part is in the endeffector, find the robot to which the endeffector is attached 
								else if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffector())))==0){

									//-- get individuals for hasSolidObject_PrimaryLocation
									primaryLocationNodeSet = l_OWLReasoner_Init.
											getObjectPropertyValues(refObject,OP_hasSolidObject_PrimaryLocation);
									if (!primaryLocationNodeSet.isEmpty()){
										for (OWLNamedIndividual primaryLocation2 : primaryLocationNodeSet.getFlattened()){
											//-- get individuals for hasSolidObject_PrimaryLocation
											refObjectNodeSet = l_OWLReasoner_Init.
													getObjectPropertyValues(primaryLocation2,OP_hasPhysicalLocation_RefObject);
											if (!refObjectNodeSet.isEmpty()){
												for (OWLNamedIndividual refObject2 : refObjectNodeSet.getFlattened()){
													//-- get only refObject that is of type Robot
													refObjectClass = refObject.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
													if(cleanIRI(refObjectClass).compareTo(cleanIRI(getM_InitOntology().
															getClass(getM_InitOntology().getM_owl_class_Robot())))==0){
														l_init_section=l_init_section+"		(part-location-robot "+cleanIRI(part)+" "+cleanIRI(refObject)+")\n";
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_holds_kittray(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					//-- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(endEffector,OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()){
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet.getFlattened()){
								//-- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								//-- Check if objectHeld is of type KitTray
								if(cleanIRI(objectHeldClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray())))==0){
									l_init_section=l_init_section+"		(robot-holds-kittray "+cleanIRI(robot)+" "+cleanIRI(objectHeld)+")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_holds_kit(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					//-- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(endEffector,OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()){
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet.getFlattened()){
								//-- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								//-- Check if objectHeld is of type KitTray
								if(cleanIRI(objectHeldClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit())))==0){
									l_init_section=l_init_section+"		(robot-holds-kit "+cleanIRI(robot)+" "+cleanIRI(objectHeld)+")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_holds_part(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					//-- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(endEffector,OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()){
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet.getFlattened()){
								//-- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								//-- Check if objectHeld is of type KitTray
								if(cleanIRI(objectHeldClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part())))==0){
									l_init_section=l_init_section+"		(robot-holds-part "+cleanIRI(robot)+" "+cleanIRI(objectHeld)+")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	public void map_robot_empty(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			//-- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			//-- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(robot,OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()){
					//-- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(endEffector,OP_hasEndEffector_HeldObject);
						if (objectHeldNodeSet.isEmpty()){
							l_init_section=l_init_section+"		(robot-empty "+cleanIRI(robot)+")\n";
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief mapper to build the predicate endeffector-type-part
	 * Part --> part_a_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_a --> hasStockKeepingUnit_EndEffector --> part_gripper
	 */
	public void map_endeffector_type_part(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(part,OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()){
					//-- Build the object property hasStockKeepingUnit_EndEffector
					OWLObjectProperty OP_hasStockKeepingUnit_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasStockKeepingUnit_EndEffector()));
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(sku,OP_hasStockKeepingUnit_EndEffector);
						if (!endEffectorNodeSet.isEmpty()){
							for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
								l_init_section=l_init_section+"		(endeffector-type-part "+
										cleanIRI(endEffector)+
										" "+
										cleanIRI(part)+
										")\n";
							}

						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate endeffector-type-kittray
	 */
	public void map_endeffector_type_kittray(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray()); 
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kitTray,OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()){
					//-- Build the object property hasStockKeepingUnit_EndEffector
					OWLObjectProperty OP_hasStockKeepingUnit_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasStockKeepingUnit_EndEffector()));
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(sku,OP_hasStockKeepingUnit_EndEffector);
						if (!endEffectorNodeSet.isEmpty()){
							for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
								l_init_section=l_init_section+"		(endeffector-type-kittray "+
										cleanIRI(endEffector)+
										" "+
										cleanIRI(kitTray)+
										")\n";
							}

						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate endeffector-type-kit
	 * Kit --> kit_a2b1c1 --> hasKit_KitTray --> kit_tray_1 --> hasSkuObject_Sku --> stock_keeping_unit_kit_tray --> hasStockKeepingUnit_EndEffector --> tray_gripper
	 */
	public void map_endeffector_type_kit(){
		OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();

		OWLDataFactory l_OWLDataFactory = getM_GoalOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(getM_InitOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasKit_KitTray
			OWLObjectProperty OP_hasKit_KitTray = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
					getM_GoalOntology().getM_OP_hasKit_KitTray()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){	
				NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Goal.
						getObjectPropertyValues(kit,OP_hasKit_KitTray);

				if (!kitTrayNodeSet.isEmpty()){
					OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
							getM_GoalOntology().getM_OP_hasSkuObject_Sku()));
					for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Goal.
								getObjectPropertyValues(kitTray,OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()){
							OWLObjectProperty OP_hasStockKeepingUnit_EndEffector = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
									getM_GoalOntology().getM_OP_hasStockKeepingUnit_EndEffector()));
							for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){
								NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Goal.
										getObjectPropertyValues(sku,OP_hasStockKeepingUnit_EndEffector);
								if (!endEffectorNodeSet.isEmpty()){
									for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened()){
										l_init_section=l_init_section+"		(endeffector-type-kit "+
												cleanIRI(endEffector)+
												" "+
												cleanIRI(kit)+
												")\n";
									}

								}
							}
						}
					}
				}
			}
		}

		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate capacity-kit
	 * Kit --> kit_a2b1c1 --> hasKit_Part --> part_a_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_a +1=1
	 * Kit --> kit_a2b1c1 --> hasKit_Part --> part_a_2 --> hasSkuObject_Sku --> stock_keeping_unit_part_a +1=2 --> stock_keeping_unit_part_a=2
	 * Kit --> kit_a2b1c1 --> hasKit_Part --> part_b_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_b +1=1 --> stock_keeping_unit_part_b=1
	 * Kit --> kit_a2b1c1 --> hasKit_Part --> part_c_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_c +1=1 --> stock_keeping_unit_part_c=1
	 */
	public void map_capacity_kit(){
		Map<String, Collection<String>> l_kit_skuPart_map = new HashMap<String, Collection<String>>();

		Map<String, Integer> partSKUNumber_map = new HashMap<String, Integer>();

		OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_GoalOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit()); 
		//System.out.println("Kit class: "+kitClass);
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasKit_Part
			OWLObjectProperty OP_hasKit_Part = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
					getM_GoalOntology().getM_OP_hasKit_Part()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){	
				//System.out.println("Kit: "+kit);
				NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Goal.
						getObjectPropertyValues(kit,OP_hasKit_Part);

				if (!partNodeSet.isEmpty()){
					OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
							getM_GoalOntology().getM_OP_hasSkuObject_Sku()));
					Collection<String> values = l_kit_skuPart_map.get(cleanIRI(kit));
					if (values==null){
						values = new ArrayList<String>();
						l_kit_skuPart_map.put(cleanIRI(kit), values);
					}

					for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
						//System.out.println("Part: "+part);
						NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Goal.
								getObjectPropertyValues(part,OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()){
							for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){

								if (!values.contains(cleanIRI(sku)))
									values.add(cleanIRI(sku));

								if (!partSKUNumber_map.isEmpty()){
									if (!partSKUNumber_map.containsKey(getM_GoalOntology().cleanIRI(sku))){
										partSKUNumber_map.put(getM_GoalOntology().cleanIRI(sku), 1);
									}
									else{
										partSKUNumber_map.put(getM_GoalOntology().cleanIRI(sku), partSKUNumber_map.get(getM_GoalOntology().cleanIRI(sku))+1);
									}
								}
								else{
									partSKUNumber_map.put(getM_GoalOntology().cleanIRI(sku), 1);
								}
							}
						}
					}
				}
				Iterator<Entry<String, Integer>> it = partSKUNumber_map.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Integer> pairs = it.next();
					//System.out.println("--------> "+pairs.getKey() + " = " + pairs.getValue());
					l_init_section=l_init_section+"		(= (capacity-kit  "+
							cleanIRI(kit)+
							" "+
							pairs.getKey()+
							") "+
							pairs.getValue()+
							")\n";
					it.remove(); // avoids a ConcurrentModificationException
				}
				partSKUNumber_map.clear();
			}
		}
		setM_init_section(l_init_section);
		setM_kit_skuPart_map(l_kit_skuPart_map);
	}

	/**
	 * @brief mapper to build the predicate quantity-kit
	 * Kit --> kit_a2b1c1
	 * Part --> part_a_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_a
	 * Part --> part_b_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_b
	 * Part --> part_c_1 --> hasSkuObject_Sku --> stock_keeping_unit_part_c
	 * 
	 */
	public void map_quantity_kit(){
		Map<String, Integer> partSKUNumber_map = new HashMap<String, Integer>();
		ArrayList<String> partSKU_list = new ArrayList<String>();
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Kit in the init file
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Init.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()){
			//-- Build the object property hasKit_Part
			OWLObjectProperty OP_hasKit_Part = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasKit_Part()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){	

				NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(kit,OP_hasKit_Part);

				if (!partNodeSet.isEmpty()){
					OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasSkuObject_Sku()));
					for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
						//System.out.println("Part: "+part);
						NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(part,OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()){
							for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){
								if (!partSKUNumber_map.isEmpty()){
									if (!partSKUNumber_map.containsKey(cleanIRI(sku))){
										partSKUNumber_map.put(cleanIRI(sku), 1);
									}
									else{
										partSKUNumber_map.put(cleanIRI(sku), partSKUNumber_map.get(cleanIRI(sku))+1);
									}
								}
								else{
									partSKUNumber_map.put(cleanIRI(sku), 1);
								}
							}
						}
					}
				}
				Iterator<Entry<String, Integer>> it = partSKUNumber_map.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Integer> pairs = it.next();
					//System.out.println("--------> "+pairs.getKey() + " = " + pairs.getValue());
					l_init_section=l_init_section+"		(= (quantity-kit  "+
							cleanIRI(kit)+
							" "+
							pairs.getKey()+
							") "+
							pairs.getValue()+
							")\n";
					it.remove(); // avoids a ConcurrentModificationException
				}
				partSKUNumber_map.clear();
			}
		}
		//-- kitNodeSet is empty
		//-- Let's get the kit in the goal file
		else{
			OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();
			l_OWLDataFactory = getM_GoalOntology().getM_OWLDataFactory();

			//-- Get each individual from the OWL class Kit in the goal file
			kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit()); 
			kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);

			//-- Get each individual from the OWL class Part in the goal file
			OWLClass partClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Part()); 
			NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Goal.getInstances(partClass, false);

			if (!kitNodeSet.isEmpty() && !partNodeSet.isEmpty()){
				OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI() + 
						getM_GoalOntology().getM_OP_hasSkuObject_Sku()));
				for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
					for (OWLNamedIndividual part : partNodeSet.getFlattened()){
						NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Goal.
								getObjectPropertyValues(part,OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()){
							for (OWLNamedIndividual sku : skuNodeSet.getFlattened()){
								if (!partSKU_list.isEmpty()){
									if (!partSKU_list.contains(getM_GoalOntology().cleanIRI(sku))){
										partSKU_list.add(getM_GoalOntology().cleanIRI(sku));
									}
								}
								else{
									partSKU_list.add(getM_GoalOntology().cleanIRI(sku));
								}
							}
						}
					}
					for(int i=0; i<partSKU_list.size();i++ )
					{
						//System.out.println(partSKU_list.get(i));
						l_init_section=l_init_section+"		(= (quantity-kit  "+
								cleanIRI(kit)+
								" "+
								partSKU_list.get(i)+
								") 0)\n";
					}
					partSKU_list.clear();
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate quantity-partstray
	 */
	public void map_quantity_partstray(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partsTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray()); 
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()){
			//-- Build the object property hasPartsVessel_Part
			OWLObjectProperty OP_hasPartsVessel_Part = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasPartsVessel_Part()));
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()){
				int numberOfParts=0;
				NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(partsTray,OP_hasPartsVessel_Part);
				if (!partNodeSet.isEmpty()){
					for (OWLNamedIndividual part : partNodeSet.getFlattened()){
						numberOfParts++;
					}
				}
				l_init_section=l_init_section+"		(= (quantity-of-parts-in-partstray  "+
						cleanIRI(partsTray)+") "+numberOfParts+")\n";
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate origin-part
	 */
	public void map_origin_part(){
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		String l_init_section = getM_init_section();

		//-- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			//-- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
					getM_InitOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){	
				//-- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = l_OWLReasoner_Init.
						getObjectPropertyValues(part,OP_hasSolidObject_PrimaryLocation);
				if (!locationNodeSet.isEmpty()){
					//-- Build the object property hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI() + 
							getM_InitOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual location : locationNodeSet.getFlattened()){	
						NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.
								getObjectPropertyValues(location,OP_hasPhysicalLocation_RefObject);
						if (!partsTrayNodeSet.isEmpty()){
							for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()){	
								//-- check if  largeBoxWithEmptyKitTrays is from the OWL Class LargeBoxWithEmptyKitTrays
								Set<OWLClassExpression> partsTrayClass = partsTray.getTypes(getM_InitOntology().getM_OWLInitInstanceOntology());
								if(cleanIRI(partsTrayClass).
										compareTo(cleanIRI(getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray())))==0){
									l_init_section=l_init_section+"		(origin-part "+
											cleanIRI(part)+
											" "+
											cleanIRI(partsTray)+
											")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate quantity-kit_and_capacity-kit
	 */

	public void map_quantity_kit_capacity_kit(){
		Map<String, Collection<String>> l_kit_skuPart_map = getM_kit_skuPart_map();
		String l_goal_section = getM_goal_section();

		for (Map.Entry<String, Collection<String>> entry : l_kit_skuPart_map.entrySet()) {
			String kit = entry.getKey();
			Collection<String> skuList = entry.getValue();
			//System.out.println("Key = " + kit);
			for (String sku: skuList){
				//System.out.println("Values = " + sku + "\n");
				l_goal_section = l_goal_section+"		(= (quantity-kit "+kit+" "+sku+") "+"(capacity-kit "+kit+" "+sku+"))\n";
			}
		}
		setM_goal_section(l_goal_section);
	}

	public void mapProblemFile(){
		//-- build the header for the problem file
		Soap soap = getM_Soap();
		Domain domain = soap.getM_domain();
		String l_problem = "(define (problem kitting-problem)\n"+
				"	(:domain "+cleanIRI(domain.getM_individual())+")\n";
		//-- Map the objects section
		mapObjects();
		//-- Map the init section
		mapInitState();
		//-- Map the goal section
		mapGoalState();

		l_problem = l_problem+getM_objects_section()+getM_init_section()+getM_goal_section()+
				"\n)";
		//System.out.println(l_problem);
		setM_problem(l_problem);
	}

	/**
	 * @brief Build the objects section for the problem file
	 */
	public void mapObjects(){
		//m_InitOntology.setReasoner();
		OWLReasoner l_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();

		String l_objects_section = "	(:objects\n";
		//-- get the individuals for each type of object

		//-- Robot --//
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot()); 
		NodeSet<OWLNamedIndividual> robotNodeSet = l_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(robot)+" ";

			l_objects_section = l_objects_section+"- Robot\n";
		}
		//-- EndEffectorChangingStation --//
		OWLClass endEffectorChangingStationClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorChangingStation()); 
		NodeSet<OWLNamedIndividual> endEffectorChangingStationNodeSet = l_OWLReasoner_Init.getInstances(endEffectorChangingStationClass, false);
		if (!endEffectorChangingStationNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual endEffectorChangingStation : endEffectorChangingStationNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(endEffectorChangingStation)+" ";

			l_objects_section = l_objects_section+"- EndEffectorChangingStation\n";
		}
		//-- KitTray --//
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray()); 
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = l_OWLReasoner_Init.getInstances(kitTrayClass, false);
		if (!kitTrayNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){
				//System.out.println("kiTray: "+ kitTray);
				l_objects_section = l_objects_section+cleanIRI(kitTray)+" ";
			}

			l_objects_section = l_objects_section+"- KitTray\n";
		}

		//-- Kit --//
		OWLClass kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit()); 
		NodeSet<OWLNamedIndividual> kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()){
				//System.out.println("kit: "+ kit);
				l_objects_section = l_objects_section+getM_GoalOntology().cleanIRI(kit)+" ";
			}

			l_objects_section = l_objects_section+"- Kit\n";
		}

		//-- LargeBoxWithEmptyKitTrays --//
		OWLClass largeBoxWithEmptyKitTraysClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithEmptyKitTrays()); 
		NodeSet<OWLNamedIndividual> largeBoxWithEmptyKitTraysNodeSet = l_OWLReasoner_Init.getInstances(largeBoxWithEmptyKitTraysClass, false);

		if (!largeBoxWithEmptyKitTraysNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual largeBoxWithEmptyKitTrays : largeBoxWithEmptyKitTraysNodeSet.getFlattened()){
				//System.out.println("largeBoxWithEmptyKitTrays: "+ largeBoxWithEmptyKitTrays);
				l_objects_section = l_objects_section+cleanIRI(largeBoxWithEmptyKitTrays)+" ";
			}

			l_objects_section = l_objects_section+"- LargeBoxWithEmptyKitTrays\n";
		}

		//-- LargeBoxWithKits --//
		OWLClass largeBoxWithKitsClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithKits()); 
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = l_OWLReasoner_Init.getInstances(largeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(largeBoxWithKits)+" ";

			l_objects_section = l_objects_section+"- LargeBoxWithKits\n";
		}

		//-- WorkTable --//
		OWLClass workTableClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_WorkTable()); 
		NodeSet<OWLNamedIndividual> workTableNodeSet = l_OWLReasoner_Init.getInstances(workTableClass, false);

		if (!workTableNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(workTable)+" ";

			l_objects_section = l_objects_section+"- WorkTable\n";
		}

		//-- PartsTray --//
		OWLClass partsTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_PartsTray()); 
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = l_OWLReasoner_Init.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(partsTray)+" ";

			l_objects_section = l_objects_section+"- PartsTray\n";
		}

		//-- Part --//
		OWLClass partClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Part()); 
		NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Init.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual part : partNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(part)+" ";

			l_objects_section = l_objects_section+"- Part\n";
		}

		//-- EndEffector --//
		OWLClass endEffectorClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffector()); 
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = l_OWLReasoner_Init.getInstances(endEffectorClass, false);

		if (!endEffectorNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual endEffector : endEffectorNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(endEffector)+" ";

			l_objects_section = l_objects_section+"- EndEffector\n";
		}

		//-- EndEffectorHolder --//
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_EndEffectorHolder()); 
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = l_OWLReasoner_Init.getInstances(endEffectorHolderClass, false);

		if (!endEffectorHolderNodeSet.isEmpty()){
			l_objects_section = l_objects_section+"		";
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet.getFlattened())
				l_objects_section = l_objects_section+cleanIRI(endEffectorHolder)+" ";

			l_objects_section = l_objects_section+"- EndEffectorHolder\n";
		}

		//-- Close the objects section
		l_objects_section = l_objects_section+"	)\n";
		//System.out.println(l_objects_section);
		setM_objects_section(l_objects_section);
	}

	/**
	 * @brief mapper to build the predicate lbwk-not-full
	 */
	public void mapInitState(){
		String l_init_section = "	(:init\n";
		setM_init_section(l_init_section);

		//-- endeffector-location-robot
		map_endeffector_location_robot();
		//-- endeffectorholder-location
		map_EndEffectorHolder_Location();
		//-- endeffectorchangingstation-contains-endeffectorholder
		map_endeffectorchangingstation_contains_endeffectorholder();
		//--robot-with-endeffector
		map_robot_with_endeffector();
		//--robot-with-no-endeffector
		map_robot_with_no_endeffector();
		//-- on-worktable-kit
		map_on_worktable_kit();
		//-- on-worktable-kittray
		map_on_worktable_kittray();
		//-- kit-location-lbwk
		map_kit_location_lbwk_init();
		//-- kit-location-worktable
		map_kit_location_worktable();
		//-- kit-location-robot
		map_kit_location_robot();
		//-- part-not-searched
		map_part_not_searched();	
		//-- lbwekt-not-empty
		map_lbwekt_not_empty();
		//-- lbwk-not-full
		map_lbwk_not_full();
		//-- partstray-not-empty
		map_partstray_not_empty();
		//-- partstray-has-part
		map_partstray_has_part();
		//-- endeffector-location-endeffectorholder
		map_endeffector_location_endeffectorholder();
		//-- endeffectorholder-holds-endeffector
		map_endeffectorholder_holds_endeffector();
		//-- endeffectorholder-empty
		map_endeffectorholder_empty();
		//-- worktable-empty
		map_worktable_empty();
		//-- kittray-location-lbwekt
		map_kittray_location_lbwekt();
		//-- kittray-location-robot
		map_kittray_location_robot();
		//-- kittray-location-worktable
		map_kittray_location_worktable();
		//-- part-location-partstray
		map_part_location_partstray();
		//-- part-location-kit
		map_part_location_kit();
		//-- part-location-robot
		map_part_location_robot();
		//-- robot-holds-kittray
		map_robot_holds_kittray();
		//-- robot-holds-kit
		map_robot_holds_kit();
		//-- robot-holds-part
		map_robot_holds_part();
		//-- robot-empty
		map_robot_empty();
		//-- endeffector-type-part
		map_endeffector_type_part();
		//-- endeffector-type-kittray
		map_endeffector_type_kittray();
		//-- endeffector-type-kit
		map_endeffector_type_kit();
		//-- (= (capacity-kit kit_a2b1c1 stock_keeping_unit_part_a) 2)
		map_capacity_kit();
		//-- (= (quantity-kit  kit_1 stock_keeping_unit_part_a) 0)
		map_quantity_kit();
		//-- (= (quantity-of-parts-in-partstray  part_a_tray) 2)
		map_quantity_partstray();
		//-- origin-part
		map_origin_part();

		l_init_section=getM_init_section();
		l_init_section = l_init_section+"	)\n";
		setM_init_section(l_init_section);
	}

	/**
	 * @brief mapper to build the predicate lbwk-not-full
	 */
	public void mapGoalState(){
		String l_goal_section = "	(:goal\n"+"		(and\n";
		setM_goal_section(l_goal_section);
		//-- (= (quantity-kit kit_a2b1c1 part_a_tray) (capacity-kit kit_a2b1c1 part_a_tray))
		map_quantity_kit_capacity_kit();
		//-- (kit-location-lbwk kit_a2b1c1 finished_kit_receiver)
		map_kit_location_lbwk_goal();
		l_goal_section = getM_goal_section();
		l_goal_section = l_goal_section+"		)\n"+"	)";
		setM_goal_section(l_goal_section);

		//System.out.println(getM_goal_section());
	}

	/**
	 * @return the m_SoapOntology
	 */
	public SoapOntology getM_SoapOntology() {
		return m_SoapOntology;
	}

	/**
	 * @param m_SoapOntology the m_SoapOntology to set
	 */
	public void setM_SoapOntology(SoapOntology m_SoapOntology) {
		this.m_SoapOntology = m_SoapOntology;
	}

	/**
	 * @return the m_InitOntology
	 */
	public InitOntology getM_InitOntology() {
		return m_InitOntology;
	}

	/**
	 * @param m_InitOntology the m_InitOntology to set
	 */
	public void setM_InitOntology(InitOntology m_InitOntology) {
		this.m_InitOntology = m_InitOntology;
	}

	/**
	 * @return the m_GoalOntology
	 */
	public GoalOntology getM_GoalOntology() {
		return m_GoalOntology;
	}

	/**
	 * @param m_GoalOntology the m_GoalOntology to set
	 */
	public void setM_GoalOntology(GoalOntology m_GoalOntology) {
		this.m_GoalOntology = m_GoalOntology;
	}

	/**
	 * @return the m_objects_section
	 */
	public String getM_objects_section() {
		return m_objects_section;
	}

	/**
	 * @param m_objects_section the m_objects_section to set
	 */
	public void setM_objects_section(String m_objects_section) {
		this.m_objects_section = m_objects_section;
	}

	/**
	 * @return the m_init_section
	 */
	public String getM_init_section() {
		return m_init_section;
	}

	/**
	 * @param m_init_section the m_init_section to set
	 */
	public void setM_init_section(String m_init_section) {
		this.m_init_section = m_init_section;
	}

	/**
	 * @return the m_goal_section
	 */
	public String getM_goal_section() {
		return m_goal_section;
	}

	/**
	 * @param m_goal_section the m_goal_section to set
	 */
	public void setM_goal_section(String m_goal_section) {
		this.m_goal_section = m_goal_section;
	}


	public String cleanIRI(Object entity) {
		int index = entity.toString().indexOf(m_SEPARATOR);
		String new_entity = entity.toString().substring(index + 1);
		String normalized = Normalizer.normalize(new_entity.toString(),
				Form.NFD);
		String result = normalized.replaceAll("[^A-Za-z0-9-_]", "");

		return (result);
	}

	public String cleanIRIDataProperty(Object entity) {
		int firstOccurrence = entity.toString().indexOf(m_SEPARATOR_DATAPROPERTY);
		int lastOccurrence = entity.toString().lastIndexOf(m_SEPARATOR_DATAPROPERTY);
		String new_entity = entity.toString().substring(firstOccurrence+1,lastOccurrence);
		return (new_entity);
	}

	/**
	 * @return the m_kit_skuPart_map
	 */
	public Map<String, Collection<String>> getM_kit_skuPart_map() {
		return m_kit_skuPart_map;
	}

	/**
	 * @param m_kit_skuPart_map the m_kit_skuPart_map to set
	 */
	public void setM_kit_skuPart_map(Map<String, Collection<String>> m_kit_skuPart_map) {
		this.m_kit_skuPart_map = m_kit_skuPart_map;
	}

	/**
	 * @return the m_problem
	 */
	public String getM_problem() {
		return m_problem;
	}

	/**
	 * @param m_problem the m_problem to set
	 */
	public void setM_problem(String m_problem) {
		this.m_problem = m_problem;
	}

	/**
	 * @return the m_Soap
	 */
	public Soap getM_Soap() {
		return m_Soap;
	}

	/**
	 * @param m_Soap the m_Soap to set
	 */
	public void setM_Soap(Soap m_Soap) {
		this.m_Soap = m_Soap;
	}

}
