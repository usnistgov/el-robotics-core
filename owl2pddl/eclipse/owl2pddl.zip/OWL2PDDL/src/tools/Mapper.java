/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/

/**
 * \file      Mapper.java
 * \author    Zeid Kootbally \a zeid.kootbally\@nist.gov
 * \version   1.0
 * \date      26 Jan 2014
 * \brief     Mapper between owl init/goal file and PDDL predicates/functions
 */

package tools;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import knowledge.Domain;
import knowledge.GoalOntology;
import knowledge.InitOntology;
import knowledge.Soap;
import knowledge.SoapOntology;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

/**
 * @brief Map owl init/goal files and PDDL predicates/functions
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 * 
 * @details This class is used to build the init and goal sections of the PDDL problem file.
 * The init section of the problem file is automatically built. 
 * To do so, the OWL init file is read and all the predicates that are true given the initial state are written in the init section.\n
 * The goal section of the problem is scripted and only the value of the parameters of the predicates in the goal section are fetched in the OWL goal file.
 */

public class Mapper {
	private Cleaner m_cleaner;
	private SoapOntology m_SoapOntology;
	private InitOntology m_InitOntology;
	private GoalOntology m_GoalOntology;
	private Soap m_Soap;
	private OWLReasoner m_OWLReasoner_Init;
	private OWLReasoner m_OWLReasoner_Goal;
	private OWLDataFactory m_OWLDataFactory_Init;
	private OWLDataFactory m_OWLDataFactory_Goal;

	private String m_objects_section;
	private String m_init_section;
	private String m_goal_section;
	private String m_problem;


	/**
	 * @brief Java HashMap that consists of the different part SKUs for a specific kit.
	 * <ul>
	 * <li>The key of the HashMap is the kit.
	 * <li>The values of the HashMap are the different part SKUs that go in the final kit
	 * </ul>
	 * 
	 * The structure of the HashMap is as follows: <kit_1<stock_keeping_unit_part_c stock_keeping_unit_part_b>> if kit_1 consists
	 * of parts of type C and B.
	 */
	private Map<String, Collection<String>> m_kit_skuPart_map = new HashMap<String, Collection<String>>();

	/**
	 * @brief Default constructor of the class
	 */
	public Mapper(SoapOntology mySoapOntology, InitOntology myInitOntology,
			GoalOntology myGoalOntology, Soap mySoap) {
		// TODO Auto-generated constructor stub
		setM_SoapOntology(mySoapOntology);
		setM_InitOntology(myInitOntology);
		setM_GoalOntology(myGoalOntology);
		setM_Soap(mySoap);
		//-- build all the OWL reasoners and datafactory needed by the init and goal ontologies
		m_OWLReasoner_Init = getM_InitOntology().getM_initOWLReasoner();
		m_OWLReasoner_Goal = getM_GoalOntology().getM_goalOWLReasoner();
		m_OWLDataFactory_Init = getM_InitOntology().getM_OWLDataFactory();
		m_OWLDataFactory_Goal = getM_GoalOntology().getM_OWLDataFactory();
		//-- Used for cleanIRI and cleanIRIDataProperty
		m_cleaner = new Cleaner();
	}


	/**
	 * @brief Mapping for the function to decimal equal relation (= (capacity-of-parts-in-kit ?sku ?kit) decimal)
	 * 
	 * It consists of:
	 * <ul>
	 * <li>a function '(capacity-kit  ?kit ?sku)'
	 * <li>a mathematical operation '='
	 * <li>a decimal value 'decimal' 
	 * </ul>
	 * The process to build this relation is as follows:
	 * <ul>
	 * <li>instantiate a HashMap HashMap<String, Integer> where the key is the sku of a part and the value is the occurrence of this part's sku in the kit  
	 * <li>read <i>OWLClass:Kit</i> from OWL goal file
	 * <ul>
	 * <li>build\f$kitNodeSet=[kit_i]_{i=1}^{i=n}\f$
	 * <li>\f$\rightarrow\f$for each \f$kit_i\f$
	 * <ul>
	 * <li>build\f$partNodeSet=[part_j:(kit_i,\mathbf{hasKit\_Part})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$part_j\f$
	 * <ul>
	 * <li>build\f$skuNodeSet=[sku_k:(part_j,\mathbf{hasSkuObject\_Sku})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$sku_k\f$
	 * <ul>
	 * <li>store \f$sku_k\f$ as the key of the HashMap
	 * <li>compute the occurrence of \f$sku_k\f$ and store this occurrence as the value of the HashMap
	 * </ul>
	 * </ul>
	 * <li>read the HashMap
	 * <li>\f$\rightarrow\f$for each element in the HashMap
	 * <ul>
	 * <li>\f$\rightarrow\f$build (= (capacity-of-parts-in-kit \f$kit_i\f$ \f$sku_k\f$) occurrence of \f$sku_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_capacity_of_parts_in_kit() {
		Map<String, Collection<String>> l_kit_skuPart_map = new HashMap<String, Collection<String>>();
		Map<String, Integer> partSKUNumber_map = new HashMap<String, Integer>();

		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(
				getM_GoalOntology().getM_owl_class_Kit());
		// System.out.println("Kit class: "+kitClass);
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal
				.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasKit_Part
			OWLObjectProperty OP_hasKit_Part = m_OWLDataFactory_Goal
					.getOWLObjectProperty(IRI.create(getM_GoalOntology()
							.getM_goal_IRI()
							+ getM_GoalOntology().getM_OP_hasKit_Part()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// System.out.println("Kit: "+kit);
				NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Goal
						.getObjectPropertyValues(kit, OP_hasKit_Part);

				if (!partNodeSet.isEmpty()) {
					OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Goal
							.getOWLObjectProperty(IRI
									.create(getM_GoalOntology().getM_goal_IRI()
											+ getM_GoalOntology()
											.getM_OP_hasSkuObject_Sku()));
					Collection<String> values = l_kit_skuPart_map
							.get(m_cleaner.cleanIRI(kit));
					if (values == null) {
						values = new ArrayList<String>();
						l_kit_skuPart_map.put(m_cleaner.cleanIRI(kit), values);
					}

					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						// System.out.println("Part: "+part);
						NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Goal
								.getObjectPropertyValues(part,
										OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()) {
							for (OWLNamedIndividual sku : skuNodeSet
									.getFlattened()) {

								if (!values.contains(m_cleaner.cleanIRI(sku)))
									values.add(m_cleaner.cleanIRI(sku));

								if (!partSKUNumber_map.isEmpty()) {
									if (!partSKUNumber_map
											.containsKey(m_cleaner.cleanIRI(sku))) {
										partSKUNumber_map.put(
												m_cleaner.cleanIRI(
														sku), 1);
									} else {
										partSKUNumber_map
										.put(m_cleaner.cleanIRI(sku),
												partSKUNumber_map
												.get(m_cleaner.cleanIRI(
																sku)) + 1);
									}
								} else {
									partSKUNumber_map.put(m_cleaner.cleanIRI(sku), 1);
								}
							}
						}
					}
				}
				Iterator<Entry<String, Integer>> it = partSKUNumber_map
						.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Integer> pairs = it.next();
					l_init_section += "		(= (capacity-of-parts-in-kit  "
							+ pairs.getKey() + " " + m_cleaner.cleanIRI(kit) + ") "
							+ pairs.getValue() + ")\n";
					it.remove(); // avoids a ConcurrentModificationException
				}
				partSKUNumber_map.clear();
			}
		}
		setM_init_section(l_init_section);
		setM_kit_skuPart_map(l_kit_skuPart_map);
	}


	/**
	 * @brief Mapping for the predicate (endEffector-has-physicalLocation-refObject-endEffectorHolder ?endeffector ?endeffectorholder)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:EndEffector</i> from OWL init file
	 * <ul>
	 * <li>build\f$endEffectorNodeSet=[endeffector_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$endeffector_i\f$
	 * <ul>
	 * <li>build\f$primaryLocationNodeSet=[primaryLocation_j:(endeffector_i,\mathbf{hasSolidObject\_PrimaryLocation})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$primaryLocation_j\f$
	 * <ul>
	 * <li>build\f$refObjectNodeSet=[refObject_k:(primaryLocation_j,\mathbf{hasPhysicalLocation\_RefObject})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$refObject_k\f$
	 * <ul>
	 * <li>if \f$refObject_k\f$ is of type <i>OWLClass:EndEffectorHolder</i> 
	 * <ul>
	 * <li>build (endEffector-has-physicalLocation-refObject-endEffectorHolder\f$(endeffector_i\f$ \f$refObject_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_physicalLocation_refObject_endEffectorHolder() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class EndEffector
		OWLClass endEffectorClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffector());
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorClass, false);

		if (!endEffectorNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual endEffector : endEffectorNodeSet
					.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(endEffector,
								OP_hasSolidObject_PrimaryLocation);

				if (!locationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual location : locationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(location,
										OP_hasPhysicalLocation_RefObject);
						if (!endEffectorHolderNodeSet.isEmpty()) {
							for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet
									.getFlattened()) {
								// -- check if endEffectorHolder is from the OWL
								// Class EndEffectorHolder
								Set<OWLClassExpression> endEffectorHolderClass = endEffectorHolder
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(endEffectorHolderClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_EndEffectorHolder()))) == 0) {
									l_init_section += "		(endEffector-has-physicalLocation-refObject-endEffectorHolder "
											+ m_cleaner.cleanIRI(endEffector) + " "
											+ m_cleaner.cleanIRI(endEffectorHolder)
											+ ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffector-has-physicalLocation-refObject-robot ?endeffector ?robot)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:EndEffector</i> from OWL init file
	 * <ul>
	 * <li>build\f$endEffectorNodeSet=[endeffector_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$endeffector_i\f$
	 * <ul>
	 * <li>build\f$primaryLocationNodeSet=[primaryLocation_j:(endeffector_i,\mathbf{hasSolidObject\_PrimaryLocation})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$primaryLocation_j\f$
	 * <ul>
	 * <li>build\f$refObjectNodeSet=[refObject_k:(primaryLocation_j,\mathbf{hasPhysicalLocation\_RefObject})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$refObject_k\f$
	 * <ul>
	 * <li>if \f$refObject_k\f$ is of type <i>OWLClass:Robot</i> 
	 * <ul>
	 * <li>build (endEffector-has-physicalLocation-refObject-robot\f$(endeffector_i\f$ \f$refObject_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_physicalLocation_refObject_robot() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class EndEffector
		OWLClass endEffectorClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffector());
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorClass, false);
		if (!endEffectorNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual endEffector : endEffectorNodeSet
					.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(endEffector,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type Robot
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_Robot()))) == 0) {
									l_init_section += "		(endEffector-has-physicalLocation-refObject-robot "
											+ m_cleaner.cleanIRI(endEffector) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffectorHolder-has-physicalLocation-refObject-changingStation ?endeffectorholder ?endeffectorchangingstation)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:EndEffectorHolder</i> from OWL init file
	 * <ul>
	 * <li>build\f$endEffectorHolderNodeSet=[endeffectorholder_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$endeffectorholder_i\f$
	 * <ul>
	 * <li>build\f$primaryLocationNodeSet=[primaryLocation_j:(endeffectorholder_i,\mathbf{hasSolidObject\_PrimaryLocation})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$primaryLocation_j\f$
	 * <ul>
	 * <li>build\f$refObjectNodeSet=[refObject_k:(primaryLocation_j,\mathbf{hasPhysicalLocation\_RefObject})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$refObject_k\f$
	 * <ul>
	 * <li>if \f$refObject_k\f$ is of type <i>OWLClass:EndEffectorChangingStation</i> 
	 * <ul>
	 * <li>build (endEffectorHolder-has-physicalLocation-refObject-changingStation\f$(endeffectorholder_i\f$ \f$refObject_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_endEffectorHolder_has_physicalLocation_refObject_changingStation() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class EndEffectorHolder
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffectorHolder());
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorHolderClass, false);
		if (!endEffectorHolderNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffectorHolder get PrimaryLocation
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet
					.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(endEffectorHolder,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type
								// EndEffectorChangingStation
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_EndEffectorChangingStation()))) == 0) {
									l_init_section += "		(endEffectorHolder-has-physicalLocation-refObject-changingStation "
											+ m_cleaner.cleanIRI(endEffectorHolder) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffectorChangingStation-has-endEffectorHolder ?endeffectorchangingstation ?endeffectorholder)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:EndEffectorChangingStation</i> from OWL init file
	 * <ul>
	 * <li>build\f$endEffectorChangingStationNodeSet=[endEffectorChangingStation_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$endEffectorChangingStation_i\f$
	 * <ul>
	 * <li>build\f$endEffectorHolderNodeSet=[endEffectorHolder_j:(endEffectorChangingStation_i,\mathbf{hasEndEffectorChangingStation\_EndEffectorHolder})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$endEffectorHolder_j\f$
	 * <ul>
	 * <li>build (endEffectorChangingStation-has-endEffectorHolder\f$(endEffectorChangingStation_i\f$ \f$endEffectorHolder_j\f$)\f$_{i=1, j=1}^{i=n, j=o}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_endEffectorChangingStation_has_endEffectorHolder() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class EndEffectorChangingStation
		OWLClass endEffectorChangingStationClass = getM_InitOntology()
				.getClass(
						getM_InitOntology()
						.getM_owl_class_EndEffectorChangingStation());
		NodeSet<OWLNamedIndividual> endEffectorChangingStationNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorChangingStationClass, false);

		if (!endEffectorChangingStationNodeSet.isEmpty()) {
			// -- Build the object property
			// hasEndEffectorChangingStation_EndEffectorHolder
			OWLObjectProperty OP_hasEndEffectorChangingStation_EndEffectorHolder = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI
							.create(getM_InitOntology().getM_init_IRI()
									+ getM_InitOntology()
									.getM_OP_hasEndEffectorChangingStation_EndEffectorHolder()));
			// -- for each EndEffectorChangingStation get EndEffectorHolder
			for (OWLNamedIndividual endEffectorChangingStation : endEffectorChangingStationNodeSet
					.getFlattened()) {
				// -- get individuals for
				// hasEndEffectorChangingStation_EndEffectorHolder
				NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(endEffectorChangingStation,
								OP_hasEndEffectorChangingStation_EndEffectorHolder);
				if (!endEffectorHolderNodeSet.isEmpty()) {
					for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet
							.getFlattened()) {
						l_init_section += "		(endEffectorChangingStation-has-endEffectorHolder "
								+ m_cleaner.cleanIRI(endEffectorChangingStation) + " "
								+ m_cleaner.cleanIRI(endEffectorHolder) + ")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (robot-has-endEffector ?robot ?endeffector)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i> from OWL init file
	 * <ul>
	 * <li>build\f$robotNodeSet=[robot_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$robot_i\f$
	 * <ul>
	 * <li>build\f$endEffectorNodeSet=[endeffector_j:(robot_i,\mathbf{hasRobot\_EndEffector})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$endeffector_j\f$
	 * <ul>
	 * <li>build (robot-has-endEffector\f$robot_i\f$ \f$endeffector_j\f$)\f$_{i=1, j=1}^{i=n, j=o}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_robot_has_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						l_init_section += "		(robot-has-endEffector "
								+ m_cleaner.cleanIRI(robot) + " " + m_cleaner.cleanIRI(endEffector)
								+ ")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (robot-has-no-endEffector ?robot)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i>
	 * <ul>
	 * <li>build\f$robotNodeSet=[robot_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$robot_i\f$
	 * <ul>
	 * <li>build\f$endEffectorNodeSet=[endeffector_j:(robot_i,\mathbf{hasRobot\_EndEffector})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>if \f$endEffectorNodeSet\f$ is empty
	 * <ul>
	 * <li>build (robot-has-no-endEffector\f$robot_i\f$)\f$_{i=1}^{i=n}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_robot_has_no_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);

				if (endEffectorNodeSet.isEmpty()) {
					l_init_section +="		(robot-has-no-endEffector " + m_cleaner.cleanIRI(robot)
							+ ")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (workTable-has-objectOnTable-kit ?worktable ?kit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:WorkTable</i>
	 * <ul>
	 * <li>build\f$workTableNodeSet=[workTable_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$workTable_i\f$
	 * <ul>
	 * <li>build\f$solidObjectNodeSet=[solidObject_j:(workTable_i,\mathbf{hasWorkTable\_ObjectOnTable})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$solidObject_j\f$
	 * <ul>
	 * <li>if \f$solidObject_j\f$ is of type OWLClass:Kit
	 * <ul>
	 * <li>build (workTable-has-objectOnTable-kit\f$workTable_i\f$ \f$solidObject_j\f$)\f$_{i=1, j=1}^{i=n, j=o}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_workTable_has_objectOnTable_kit() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_WorkTable());
		NodeSet<OWLNamedIndividual> workTableNodeSet = m_OWLReasoner_Init
				.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()) {
			// -- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(workTable,
								OP_hasWorkTable_ObjectOnTable);
				if (!solidObjectNodeSet.isEmpty()) {
					for (OWLNamedIndividual solidObject : solidObjectNodeSet
							.getFlattened()) {
						Set<OWLClassExpression> solidObjectClass = solidObject
								.getTypes(getM_InitOntology()
										.getM_OWLInitInstanceOntology());
						if (m_cleaner.cleanIRI(solidObjectClass).compareTo(
								m_cleaner.cleanIRI(getM_InitOntology().getClass(
										getM_InitOntology()
										.getM_owl_class_Kit()))) == 0) {
							l_init_section += "		(workTable-has-objectOnTable-kit "
									+ m_cleaner.cleanIRI(workTable) + " "
									+ m_cleaner.cleanIRI(solidObject) + ")\n";
						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (workTable-has-objectOnTable-kitTray ?worktable ?kittray)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:WorkTable</i>
	 * <ul>
	 * <li>build\f$workTableNodeSet=[workTable_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$workTable_i\f$
	 * <ul>
	 * <li>build\f$solidObjectNodeSet=[solidObject_j:(workTable_i,\mathbf{hasWorkTable\_ObjectOnTable})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$solidObject_j\f$
	 * <ul>
	 * <li>if \f$solidObject_j\f$ is of type OWLClass:KitTray
	 * <ul>
	 * <li>build (workTable-has-objectOnTable-kitTray\f$workTable_i\f$ \f$solidObject_j\f$)\f$_{i=1, j=1}^{i=n, j=o}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 */
	private void build_workTable_has_objectOnTable_kitTray() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_WorkTable());
		NodeSet<OWLNamedIndividual> workTableNodeSet = m_OWLReasoner_Init
				.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()) {
			// -- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(workTable,
								OP_hasWorkTable_ObjectOnTable);
				if (!solidObjectNodeSet.isEmpty()) {
					for (OWLNamedIndividual solidObject : solidObjectNodeSet
							.getFlattened()) {
						Set<OWLClassExpression> solidObjectClass = solidObject
								.getTypes(getM_InitOntology()
										.getM_OWLInitInstanceOntology());
						if (m_cleaner.cleanIRI(solidObjectClass).compareTo(
								m_cleaner.cleanIRI(getM_InitOntology().getClass(
										getM_InitOntology()
										.getM_owl_class_KitTray()))) == 0) {
							l_init_section += "		(workTable-has-objectOnTable-kitTray "
									+ m_cleaner.cleanIRI(workTable) + " "
									+ m_cleaner.cleanIRI(solidObject) + ")\n";
						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kit-has-physicalLocation-refObject-lbwk ?kit ?largeboxwithkits)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL init file
	 * <ul>
	 * <li>build\f$kitNodeSet=[kit_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$kit_i\f$
	 * <ul>
	 * <li>build\f$primaryLocationNodeSet=[primaryLocation_j:(kit_i,\mathbf{hasSolidObject\_PrimaryLocation})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$primaryLocation_j\f$
	 * <ul>
	 * <li>build\f$refObjectNodeSet=[refObject_k:(primaryLocation_j,\mathbf{hasPhysicalLocation\_RefObject})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$refObject_k\f$
	 * <ul>
	 * <li>if \f$refObject_k\f$ is of type <i>OWLClass:LargeBoxWithKits</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-has-physicalLocation-refObject-lbwk\f$(kit_i\f$ \f$refObject_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_has_physicalLocation_refObject_lbwk() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init
				.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kit,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type
								// LargeBoxWithKits
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_LargeBoxWithKits()))) == 0) {
									l_init_section += "		(kit-has-physicalLocation-refObject-lbwk "
											+ m_cleaner.cleanIRI(kit) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kit-has-physicalLocation-refObject-lbwk ?kit ?largeboxwithkits) in the goal state
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$kitNodeSet=[kit_i]_{i=1}^{i=n}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$kit_i\f$
	 * <ul>
	 * <li>build\f$primaryLocationNodeSet=[primaryLocation_j:(kit_i,\mathbf{hasSolidObject\_PrimaryLocation})]_{i=1,j=1}^{i=n,j=o}\f$
	 * <li>\f$\rightarrow\f$for each \f$primaryLocation_j\f$
	 * <ul>
	 * <li>build\f$refObjectNodeSet=[refObject_k:(primaryLocation_j,\mathbf{hasPhysicalLocation\_RefObject})]_{j=1, k=1}^{j=o, k=p}\f$
	 * <li>\f$\rightarrow\f$for each \f$refObject_k\f$
	 * <ul>
	 * <li>if \f$refObject_k\f$ is of type <i>OWLClass:LargeBoxWithKits</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-has-physicalLocation-refObject-lbwk\f$(kit_i\f$ \f$refObject_k\f$)\f$_{i=1, k=1}^{i=n, k=p}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_has_physicalLocation_refObject_lbwk_goal() {
		String l_goal_section = getM_goal_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(
				getM_GoalOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal
				.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Goal
					.getOWLObjectProperty(IRI.create(getM_GoalOntology()
							.getM_goal_IRI()
							+ getM_GoalOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Goal
						.getObjectPropertyValues(kit,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Goal
							.getOWLObjectProperty(IRI
									.create(getM_GoalOntology().getM_goal_IRI()
											+ getM_GoalOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Goal
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type
								// LargeBoxWithKits
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_GoalOntology()
												.getM_OWLGoalInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_GoalOntology()
														.getClass(
																getM_GoalOntology()
																.getM_owl_class_LargeBoxWithKits()))) == 0) {
									l_goal_section += "		(kit-has-physicalLocation-refObject-lbwk "
											+ m_cleaner.cleanIRI(kit) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_goal_section(l_goal_section);
	}
	
	
	/**
	 * @brief Mapping for the predicate (kit-has-physicalLocation-refObject-endEffector ?kit ?largeboxwithkits) in the goal state
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:EndEffector</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-has-physicalLocation-refObject-endEffector\f$\mathrm{(kit_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_has_physicalLocation_refObject_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init
				.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kit,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type EndEffector
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_EndEffector()))) == 0) {
									l_init_section += "		(kit-has-physicalLocation-refObject-endEffector "
											+ m_cleaner.cleanIRI(kit) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kit-has-kitTray ?kit ?kitTray)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_j:(kit_i,hashasKit\_KitTray)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_j}\f$ 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-has-kitTray\f$\mathrm{(kit_i}\f$ \f$\mathrm{kitTray_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_has_kitTray(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasKit_KitTray = m_OWLDataFactory_Goal
					.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI()+ getM_GoalOntology().getM_OP_hasKit_KitTray()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {

				NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Goal.getObjectPropertyValues(kit,OP_hasKit_KitTray);
				if (!kitTrayNodeSet.isEmpty()) {
					for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
						l_init_section += "		(kit-has-kitTray "
								+ m_cleaner.cleanIRI(kit) + " "
								+ m_cleaner.cleanIRI(kitTray) + ")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kit-exists ?kit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-exists\f$\mathrm{kit_i}\f$)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_exists(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()) {
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				l_init_section += "		(kit-exists "+ m_cleaner.cleanIRI(kit)+ ")\n";
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kit-has-physicalLocation-refObject-workTable ?kit ?workTable) in the goal state
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:WorkTable</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kit-has-physicalLocation-refObject-workTable\f$\mathrm{(kit_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kit_has_physicalLocation_refObject_workTable() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init
				.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));

			// -- for eachendEffector get PrimaryLocation
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// -- get individuals for hasSolidObject_PrimaryLocation
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kit,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						// -- get individuals for hasSolidObject_PrimaryLocation
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- get only refObject that is of type
								// WorkTable
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_WorkTable()))) == 0) {
									l_init_section += "		(kit-has-physicalLocation-refObject-workTable "
											+ m_cleaner.cleanIRI(kit) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (lbwk-has-kit ?largeBoxWithKits ?kit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:LargeBoxWithKits</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{largeBoxWithKitsNodeSet=[largeBoxWithKits_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{largeBoxWithKits_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_j:(largeBoxWithKits_i,hasLargeBoxWithKits\_Kit)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$build (lbwk-has-kit\f$\mathrm{(largeBoxWithKits_i}\f$ \f$\mathrm{kit_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_lbwk_has_kit() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class LargeBoxWithKits
		OWLClass LargeBoxWithKitsClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_LargeBoxWithKits());
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = m_OWLReasoner_Init
				.getInstances(LargeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()) {
			// -- Build the object property hasLargeWithKits_Kit
			OWLObjectProperty OP_hasLargeBoxWithKits_Kit = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasLargeBoxWithKits_Kit()));
			// System.out.println(DP_hasLargeWithKits_Capacity);
			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet
					.getFlattened()) {

				NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(largeBoxWithKits,OP_hasLargeBoxWithKits_Kit);
				if (!kitNodeSet.isEmpty()) {
					for (OWLNamedIndividual kit : kitNodeSet.getFlattened())
						l_init_section += "		(lbwk-has-kit "+m_cleaner.cleanIRI(largeBoxWithKits)+" "+m_cleaner.cleanIRI(kit)+")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (lbwk-has-kit ?largeBoxWithKits ?kit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:LargeBoxWithKits</i> in OWL <b>goal</b> file
	 * <ul>
	 * <li>build\f$\mathrm{largeBoxWithKitsNodeSet=[largeBoxWithKits_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{largeBoxWithKits_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_j:(largeBoxWithKits_i,hasLargeBoxWithKits\_Kit)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$build (lbwk-has-kit\f$\mathrm{(largeBoxWithKits_i}\f$ \f$\mathrm{kit_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_lbwk_has_kit_goal() {
		String l_goal_section = getM_goal_section();
		
		// -- Get each individual from the OWL class LargeBoxWithKits
		OWLClass LargeBoxWithKitsClass = getM_GoalOntology().getClass(
				getM_GoalOntology().getM_owl_class_LargeBoxWithKits());
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = m_OWLReasoner_Goal
				.getInstances(LargeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()) {
			// -- Build the object property hasLargeWithKits_Kit
			OWLObjectProperty OP_hasLargeBoxWithKits_Kit = m_OWLDataFactory_Goal
					.getOWLObjectProperty(IRI.create(getM_GoalOntology()
							.getM_goal_IRI()
							+ getM_GoalOntology()
							.getM_OP_hasLargeBoxWithKits_Kit()));
			// System.out.println(DP_hasLargeWithKits_Capacity);
			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet
					.getFlattened()) {

				NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal.getObjectPropertyValues(largeBoxWithKits,OP_hasLargeBoxWithKits_Kit);
				if (!kitNodeSet.isEmpty()) {
					for (OWLNamedIndividual kit : kitNodeSet.getFlattened())
						l_goal_section += "		(lbwk-has-kit "+m_cleaner.cleanIRI(largeBoxWithKits)+" "+m_cleaner.cleanIRI(kit)+")\n";
				}
			}
		}
		setM_goal_section(l_goal_section);
	}

	/**
	 * @brief Mapping for the predicate (partsVessel-has-part ?partsTray ?part)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:PartsTray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partsTrayNodeSet=[partsTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{partsTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(kit_i,hasPartsVessel\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$build (partsVessel-has-part\f$\mathrm{(partsTray_i}\f$ \f$\mathrm{part_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_partsVessel_has_part() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class PartsTray
		OWLClass partsTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_PartsTray());
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = m_OWLReasoner_Init
				.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()) {
			// -- Build the object property hasPartsVessel_Part
			OWLObjectProperty OP_hasPartsVessel_Part = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI
							.create(getM_InitOntology().getM_init_IRI()
									+ getM_InitOntology()
									.getM_OP_hasPartsVessel_Part()));
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(partsTray,
								OP_hasPartsVessel_Part);
				if (!partNodeSet.isEmpty()) {
					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						l_init_section += "		(partsVessel-has-part  "
								+ m_cleaner.cleanIRI(partsTray) + " " + m_cleaner.cleanIRI(part)
								+ ")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}



	/**
	 * @brief Mapping for the predicate (endEffectorHolder-has-endEffector ?endEffectorHolder ?endEffector)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:EndEffectorHolder</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorHolderNodeSet=[endEffectorHolder_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffectorHolder_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_j:(endEffectorHolder_i,hasEndEffectorHolder\_EndEffector)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$build (endEffectorHolder-has-endEffector\f$\mathrm{(endEffectorHolder_i}\f$ \f$\mathrm{endEffector_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffectorHolder_has_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class EndEffectorHolder
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffectorHolder());
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorHolderClass, false);

		if (!endEffectorHolderNodeSet.isEmpty()) {
			// -- Build the object property hasEndEffectorHolder_EndEffector
			OWLObjectProperty OP_hasEndEffectorHolder_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI
							.create(getM_InitOntology().getM_init_IRI()
									+ getM_InitOntology()
									.getM_OP_hasEndEffectorHolder_EndEffector()));
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet
					.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(endEffectorHolder,
								OP_hasEndEffectorHolder_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						l_init_section += "		(endEffectorHolder-has-endEffector "
								+ m_cleaner.cleanIRI(endEffectorHolder) + " "
								+ m_cleaner.cleanIRI(endEffector) + ")\n";
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (workTable-has-no-objectOnTable ?workTable)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:WorkTable</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{workTableNodeSet=[worktable_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{worktable_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{solidObjectNodeSet=[solidObject_j:(worktable_i,hasWorkTable\_ObjectOnTable)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$ if  \f$\mathrm{solidObjectNodeSet}\f$ is empty
	 * <ul>
	 * <li>\f$\rightarrow\f$build (workTable-has-no-objectOnTable\f$\mathrm{worktable_i}\f$)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_workTable_has_no_objectOnTable() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class WorkTable
		OWLClass workTableClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_WorkTable());
		NodeSet<OWLNamedIndividual> workTableNodeSet = m_OWLReasoner_Init.getInstances(workTableClass, false);
		if (!workTableNodeSet.isEmpty()) {
			// -- Build the object property hasWorkTable_ObjectOnTable
			OWLObjectProperty OP_hasWorkTable_ObjectOnTable = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasWorkTable_ObjectOnTable()));
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> solidObjectNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(workTable,
								OP_hasWorkTable_ObjectOnTable);
				if (solidObjectNodeSet.isEmpty()) {
					l_init_section += "		(workTable-has-no-objectOnTable "
							+ m_cleaner.cleanIRI(workTable) + ")\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kitTray-has-physicalLocation-refObject-lbwekt ?kitTray ?largeBoxWithEmptyKitTrays)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kittray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:LargeBoxWithEmptyKitTrays</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kitTray-has-physicalLocation-refObject-lbwekt\f$\mathrm{kitTray_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kitTray_has_physicalLocation_refObject_lbwekt() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kitTray,
								OP_hasSolidObject_PrimaryLocation);

				if (!locationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual location : locationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> largeBoxWithEmptyKitTraysNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(location,
										OP_hasPhysicalLocation_RefObject);
						if (!largeBoxWithEmptyKitTraysNodeSet.isEmpty()) {
							for (OWLNamedIndividual largeBoxWithEmptyKitTrays : largeBoxWithEmptyKitTraysNodeSet
									.getFlattened()) {
								// -- check if largeBoxWithEmptyKitTrays is from
								// the OWL Class LargeBoxWithEmptyKitTrays
								Set<OWLClassExpression> largeBoxWithEmptyKitTraysClass = largeBoxWithEmptyKitTrays
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(largeBoxWithEmptyKitTraysClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_LargeBoxWithEmptyKitTrays()))) == 0) {
									l_init_section += "		(kitTray-has-physicalLocation-refObject-lbwekt "
											+ m_cleaner.cleanIRI(kitTray)
											+ " "
											+ m_cleaner.cleanIRI(largeBoxWithEmptyKitTrays)
											+ ")\n";
								}
							}
						}
					}
				}
			}
		}

		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kitTray-has-physicalLocation-refObject-endEffector ?kitTray ?endEffector)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kittray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:EndEffector</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kitTray-has-physicalLocation-refObject-endEffector\f$\mathrm{kitTray_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kitTray_has_physicalLocation_refObject_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init
				.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kitTray,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- check if refObject is from the OWL Class
								// Robot
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_EndEffector()))) == 0) {
									l_init_section += "		(kitTray-has-physicalLocation-refObject-endEffector "
											+ m_cleaner.cleanIRI(kitTray) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (kitTray-has-physicalLocation-refObject-workTable ?kitTray ?workTable)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kittray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:WorkTable</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kitTray-has-physicalLocation-refObject-workTable\f$\mathrm{kitTray_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kitTray_has_physicalLocation_refObject_workTable() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init
				.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kitTray,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));

					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- check if refObject is from the OWL Class
								// WorkTable
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_WorkTable()))) == 0) {
									l_init_section += "		(kitTray-has-physicalLocation-refObject-workTable "
											+ m_cleaner.cleanIRI(kitTray) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (kitTray-has-physicalLocation-refObject-kit ?kitTray ?workTable)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kittray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:Kit</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (kitTray-has-physicalLocation-refObject-kit\f$\mathrm{kitTray_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kitTray_has_physicalLocation_refObject_kit(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Goal.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Goal
					.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI()+ getM_GoalOntology().getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Goal.getObjectPropertyValues(kitTray,OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Goal.getOWLObjectProperty(IRI.create(getM_GoalOntology().getM_goal_IRI()+ getM_GoalOntology().getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Goal.getObjectPropertyValues(primaryLocation,OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- check if refObject is of type Kit
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_GoalOntology()
												.getM_OWLGoalInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_GoalOntology()
														.getClass(
																getM_GoalOntology()
																.getM_owl_class_Kit()))) == 0) {
									l_init_section += "		(kitTray-has-physicalLocation-refObject-kit "
											+ m_cleaner.cleanIRI(kitTray) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}


	/**
	 * @brief Mapping for the predicate (part-has-physicalLocation-refObject-partsTray ?part ?partsTray)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Part</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:PartsTray</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$build (part-has-physicalLocation-refObject-partsTray\f$\mathrm{part_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_part_has_physicalLocation_refObject_partsTray() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> locationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(part,
								OP_hasSolidObject_PrimaryLocation);
				if (!locationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual location : locationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> partsTrayNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(location,
										OP_hasPhysicalLocation_RefObject);
						if (!partsTrayNodeSet.isEmpty()) {
							for (OWLNamedIndividual partsTray : partsTrayNodeSet
									.getFlattened()) {
								// -- check if largeBoxWithEmptyKitTrays is from
								// the OWL Class LargeBoxWithEmptyKitTrays
								Set<OWLClassExpression> partsTrayClass = partsTray
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(partsTrayClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_PartsTray()))) == 0) {
									l_init_section += "		(part-has-physicalLocation-refObject-partsTray "
											+ m_cleaner.cleanIRI(part) + " "
											+ m_cleaner.cleanIRI(partsTray) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (part-has-physicalLocation-refObject-kit ?part ?kit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Part</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:Kit</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (part-has-physicalLocation-refObject-kit\f$\mathrm{part_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_part_has_physicalLocation_refObject_kit() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(part,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- check if refObject is of type Kit
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_Kit()))) == 0) {
									l_init_section += "		(part-has-physicalLocation-refObject-kit "
											+ m_cleaner.cleanIRI(part) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (part-has-physicalLocation-refObject-endEffector ?part ?endEffector)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Part</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{primaryLocationNodeSet=[primaryLocation_j:(kit_i,hasSolidObject\_PrimaryLocation)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{primaryLocation_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{refObjectNodeSet=[refObject_k:(primaryLocation_j,hasPhysicalLocation\_RefObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{refObject_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{refObject_k}\f$ is of type <i>OWLClass:EndEffector</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (part-has-physicalLocation-refObject-endEffector\f$\mathrm{part_i}\f$ \f$\mathrm{refObject_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_part_has_physicalLocation_refObject_endEffector() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSolidObject_PrimaryLocation = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasSolidObject_PrimaryLocation()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> primaryLocationNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(part,
								OP_hasSolidObject_PrimaryLocation);
				if (!primaryLocationNodeSet.isEmpty()) {
					// -- Build the object property
					// hasPhysicalLocation_RefObject
					OWLObjectProperty OP_hasPhysicalLocation_RefObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasPhysicalLocation_RefObject()));
					for (OWLNamedIndividual primaryLocation : primaryLocationNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> refObjectNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(primaryLocation,
										OP_hasPhysicalLocation_RefObject);
						if (!refObjectNodeSet.isEmpty()) {
							for (OWLNamedIndividual refObject : refObjectNodeSet
									.getFlattened()) {
								// -- check if refObject is of type EndEffector or
								Set<OWLClassExpression> refObjectClass = refObject
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								if (m_cleaner.cleanIRI(refObjectClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_EndEffector()))) == 0) {
									l_init_section += "		(part-has-physicalLocation-refObject-endEffector "
											+ m_cleaner.cleanIRI(part) + " "
											+ m_cleaner.cleanIRI(refObject) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffector-has-heldObject-kitTray ?endEffector ?kitTray)
	 * The endEffector must be attached to a robot and is holding a kitTray for this predicate to be true
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{robotNodeSet=[robot_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{robot_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_j:(kit_i,hasRobot\_EndEffector)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{objectHeldNodeSet=[objectHeld_k:(endEffector_j,hasEndEffector\_HeldObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{objectHeld_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{objectHeld_k}\f$ is of type <i>OWLClass:KitTray</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-has-heldObject-kitTray\f$\mathrm{endEffector_j}\f$ \f$\mathrm{objectHeld_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_heldObject_kitTray() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()+ getM_InitOntology().getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					// -- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = m_OWLDataFactory_Init.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()+ getM_InitOntology().getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(endEffector,
										OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()) {
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet
									.getFlattened()) {
								// -- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								// -- Check if objectHeld is of type KitTray
								if (m_cleaner.cleanIRI(objectHeldClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_KitTray()))) == 0) {
									l_init_section += "		(endEffector-has-heldObject-kitTray "
											+ m_cleaner.cleanIRI(endEffector) + " "
											+ m_cleaner.cleanIRI(objectHeld) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (endEffector-has-heldObject-kit ?endEffector ?kit)
	 * The endEffector must be attached to a robot and is holding a kit for this predicate to be true
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{robotNodeSet=[robot_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{robot_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_j:(kit_i,hasRobot\_EndEffector)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{objectHeldNodeSet=[objectHeld_k:(endEffector_j,hasEndEffector\_HeldObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{objectHeld_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{objectHeld_k}\f$ is of type <i>OWLClass:Kit</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-has-heldObject-kit\f$\mathrm{endEffector_j}\f$ \f$\mathrm{objectHeld_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_heldObject_kit() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					// -- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(endEffector,
										OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()) {
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet
									.getFlattened()) {
								// -- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								// -- Check if objectHeld is of type Kit
								if (m_cleaner.cleanIRI(objectHeldClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_Kit()))) == 0) {
									l_init_section += "		(endEffector-has-heldObject-kit "
											+ m_cleaner.cleanIRI(endEffector) + " "
											+ m_cleaner.cleanIRI(objectHeld) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (endEffector-has-heldObject-part ?endEffector ?part)
	 * The endEffector must be attached to a robot and is holding a part for this predicate to be true
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{robotNodeSet=[robot_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{robot_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_j:(kit_i,hasRobot\_EndEffector)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{objectHeldNodeSet=[objectHeld_k:(endEffector_j,hasEndEffector\_HeldObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{objectHeld_k}\f$
	 * <ul>
	 * <li>if \f$\mathrm{objectHeld_k}\f$ is of type <i>OWLClass:Part</i> 
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-has-heldObject-part\f$\mathrm{endEffector_j}\f$ \f$\mathrm{objectHeld_k}\f$)\f$\mathrm{_{i=1, k=1}^{i=n, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_heldObject_part() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					// -- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(endEffector,
										OP_hasEndEffector_HeldObject);
						if (!objectHeldNodeSet.isEmpty()) {
							for (OWLNamedIndividual objectHeld : objectHeldNodeSet
									.getFlattened()) {
								// -- Get the class of objectHeld
								Set<OWLClassExpression> objectHeldClass = objectHeld
										.getTypes(getM_InitOntology()
												.getM_OWLInitInstanceOntology());
								// -- Check if objectHeld is of type Part
								if (m_cleaner.cleanIRI(objectHeldClass)
										.compareTo(
												m_cleaner.cleanIRI(getM_InitOntology()
														.getClass(
																getM_InitOntology()
																.getM_owl_class_Part()))) == 0) {
									l_init_section += "		(endEffector-has-heldObject-part "
											+ m_cleaner.cleanIRI(endEffector) + " "
											+ m_cleaner.cleanIRI(objectHeld) + ")\n";
								}
							}
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (endEffector-has-no-heldObject ?endEffector)
	 * The endEffector must be attached to a robot and is not holding any object for this predicate to be true
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Robot</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{robotNodeSet=[robot_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{robot_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_j:(kit_i,hasRobot\_EndEffector)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{objectHeldNodeSet=[objectHeld_k:(endEffector_j,hasEndEffector\_HeldObject)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <ul>
	 * <li>if \f$\mathrm{objectHeldNodeSet}\f$ is empty
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-has-no-heldObject\f$\mathrm{endEffector_j}\f$)\f$\mathrm{_{j=1}^{j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_has_no_heldObject() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Robot
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			// -- Build the object property hasRobot_EndEffector
			OWLObjectProperty OP_hasRobot_EndEffector = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology()
							.getM_OP_hasRobot_EndEffector()));
			// -- for each robot get EndEffector
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened()) {
				NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(robot, OP_hasRobot_EndEffector);
				if (!endEffectorNodeSet.isEmpty()) {
					// -- Build the object property hasEndEffector_HeldObject
					OWLObjectProperty OP_hasEndEffector_HeldObject = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasEndEffector_HeldObject()));
					for (OWLNamedIndividual endEffector : endEffectorNodeSet
							.getFlattened()) {
						NodeSet<OWLNamedIndividual> objectHeldNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(endEffector,
										OP_hasEndEffector_HeldObject);
						if (objectHeldNodeSet.isEmpty()) {
							l_init_section += "		(endEffector-has-no-heldObject "
									+ m_cleaner.cleanIRI(endEffector) + ")\n";
						}
					}
				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (part-has-skuObject-sku ?part ?stockKeepingUnit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Part</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_j:(part_i,hasSkuObject\_Sku)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (part-has-skuObject-sku\f$\mathrm{part_i}\f$ \f$\mathrm{stockKeepingUnit_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_part_has_skuObject_sku(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			// -- Build the object property hasSkuObject_Sku
			OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
				//-- NodeSet of SKU
				NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(part, OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()) {
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()) {
						l_init_section += "		(part-has-skuObject-sku "
								+ m_cleaner.cleanIRI(part) + " "
								+ m_cleaner.cleanIRI(sku) + ")\n";
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the predicate (kitTray-has-skuObject-sku ?kitTray ?stockKeepingUnit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:KitTray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_j:(part_i,hasSkuObject\_Sku)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_j}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (kitTray-has-skuObject-sku\f$\mathrm{kitTray_i}\f$ \f$\mathrm{stockKeepingUnit_j}\f$)\f$\mathrm{_{i=1, j=1}^{i=n, j=o}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_kitTray_has_skuObject_sku(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init
				.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSkuObject_Sku
			OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				//-- NodeSet of SKU
				NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kitTray, OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()) {
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()) {
						l_init_section += "		(kitTray-has-skuObject-sku "
								+ m_cleaner.cleanIRI(kitTray) + " "
								+ m_cleaner.cleanIRI(sku) + ")\n";
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffector-is-for-partSKU ?endEffector ?stockKeepingUnit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Part</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partNodeSet=[part_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_i}\f$
	 * <ul>
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_j:(part_i,hasSkuObject\_Sku)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_j}\f$
	 * <ul>
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_k:(stockKeepingUnit_j,hasStockKeepingUnit\_EndEffector)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_k}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-is-for-partSKU\f$\mathrm{endEffector_k}\f$ \f$\mathrm{stockKeepingUnit_j}\f$)\f$\mathrm{_{j=1, k=1}^{j=o, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_is_for_partSKU() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(part, OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()) {
					// -- Build the object property
					// hasStockKeepingUnit_EndEffector
					OWLObjectProperty OP_hasStockKeepingUnit_EndEffector = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasStockKeepingUnit_EndEffector()));
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()) {
						NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(sku,
										OP_hasStockKeepingUnit_EndEffector);
						if (!endEffectorNodeSet.isEmpty()) {
							for (OWLNamedIndividual endEffector : endEffectorNodeSet
									.getFlattened()) {
								l_init_section += "		(endEffector-is-for-partSKU "
										+ m_cleaner.cleanIRI(endEffector) + " "
										+ m_cleaner.cleanIRI(sku) + ")\n";
							}

						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the predicate (endEffector-is-for-kitTraySKU ?endEffector ?stockKeepingUnit)
	 * 
	 * The process to build this predicate is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:KitTray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_i}\f$
	 * <ul>
	 * <li>get its stockKeepingUnit
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_j:(kitTray_i,hasSkuObject\_Sku)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_j}\f$
	 * <ul>
	 * <li>get the endEffector
	 * <li>build\f$\mathrm{endEffectorNodeSet=[endEffector_k:(stockKeepingUnit_j,hasStockKeepingUnit\_EndEffector)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{endEffector_k}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (endEffector-is-for-kitTraySKU\f$\mathrm{endEffector_k}\f$ \f$\mathrm{stockKeepingUnit_j}\f$)\f$\mathrm{_{j=1, k=1}^{j=o, k=p}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_endEffector_is_for_kitTraySKU() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class KitTray
		OWLClass kitTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init
				.getInstances(kitTrayClass, false);

		if (!kitTrayNodeSet.isEmpty()) {
			// -- Build the object property hasSolidObject_PrimaryLocation
			OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology().getM_OP_hasSkuObject_Sku()));
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// -- Get location
				NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kitTray, OP_hasSkuObject_Sku);
				if (!skuNodeSet.isEmpty()) {
					// -- Build the object property
					// hasStockKeepingUnit_EndEffector
					OWLObjectProperty OP_hasStockKeepingUnit_EndEffector = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasStockKeepingUnit_EndEffector()));
					for (OWLNamedIndividual sku : skuNodeSet.getFlattened()) {
						NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(sku,
										OP_hasStockKeepingUnit_EndEffector);
						if (!endEffectorNodeSet.isEmpty()) {
							for (OWLNamedIndividual endEffector : endEffectorNodeSet
									.getFlattened()) {
								l_init_section += "		(endEffector-is-for-kitTraySKU "
										+ m_cleaner.cleanIRI(endEffector) + " "
										+ m_cleaner.cleanIRI(sku) + ")\n";
							}

						}
					}

				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the function (= (quantity-of-parts-in-kit  ?stockKeepingUnit ?kit) ?value)
	 * 
	 * sets the quantity of parts of a certain stock keeping unit in a kit.
	 * <ul>
	 * <li>if kits are present in the OWL init file, the function is written.
	 * <li>if kits are not present in the OWL init file, the OWL goal file is parsed and the function is written from data coming from the OWL goal file.
	 * </ul>
	 * The process to build this funciton is as follows:
	 * <ul>
	 * <li>initialize a HashMap: key=stockKeepingUnit, value=occurrence of stockKeepingUnit in a kit
	 * <li>read <i>OWLClass:Kit</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is not empty
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>get parts in \f$\mathrm{kit_i}\f$
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(kit_i,hasKit\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>get the stock keeping unit of \f$\mathrm{part_j}\f$
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_k:(part_j,hasSkuObject\_Sku)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_k}\f$
	 * <ul>
	 * <li>put \f$\mathrm{stockKeepingUnit_k}\f$ in the HashMap
	 * </ul>
	 * </ul>
	 * <li>for each \f$element\f$ in HashMap
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (quantity-of-parts-in-kit\f$\mathrm{element.key}\f$ \f$\mathrm{kit_i}\f$) \f$\mathrm{element.value}\f$)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is empty
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is not empty
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>get parts in \f$\mathrm{kit_i}\f$
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(kit_i,hasKit\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>get the stock keeping unit of \f$\mathrm{part_j}\f$
	 * <li>build\f$\mathrm{skuNodeSet=[stockKeepingUnit_k:(part_j,hasSkuObject\_Sku)]_{j=1, k=1}^{j=o, k=p}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{stockKeepingUnit_k}\f$
	 * <ul>
	 * <li>put \f$\mathrm{stockKeepingUnit_k}\f$ in the HashMap
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * <li>for each \f$element\f$ in HashMap
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (quantity-of-parts-in-kit\f$\mathrm{element.key}\f$ \f$\mathrm{kit_i}\f$) \f$\mathrm{element.value}\f$)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_quantity_of_parts_in_kit() {
		Map<String, Integer> partSKUNumber_map = new HashMap<String, Integer>();
		ArrayList<String> partSKU_list = new ArrayList<String>();
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Kit in the init file
		OWLClass kitClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init
				.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasKit_Part
			OWLObjectProperty OP_hasKit_Part = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI.create(getM_InitOntology()
							.getM_init_IRI()
							+ getM_InitOntology().getM_OP_hasKit_Part()));
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {

				NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(kit, OP_hasKit_Part);

				if (!partNodeSet.isEmpty()) {
					OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
							.getOWLObjectProperty(IRI
									.create(getM_InitOntology().getM_init_IRI()
											+ getM_InitOntology()
											.getM_OP_hasSkuObject_Sku()));
					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						// System.out.println("Part: "+part);
						NodeSet<OWLNamedIndividual> skuNodeSet = m_OWLReasoner_Init
								.getObjectPropertyValues(part,
										OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()) {
							for (OWLNamedIndividual sku : skuNodeSet
									.getFlattened()) {
								if (!partSKUNumber_map.isEmpty()) {
									if (!partSKUNumber_map
											.containsKey(m_cleaner.cleanIRI(sku))) {
										partSKUNumber_map.put(m_cleaner.cleanIRI(sku), 1);
									} else {
										partSKUNumber_map
										.put(m_cleaner.cleanIRI(sku),
												partSKUNumber_map
												.get(m_cleaner.cleanIRI(sku)) + 1);
									}
								} else {
									partSKUNumber_map.put(m_cleaner.cleanIRI(sku), 1);
								}
							}
						}
					}
				}
				Iterator<Entry<String, Integer>> it = partSKUNumber_map
						.entrySet().iterator();
				while (it.hasNext()) {
					Entry<String, Integer> pairs = it.next();
					// System.out.println("--------> "+pairs.getKey() + " = " +
					// pairs.getValue());
					l_init_section += "		(= (quantity-of-parts-in-kit  "
							+ pairs.getKey() + " " + m_cleaner.cleanIRI(kit) + ") "
							+ pairs.getValue() + ")\n";
					it.remove(); // avoids a ConcurrentModificationException
				}
				partSKUNumber_map.clear();
			}
		}
		// -- kitNodeSet is empty
		// -- Let's get the kit in the goal file
		else {
			OWLReasoner l_OWLReasoner_Goal = getM_GoalOntology()
					.getM_goalOWLReasoner();
			m_OWLDataFactory_Init = getM_GoalOntology().getM_OWLDataFactory();

			// -- Get each individual from the OWL class Kit in the goal file
			kitClass = getM_GoalOntology().getClass(
					getM_GoalOntology().getM_owl_class_Kit());
			kitNodeSet = l_OWLReasoner_Goal.getInstances(kitClass, false);

			// -- Get each individual from the OWL class Part in the goal file
			OWLClass partClass = getM_GoalOntology().getClass(
					getM_GoalOntology().getM_owl_class_Part());
			NodeSet<OWLNamedIndividual> partNodeSet = l_OWLReasoner_Goal
					.getInstances(partClass, false);

			if (!kitNodeSet.isEmpty() && !partNodeSet.isEmpty()) {
				OWLObjectProperty OP_hasSkuObject_Sku = m_OWLDataFactory_Init
						.getOWLObjectProperty(IRI.create(getM_GoalOntology()
								.getM_goal_IRI()
								+ getM_GoalOntology()
								.getM_OP_hasSkuObject_Sku()));
				for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						NodeSet<OWLNamedIndividual> skuNodeSet = l_OWLReasoner_Goal
								.getObjectPropertyValues(part,
										OP_hasSkuObject_Sku);
						if (!skuNodeSet.isEmpty()) {
							for (OWLNamedIndividual sku : skuNodeSet
									.getFlattened()) {
								if (!partSKU_list.isEmpty()) {
									if (!partSKU_list
											.contains(m_cleaner.cleanIRI(sku))) {
										partSKU_list.add(m_cleaner.cleanIRI(sku));
									}
								} else {
									partSKU_list.add(m_cleaner.cleanIRI(sku));
								}
							}
						}
					}
					for (int i = 0; i < partSKU_list.size(); i++) {
						// System.out.println(partSKU_list.get(i));
						l_init_section += "		(= (quantity-of-parts-in-kit  " + partSKU_list.get(i) + " "
								+ m_cleaner.cleanIRI(kit) + ") 0)\n";
					}
					partSKU_list.clear();
				}
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the function (= (quantity-of-parts-in-partstray  ?partsTray) value)
	 * 
	 * set the quantity of parts in a parts tray
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:PartsTray</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{partsTrayNodeSet=[partsTray_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{partsTray_i}\f$
	 * <ul>
	 * <li>numberOfParts=0
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(partsTray_i,hasPartsVessel\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>numberOfParts++
	 * </ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (quantity-of-parts-in-partstray\f$\mathrm{partsTray_i}\f$) numberOfParts)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_quantity_of_parts_in_partstray() {
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class Part
		OWLClass partsTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_PartsTray());
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = m_OWLReasoner_Init
				.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()) {
			// -- Build the object property hasPartsVessel_Part
			OWLObjectProperty OP_hasPartsVessel_Part = m_OWLDataFactory_Init
					.getOWLObjectProperty(IRI
							.create(getM_InitOntology().getM_init_IRI()
									+ getM_InitOntology()
									.getM_OP_hasPartsVessel_Part()));
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened()) {
				int numberOfParts = 0;
				NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
						.getObjectPropertyValues(partsTray,
								OP_hasPartsVessel_Part);
				if (!partNodeSet.isEmpty()) {
					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						numberOfParts++;
					}
				}
				l_init_section += "		(= (quantity-of-parts-in-partstray  "
						+ m_cleaner.cleanIRI(partsTray) + ") " + numberOfParts + ")\n";
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the function (= (part-found-flag) ?flag)
	 * 
	 * <ul>
	 * <li>?flag=0 when a part is not found
	 * <li>?flag=1 when a part is found
	 * </ul>
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (part-found-flag) 1)
	 * </ul>
	 * */
	private void build_part_found_flag(){
		String l_init_section = getM_init_section();
		l_init_section += "		(= (part-found-flag) 1)\n";
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the function (= (capacity-of-kits-in-lbwk ?largeBoxWithKits) ?value)
	 * 
	 * set the quantity of kits in ?largeBoxWithKits
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:LargeBoxWithKits</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{largeBoxWithKitsNodeSet=[largeBoxWithKits_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{largeBoxWithKits_i}\f$
	 * <ul>
	 * <li>get\f$\mathrm{capacity=(largeBoxWithKits_i,hasLargeWithKits\_Capacity)_{i=1}^{i=n}}\f$
	 * <li>\f$\rightarrow\f$write in init section: (= (capacity-of-kits-in-lbwk\f$\mathrm{largeBoxWithKits_i}\f$) \f$\mathrm{capacity}\f$)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_capacity_of_kits_in_lbwk(){
		String l_init_section = getM_init_section();
		//-- Capacity of the LargeBoxWithKits
		int lbwkCapacity=0;

		//-- Get each individual from the OWL class LargeBoxWithKits
		OWLClass LargeBoxWithKitsClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithKits()); 
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = m_OWLReasoner_Init.getInstances(LargeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()){
			//-- Build the data property hasLargeWithKits_Capacity
			OWLDataProperty DP_hasLargeWithKits_Capacity = m_OWLDataFactory_Init.getOWLDataProperty(IRI.create(getM_InitOntology().getM_init_IRI()+		
					getM_InitOntology().getM_DP_hasLargeBoxWithKits_Capacity()));

			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet.getFlattened()){	
				//-- Get all the data properties for each LargeBoxWithKits
				Map<OWLDataPropertyExpression,Set<OWLLiteral>> largeBoxWithKitsMap = 
						largeBoxWithKits.getDataPropertyValues(getM_InitOntology().getM_OWLInitInstanceOntology());

				//-- Find the capacity
				if(largeBoxWithKitsMap.get(DP_hasLargeWithKits_Capacity) != null) {
					for(OWLLiteral d : largeBoxWithKitsMap.get(DP_hasLargeWithKits_Capacity)) {
						//System.out.println(cleanIRIDataProperty(d));
						//-- Convert the result into an Integer
						lbwkCapacity=Integer.parseInt(m_cleaner.cleanIRIDataProperty(d));
					}
				}
				l_init_section+="		(= (capacity-of-kits-in-lbwk "+
						m_cleaner.cleanIRI(largeBoxWithKits)+
						") "+lbwkCapacity+")\n";

			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the function (= (quantity-of-kittrays-in-lbwekt ?largeBoxWithEmptyKitTrays) ?value)
	 * 
	 * set the quantity of kit trays in ?largeBoxWithEmptyKitTrays
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:LargeBoxWithEmptyKitTrays</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{largeBoxWithEmptyKitTraysNodeSet=[largeBoxWithEmptyKitTrays_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{largeBoxWithEmptyKitTrays_i}\f$
	 * <ul>
	 * <li>numberOfKitTrays=0
	 * <li>build\f$\mathrm{kitTrayNodeSet=[kitTray_j:(largeBoxWithEmptyKitTrays_i,hasLargeBoxWithEmptyKitTrays\_KitTray)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kitTray_j}\f$
	 * <ul>
	 * <li>numberOfKitTrays++
	 * </ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (quantity-of-kittrays-in-lbwekt\f$\mathrm{largeBoxWithEmptyKitTrays_i}\f$) numberOfKitTrays)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_quantity_of_kittrays_in_lbwekt(){
		String l_init_section = getM_init_section();

		// -- Get each individual from the OWL class LargeBoxWithEmptyKitTrays
		OWLClass lbwektClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithEmptyKitTrays());
		NodeSet<OWLNamedIndividual> lbwektNodeSet = m_OWLReasoner_Init.getInstances(lbwektClass, false);
		if (!lbwektNodeSet.isEmpty()) {
			// -- Build the object property hasLargeBoxWithEmptyKitTrays_KitTray
			OWLObjectProperty OP_hasLargeBoxWithEmptyKitTrays_KitTray = m_OWLDataFactory_Init.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()
					+ getM_InitOntology().getM_OP_hasLargeBoxWithEmptyKitTrays_KitTray()));

			for (OWLNamedIndividual lbwekt : lbwektNodeSet.getFlattened()) {
				int quantity_of_kitTrays=0;

				NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(lbwekt,OP_hasLargeBoxWithEmptyKitTrays_KitTray);
				if (!kitTrayNodeSet.isEmpty()) {
					for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
						quantity_of_kitTrays++;	
					}
				}
				l_init_section+="		(= (quantity-of-kittrays-in-lbwekt "+
						m_cleaner.cleanIRI(lbwekt)+
						") "+quantity_of_kitTrays+")\n";
			}
		}
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Mapping for the function (= (quantity-of-kits-in-lbwk ?largeBoxWithKits) ?value)
	 * 
	 * set the quantity of kits in ?largeBoxWithKits
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:LargeBoxWithKits</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{largeBoxWithKitsNodeSet=[largeBoxWithKits_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{largeBoxWithKits_i}\f$
	 * <ul>
	 * <li>numberOfKits=0
	 * <li>build\f$\mathrm{kitNodeSet=[kit_j:(largeBoxWithKits_i,hasLargeBoxWithKits\_Kit)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_j}\f$
	 * <ul>
	 * <li>numberOfKits++
	 * </ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (quantity-of-kits-in-lbwk\f$\mathrm{largeBoxWithKits_i}\f$) numberOfKits)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_quantity_of_kits_in_lbwk(){
		String l_init_section = getM_init_section();
		// -- Get each individual from the OWL class LargeBoxWithEmptyKits
		OWLClass lbwkClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_LargeBoxWithKits());
		NodeSet<OWLNamedIndividual> lbwkNodeSet = m_OWLReasoner_Init.getInstances(lbwkClass, false);
		if (!lbwkNodeSet.isEmpty()) {
			// -- Build the object property hasLargeBoxWithKits_Kit
			OWLObjectProperty OP_hasLargeBoxWithKits_Kit = m_OWLDataFactory_Init.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()
					+ getM_InitOntology().getM_OP_hasLargeBoxWithKits_Kit()));

			for (OWLNamedIndividual lbwk : lbwkNodeSet.getFlattened()) {
				int quantity_of_kits=0;
				NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(lbwk,OP_hasLargeBoxWithKits_Kit);
				if (!kitNodeSet.isEmpty()) {
					for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
						quantity_of_kits++;	
					}
				}
				l_init_section+="		(= (quantity-of-kits-in-lbwk "+
						m_cleaner.cleanIRI(lbwk)+
						") "+quantity_of_kits+")\n";
			}
		}
		setM_init_section(l_init_section);
	}
	/**
	 * @brief Mapping for the function (= (current-quantity-of-parts-in-kit ?kit) ?value)
	 * 
	 * set the current quantity of parts in ?kit
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL init file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is not empty
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>numberOfParts=0
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(kit_i,hasKit\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>numberOfParts++
	 * </ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (current-quantity-of-parts-in-kit\f$\mathrm{kit_i}\f$) numberOfParts)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is empty
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <li>if \f$\mathrm{kitNodeSet}\f$ is not empty
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (current-quantity-of-parts-in-kit\f$\mathrm{kit_i}\f$) 0)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
	private void build_current_quantity_of_parts_in_kit(){
		String l_init_section = getM_init_section();
		// -- Get each individual from the OWL class Kit
		OWLClass kitClass = getM_InitOntology().getClass(getM_InitOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Init.getInstances(kitClass, false);
		if (!kitNodeSet.isEmpty()) {
			// -- Build the object property hasKit_Part
			OWLObjectProperty OP_hasKit_Part = m_OWLDataFactory_Init.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()
					+ getM_InitOntology().getM_OP_hasKit_Part()));

			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				int quantity_of_parts=0;
				NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(kit,OP_hasKit_Part);
				if (!partNodeSet.isEmpty()) {
					for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
						quantity_of_parts++;	
					}
				}
				l_init_section+="		(= (current-quantity-of-parts-in-kit "+
						m_cleaner.cleanIRI(kit)+
						") "+quantity_of_parts+")\n";
			}
		}
		//-- Get all the kits in the goal file and set the current quantity of parts to 0 for each kit
		else{
			kitClass = getM_GoalOntology().getClass(getM_GoalOntology().getM_owl_class_Kit());
			kitNodeSet = m_OWLReasoner_Goal.getInstances(kitClass, false);
			if (!kitNodeSet.isEmpty()) {
				for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
					l_init_section+="		(= (current-quantity-of-parts-in-kit "+
							m_cleaner.cleanIRI(kit)+
							") 0)\n";
				}
			}
		}
		setM_init_section(l_init_section);
	}
	
	/**
	 * @brief Mapping for the function (= (final-quantity-of-parts-in-kit ?kit) ?value)
	 * 
	 * set the expected quantity of parts in ?kit
	 * The process to build this function is as follows:
	 * <ul>
	 * <li>read <i>OWLClass:Kit</i> in OWL goal file
	 * <ul>
	 * <li>build\f$\mathrm{kitNodeSet=[kit_i]_{i=1}^{i=n}}\f$
	 * <ul>
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{kit_i}\f$
	 * <ul>
	 * <li>numberOfParts=0
	 * <li>build\f$\mathrm{partNodeSet=[part_j:(kit_i,hasKit\_Part)]_{i=1,j=1}^{i=n,j=o}}\f$
	 * <li>\f$\rightarrow\f$for each \f$\mathrm{part_j}\f$
	 * <ul>
	 * <li>numberOfParts++
	 * </ul>
	 * <li>\f$\rightarrow\f$write in init section: (= (final-quantity-of-parts-in-kit\f$\mathrm{kit_i}\f$) numberOfParts)\f$\mathrm{_{i=1}^{i=n}}\f$
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * </ul>
	 * */
private void build_final_quantity_of_parts_in_kit(){
	String l_init_section = getM_init_section();
	// -- Get each individual from the OWL class Kit
	OWLClass kitClass = getM_GoalOntology().getClass(getM_InitOntology().getM_owl_class_Kit());
	NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal.getInstances(kitClass, false);
	if (!kitNodeSet.isEmpty()) {
		// -- Build the object property hasKit_Part
		OWLObjectProperty OP_hasKit_Part = m_OWLDataFactory_Init.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()
				+ getM_InitOntology().getM_OP_hasKit_Part()));

		for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
			int quantity_of_parts=0;
			NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Goal.getObjectPropertyValues(kit,OP_hasKit_Part);
			if (!partNodeSet.isEmpty()) {
				for (OWLNamedIndividual part : partNodeSet.getFlattened()) {
					quantity_of_parts++;	
				}
			}
			l_init_section+="		(= (final-quantity-of-parts-in-kit "+
					m_cleaner.cleanIRI(kit)+
					") "+quantity_of_parts+")\n";
		}
	}
	setM_init_section(l_init_section);
	}

	

/**
 * @brief Build and write the different sections of the PDDL problem file
 * 
 * The problem file consists of:
 * <ul>
 * <li> A header: (define (problem kitting-problem)
 * <li> A reference to a domain file: (:domain kitting-domain)
 * <li> A "objects" section: (:objects ...)
 * <li> A "init" section: (:init ...)
 * <li> A "goal" section: (:goal ...)
 * </ul>
 */
	public void buildProblemFile() {
		// -- build the header for the problem file
		Soap soap = getM_Soap();
		Domain domain = soap.getM_domain();
		String l_problem = "(define (problem kitting-problem)\n" + "	(:domain "
				+ m_cleaner.cleanIRI(domain.getM_individual()) + ")\n";
		// -- Map the objects section
		buildObjects();
		// -- Map the init section
		buildInitState();
		// -- Map the goal section
		buildGoalState();

		l_problem = l_problem + getM_objects_section() + getM_init_section()
				+ getM_goal_section() + "\n)";
		// System.out.println(l_problem);
		setM_problem(l_problem);
	}

	/**
	 * @brief Build the section (:objects ...)
	 * 
	 * Reads relevant OWL classes and retrieve OWL individuals for each class.
	 * \remarks For the OWL class StockKeepingUnit, only stock keeping units for kit trays, parts, and parts trays are retrieved.
	 */
	private void buildObjects() {
		String l_objects_section = "	(:objects\n";
		// -- get the individuals for each type of object

		// -- Robot --//
		OWLClass robotClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Robot());
		NodeSet<OWLNamedIndividual> robotNodeSet = m_OWLReasoner_Init
				.getInstances(robotClass, false);
		if (!robotNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual robot : robotNodeSet.getFlattened())
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(robot) + " ";

			l_objects_section = l_objects_section + "- Robot\n";
		}
		// -- EndEffectorChangingStation --//
		OWLClass endEffectorChangingStationClass = getM_InitOntology()
				.getClass(
						getM_InitOntology()
						.getM_owl_class_EndEffectorChangingStation());
		NodeSet<OWLNamedIndividual> endEffectorChangingStationNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorChangingStationClass, false);
		if (!endEffectorChangingStationNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual endEffectorChangingStation : endEffectorChangingStationNodeSet
					.getFlattened())
				l_objects_section = l_objects_section
				+ m_cleaner.cleanIRI(endEffectorChangingStation) + " ";

			l_objects_section = l_objects_section
					+ "- EndEffectorChangingStation\n";
		}
		// -- KitTray --//
		OWLClass kitTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_KitTray());
		NodeSet<OWLNamedIndividual> kitTrayNodeSet = m_OWLReasoner_Init
				.getInstances(kitTrayClass, false);
		if (!kitTrayNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()) {
				// System.out.println("kiTray: "+ kitTray);
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(kitTray) + " ";
			}

			l_objects_section = l_objects_section + "- KitTray\n";
		}

		// -- Kit --//
		OWLClass kitClass = getM_GoalOntology().getClass(
				getM_GoalOntology().getM_owl_class_Kit());
		NodeSet<OWLNamedIndividual> kitNodeSet = m_OWLReasoner_Goal
				.getInstances(kitClass, false);

		if (!kitNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual kit : kitNodeSet.getFlattened()) {
				// System.out.println("kit: "+ kit);
				l_objects_section = l_objects_section
						+ m_cleaner.cleanIRI(kit) + " ";
			}

			l_objects_section = l_objects_section + "- Kit\n";
		}

		// -- LargeBoxWithEmptyKitTrays --//
		OWLClass largeBoxWithEmptyKitTraysClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_LargeBoxWithEmptyKitTrays());
		NodeSet<OWLNamedIndividual> largeBoxWithEmptyKitTraysNodeSet = m_OWLReasoner_Init
				.getInstances(largeBoxWithEmptyKitTraysClass, false);

		if (!largeBoxWithEmptyKitTraysNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual largeBoxWithEmptyKitTrays : largeBoxWithEmptyKitTraysNodeSet
					.getFlattened()) {
				// System.out.println("largeBoxWithEmptyKitTrays: "+
				// largeBoxWithEmptyKitTrays);
				l_objects_section = l_objects_section
						+ m_cleaner.cleanIRI(largeBoxWithEmptyKitTrays) + " ";
			}

			l_objects_section = l_objects_section
					+ "- LargeBoxWithEmptyKitTrays\n";
		}

		// -- LargeBoxWithKits --//
		OWLClass largeBoxWithKitsClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_LargeBoxWithKits());
		NodeSet<OWLNamedIndividual> largeBoxWithKitsNodeSet = m_OWLReasoner_Init
				.getInstances(largeBoxWithKitsClass, false);

		if (!largeBoxWithKitsNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual largeBoxWithKits : largeBoxWithKitsNodeSet
					.getFlattened())
				l_objects_section = l_objects_section
				+ m_cleaner.cleanIRI(largeBoxWithKits) + " ";

			l_objects_section = l_objects_section + "- LargeBoxWithKits\n";
		}

		// -- WorkTable --//
		OWLClass workTableClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_WorkTable());
		NodeSet<OWLNamedIndividual> workTableNodeSet = m_OWLReasoner_Init
				.getInstances(workTableClass, false);

		if (!workTableNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual workTable : workTableNodeSet.getFlattened())
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(workTable)
				+ " ";

			l_objects_section = l_objects_section + "- WorkTable\n";
		}

		// -- PartsTray --//
		OWLClass partsTrayClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_PartsTray());
		NodeSet<OWLNamedIndividual> partsTrayNodeSet = m_OWLReasoner_Init
				.getInstances(partsTrayClass, false);

		if (!partsTrayNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual partsTray : partsTrayNodeSet.getFlattened())
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(partsTray)
				+ " ";

			l_objects_section = l_objects_section + "- PartsTray\n";
		}

		// -- Part --//
		OWLClass partClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_Part());
		NodeSet<OWLNamedIndividual> partNodeSet = m_OWLReasoner_Init
				.getInstances(partClass, false);

		if (!partNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual part : partNodeSet.getFlattened())
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(part) + " ";

			l_objects_section = l_objects_section + "- Part\n";
		}

		// -- EndEffector --//
		OWLClass endEffectorClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffector());
		NodeSet<OWLNamedIndividual> endEffectorNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorClass, false);

		if (!endEffectorNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual endEffector : endEffectorNodeSet
					.getFlattened())
				l_objects_section = l_objects_section + m_cleaner.cleanIRI(endEffector)
				+ " ";

			l_objects_section = l_objects_section + "- EndEffector\n";
		}

		// -- EndEffectorHolder --//
		OWLClass endEffectorHolderClass = getM_InitOntology().getClass(
				getM_InitOntology().getM_owl_class_EndEffectorHolder());
		NodeSet<OWLNamedIndividual> endEffectorHolderNodeSet = m_OWLReasoner_Init
				.getInstances(endEffectorHolderClass, false);

		if (!endEffectorHolderNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual endEffectorHolder : endEffectorHolderNodeSet
					.getFlattened())
				l_objects_section = l_objects_section
				+ m_cleaner.cleanIRI(endEffectorHolder) + " ";

			l_objects_section = l_objects_section + "- EndEffectorHolder\n";
		}

		// -- StockKeepingUnit --//
		ArrayList<String> sku_list = new ArrayList<String>();
		//-- Search for stock keeping units for Parts and KitTrays only
		OWLDataFactory l_OWLDataFactory = getM_InitOntology().getM_OWLDataFactory();
		OWLObjectProperty OP_hasSkuObject_Sku = l_OWLDataFactory.getOWLObjectProperty(IRI.create(getM_InitOntology().getM_init_IRI()+ getM_InitOntology().getM_OP_hasSkuObject_Sku()));

		if (!partNodeSet.isEmpty()) {
			l_objects_section = l_objects_section + "		";
			for (OWLNamedIndividual part : partNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> partSkuNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(part,OP_hasSkuObject_Sku);
				if (!partSkuNodeSet.isEmpty()) {
					for (OWLNamedIndividual partSku : partSkuNodeSet.getFlattened()) {
						//-- store the sku in the arraylist
						sku_list.add(m_cleaner.cleanIRI(partSku));
					}
				}
			}
		}
		if (!kitTrayNodeSet.isEmpty()) {
			for (OWLNamedIndividual kitTray : kitTrayNodeSet.getFlattened()){
				NodeSet<OWLNamedIndividual> kitTraySkuNodeSet = m_OWLReasoner_Init.getObjectPropertyValues(kitTray,OP_hasSkuObject_Sku);
				if (!kitTraySkuNodeSet.isEmpty()) {
					for (OWLNamedIndividual kitTraySku : kitTraySkuNodeSet.getFlattened()) {
						//-- store the sku in the arraylist
						sku_list.add(m_cleaner.cleanIRI(kitTraySku));
					}
				}
			}
		}

		//-- remove duplicates in sku_list
		HashSet hs = new HashSet();
		hs.addAll(sku_list);
		sku_list.clear();
		sku_list.addAll(hs);

		for (int i=0; i<sku_list.size(); i++){
			l_objects_section = l_objects_section + sku_list.get(i)+" ";
		}

		l_objects_section = l_objects_section + "- StockKeepingUnit\n";

		// -- Close the objects section
		l_objects_section = l_objects_section + "	)\n";
		// System.out.println(l_objects_section);
		setM_objects_section(l_objects_section);
	}

	/**
	 * @brief Build the predicates in the section (:init ...)
	 * 
	 * Each predicate is built by calling its respective "build_" function.
	 */
	private void buildInitPredicates(){
		// -- endEffector-has-physicalLocation-refObject-robot
		build_endEffector_has_physicalLocation_refObject_robot();
		// -- endEffectorHolder-has-physicalLocation-refObject-changingStation
		build_endEffectorHolder_has_physicalLocation_refObject_changingStation();
		// -- endEffector-has-physicalLocation-refObject-endEffectorHolder
		build_endEffector_has_physicalLocation_refObject_endEffectorHolder();
		// -- endEffector-has-heldObject-kitTray
		build_endEffector_has_heldObject_kitTray();
		// -- endEffector-has-heldObject-kit
		build_endEffector_has_heldObject_kit();
		// -- endEffector-has-heldObject-part
		build_endEffector_has_heldObject_part();
		// -- endEffector-has-no-heldObject
		build_endEffector_has_no_heldObject();
		// -- endEffector-is-for-partSKU
		build_endEffector_is_for_partSKU();
		// -- endEffectorHolder-has-endEffector
		build_endEffectorHolder_has_endEffector();
		// -- endEffectorChangingStation-has-endEffectorHolder
		build_endEffectorChangingStation_has_endEffectorHolder();
		// --robot-has-endEffector
		build_robot_has_endEffector();
		// -- robot-has-no-endEffector
		build_robot_has_no_endEffector();
		// -- workTable-has-objectOnTable-kit
		build_workTable_has_objectOnTable_kit();
		// -- workTable-has-objectOnTable-kitTray
		build_workTable_has_objectOnTable_kitTray();
		// -- kit-has-physicalLocation-refObject-lbwk
		build_kit_has_physicalLocation_refObject_lbwk();
		// -- kit-has-physicalLocation-refObject-workTable
		build_kit_has_physicalLocation_refObject_workTable();
		// -- kit-has-physicalLocation-refObject-endEffector
		build_kit_has_physicalLocation_refObject_endEffector();
		// -- kit-has-kitTray
		build_kit_has_kitTray();
		// -- kit-exists
		build_kit_exists();
		// -- lbwk-has-kit
		build_lbwk_has_kit();
		// -- partsVessel-has-part
		build_partsVessel_has_part();
		// -- workTable-has-no-objectOnTable
		build_workTable_has_no_objectOnTable();
		// -- kittray-location-lbwekt
		build_kitTray_has_physicalLocation_refObject_lbwekt();
		// -- kitTray-has-physicalLocation-refObject-endEffector
		build_kitTray_has_physicalLocation_refObject_endEffector();
		// -- kitTray-has-physicalLocation-refObject-workTable
		build_kitTray_has_physicalLocation_refObject_workTable();
		// -- kitTray-has-physicalLocation-refObject-kit
		build_kitTray_has_physicalLocation_refObject_kit();
		// -- kitTray-has-skuObject-sku
		build_kitTray_has_skuObject_sku();
		// -- part-has-physicalLocation-refObject-partsTray
		build_part_has_physicalLocation_refObject_partsTray();
		// -- part-has-physicalLocation-refObject-kit
		build_part_has_physicalLocation_refObject_kit();
		// -- part-has-physicalLocation-refObject-endEffector
		build_part_has_physicalLocation_refObject_endEffector();
		// -- part-has-skuObject-sku
		build_part_has_skuObject_sku();
		// -- endEffector-is-for-kitTraySKU
		build_endEffector_is_for_kitTraySKU();
	}

	/**
	 * @brief Build the functions in the section (:init ...)
	 * 
	 * Each function is built by calling its respective "build_" function.
	 */
	private void buildInitFunctions(){
		build_capacity_of_parts_in_kit();
		build_quantity_of_parts_in_kit();
		build_quantity_of_parts_in_partstray();
		build_part_found_flag();
		build_capacity_of_kits_in_lbwk();
		build_quantity_of_kittrays_in_lbwekt();
		build_quantity_of_kits_in_lbwk();
		build_current_quantity_of_parts_in_kit();
		build_final_quantity_of_parts_in_kit();
	}
	/**
	 * @brief Build the the section (:init ...)
	 * 
	 * PDDL predicates in the init section are built with the buildInitPredicates() function
	 * 
	 * PDDL function in the init section are built with the buildInitFunctions() function 
	 */
	private void buildInitState() {
		String l_init_section = "	(:init\n";
		setM_init_section(l_init_section);

		buildInitPredicates();
		buildInitFunctions();
		l_init_section = getM_init_section();
		l_init_section += "	)\n";
		setM_init_section(l_init_section);
	}

	/**
	 * @brief Build the the section (:goal ...) 
	 */
	private void buildGoalState() {
		String l_goal_section = "	(:goal\n" + "		(and\n";
		setM_goal_section(l_goal_section);
		build_kit_has_physicalLocation_refObject_lbwk_goal();
		build_lbwk_has_kit_goal();
		l_goal_section = getM_goal_section();
		l_goal_section += "		)\n" + "	)";
		setM_goal_section(l_goal_section);

		// System.out.println(getM_goal_section());
	}

	/**
	 * @return the m_SoapOntology
	 */
	public SoapOntology getM_SoapOntology() {
		return m_SoapOntology;
	}

	/**
	 * @param m_SoapOntology
	 *            the m_SoapOntology to set
	 */
	public void setM_SoapOntology(SoapOntology m_SoapOntology) {
		this.m_SoapOntology = m_SoapOntology;
	}

	/**
	 * @return the m_InitOntology
	 */
	public InitOntology getM_InitOntology() {
		return m_InitOntology;
	}

	/**
	 * @param m_InitOntology
	 *            the m_InitOntology to set
	 */
	public void setM_InitOntology(InitOntology m_InitOntology) {
		this.m_InitOntology = m_InitOntology;
	}

	/**
	 * @return the m_GoalOntology
	 */
	public GoalOntology getM_GoalOntology() {
		return m_GoalOntology;
	}

	/**
	 * @param m_GoalOntology
	 *            the m_GoalOntology to set
	 */
	public void setM_GoalOntology(GoalOntology m_GoalOntology) {
		this.m_GoalOntology = m_GoalOntology;
	}

	/**
	 * @return the m_objects_section
	 */
	public String getM_objects_section() {
		return m_objects_section;
	}

	/**
	 * @param m_objects_section
	 *            the m_objects_section to set
	 */
	public void setM_objects_section(String m_objects_section) {
		this.m_objects_section = m_objects_section;
	}

	/**
	 * @return the m_init_section
	 */
	public String getM_init_section() {
		return m_init_section;
	}

	/**
	 * @param m_init_section
	 *            the m_init_section to set
	 */
	public void setM_init_section(String m_init_section) {
		this.m_init_section = m_init_section;
	}

	/**
	 * @return the m_goal_section
	 */
	public String getM_goal_section() {
		return m_goal_section;
	}

	/**
	 * @param m_goal_section
	 *            the m_goal_section to set
	 */
	public void setM_goal_section(String m_goal_section) {
		this.m_goal_section = m_goal_section;
	}

	/**
	 * @param m_kit_skuPart_map
	 *            the m_kit_skuPart_map to set
	 */
	private void setM_kit_skuPart_map(
			Map<String, Collection<String>> m_kit_skuPart_map) {
		this.m_kit_skuPart_map = m_kit_skuPart_map;
	}

	/**
	 * @return the m_problem
	 */
	public String getM_problem() {
		return m_problem;
	}

	/**
	 * @param m_problem
	 *            the m_problem to set
	 */
	public void setM_problem(String m_problem) {
		this.m_problem = m_problem;
	}

	/**
	 * @return the m_Soap
	 */
	public Soap getM_Soap() {
		return m_Soap;
	}

	/**
	 * @param m_Soap
	 *            the m_Soap to set
	 */
	public void setM_Soap(Soap m_Soap) {
		this.m_Soap = m_Soap;
	}

}
