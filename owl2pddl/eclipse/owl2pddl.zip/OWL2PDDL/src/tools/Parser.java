/**
 * 
 */
package tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author zeid
 *
 */
public class Parser {
	private String m_soapInstancePath="";
	private String m_initInstancePath="";
	private String m_goalInstancePath="";
	private String m_domainPath="";
	private String m_problemPath="";
	/**
	 * 
	 */
	public Parser(String configFilePath) {
		String filePath = new File("").getAbsolutePath();


		File file = new File(filePath.concat("/"+configFilePath));
		//System.out.println("filepath: "+file);

		try {
			Scanner scanner = new Scanner(file);

			//now read the file line by line...
			int lineNum = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				lineNum++;
				//-- Look for SOAP_Instance
				if(line.contains("SOAP_Instance") && !line.contains("#")) { 

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String soapInstancePath = line.substring(colonPosition+1,closingBracketPosition).replaceAll("\\s+","");
					setM_soapInstancePath(soapInstancePath);
					//System.out.println("SOAP_Instance: " +soapInstancePath);
				}
				//-- Look for INIT_Instance
				else if(line.contains("INIT_Instance") && !line.contains("#")) { 

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String initInstancePath = line.substring(colonPosition+1,closingBracketPosition).replaceAll("\\s+","");
					setM_initInstancePath(initInstancePath);
					//System.out.println("INIT_Instance: " +initInstancePath);
				}
				//-- Look for GOAL_Instance
				else if(line.contains("GOAL_Instance") && !line.contains("#")) { 

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String goalInstancePath = line.substring(colonPosition+1,closingBracketPosition).replaceAll("\\s+","");
					setM_goalInstancePath(goalInstancePath);
					//System.out.println("GOAL_Instance: " +goalInstancePath);
				}
				//-- Look for DOMAIN
				else if(line.contains("DOMAIN") && !line.contains("#")) { 

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String domainPath = line.substring(colonPosition+1,closingBracketPosition).replaceAll("\\s+","");
					setM_domainPath(domainPath);
					//System.out.println("DOMAIN: " +domainPath);
				}
				//-- Look for PROBLEM
				else if(line.contains("PROBLEM") && !line.contains("#")) { 

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String problemPath = line.substring(colonPosition+1,closingBracketPosition).replaceAll("\\s+","");
					setM_problemPath(problemPath);
					//System.out.println("PROBLEM: " +problemPath);
				}
			}
		} catch(FileNotFoundException e) { 
			//handle this
		}

		//-- Check that the results are not empty
		checkParsedResult();
	}

	private void checkParsedResult(){
		String l_soapInstancePath=getM_soapInstancePath();
		if (l_soapInstancePath.isEmpty()){
			System.out.println("ERROR: Path not set for SOAP_Instance...exiting");
			System.exit(0);
		}
		String l_initInstancePath=getM_initInstancePath();
		if (l_initInstancePath.isEmpty()){
			System.out.println("ERROR: Path not set for INIT_Instance...exiting");
			System.exit(0);
		}
		String l_goalInstancePath=getM_goalInstancePath();
		if (l_goalInstancePath.isEmpty()){
			System.out.println("ERROR: Path not set for GOAL_Instance...exiting");
			System.exit(0);
		}
		String l_domainPath=getM_domainPath();
		if (l_domainPath.isEmpty()){
			System.out.println("ERROR: Path not set for DOMAIN...exiting");
			System.exit(0);
		}
		String l_problemPath=getM_problemPath();
		if (l_problemPath.isEmpty()){
			System.out.println("ERROR: Path not set for PROBLEM...exiting");
			System.exit(0);
		}
	}
	/**
	 * @return the m_soapInstancePath
	 */
	public String getM_soapInstancePath() {
		return m_soapInstancePath;
	}
	/**
	 * @param m_soapInstancePath the m_soapInstancePath to set
	 */
	public void setM_soapInstancePath(String m_soapInstancePath) {
		this.m_soapInstancePath = m_soapInstancePath;
	}
	/**
	 * @return the m_initInstancePath
	 */
	public String getM_initInstancePath() {
		return m_initInstancePath;
	}
	/**
	 * @param m_initInstancePath the m_initInstancePath to set
	 */
	public void setM_initInstancePath(String m_initInstancePath) {
		this.m_initInstancePath = m_initInstancePath;
	}
	/**
	 * @return the m_goalInstancePath
	 */
	public String getM_goalInstancePath() {
		return m_goalInstancePath;
	}
	/**
	 * @param m_goalInstancePath the m_goalInstancePath to set
	 */
	public void setM_goalInstancePath(String m_goalInstancePath) {
		this.m_goalInstancePath = m_goalInstancePath;
	}
	/**
	 * @return the m_domainPath
	 */
	public String getM_domainPath() {
		return m_domainPath;
	}
	/**
	 * @param m_domainPath the m_domainPath to set
	 */
	public void setM_domainPath(String m_domainPath) {
		this.m_domainPath = m_domainPath;
	}
	/**
	 * @return the m_problemPath
	 */
	public String getM_problemPath() {
		return m_problemPath;
	}
	/**
	 * @param m_problemPath the m_problemPath to set
	 */
	public void setM_problemPath(String m_problemPath) {
		this.m_problemPath = m_problemPath;
	}

}
