/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package tools;

/**
 * @brief Get the different paths needed in the project from environment variables
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 * 
 * @details This class is used to retrieve environment variables that the user has set in his .bashrc. 
 * 
 * The value of each variable is retrieved via the getEnvironmentVariable() function. 
 * 
 * Appropriate setters are used to set the value of each internal Java variable.
 */
public class PathGetter {
	private String m_soapInstancePath;
	private String m_initInstancePath;
	private String m_goalInstancePath;
	private String m_domainPath;
	private String m_problemPath;

	/**
	 * @brief sets the paths to OWL files and PDDL domain and problem files
	 * <ul>
	 * <li>The path to the OWL soap file is given by the environment variable PATH_SOAP_OWL_FILE
	 * <li>The path to the OWL init file is given by the environment variable PATH_INIT_OWL_FILE
	 * <li>The path to the OWL goal file is given by the environment variable PATH_GOAL_OWL_FILE
	 * <li>The path to the PDDL domain file is given by the environment variable PATH_DOMAIN_OUTPUT_FILE
	 * <li>The path to the PDDL problem file is given by the environment variable PATH_PROBLEM_OUTPUT_FILE
	 * </ul>
	 */
	public PathGetter(){
		setM_soapInstancePath(getEnvironmentVariable("PATH_SOAP_OWL_FILE"));
		setM_initInstancePath(getEnvironmentVariable("PATH_INIT_OWL_FILE"));
		setM_goalInstancePath(getEnvironmentVariable("PATH_GOAL_OWL_FILE"));
		setM_domainPath(getEnvironmentVariable("PATH_DOMAIN_OUTPUT_FILE"));
		setM_problemPath(getEnvironmentVariable("PATH_PROBLEM_OUTPUT_FILE"));
	}

	/**
	 * @brief returns the value of an environment variable
	 * @param env environment variable
	 * @return value of the environment variable
	 */
	private static String getEnvironmentVariable (String env) {
		final String value = System.getenv(env);
		if (value == null) {
			//System.out.format("%s=%s%n",env, value);
			System.out.format("%s is"
					+ " not assigned.%n...exiting", env);
			System.exit(0);
		}
		return value;
	}
	/**
	 * @return the m_soapInstancePath
	 */
	public String getM_soapInstancePath() {
		return m_soapInstancePath;
	}

	/**
	 * @param m_soapInstancePath
	 *            the m_soapInstancePath to set
	 */
	public void setM_soapInstancePath(String m_soapInstancePath) {
		this.m_soapInstancePath = m_soapInstancePath;
	}

	/**
	 * @return the m_initInstancePath
	 */
	public String getM_initInstancePath() {
		return m_initInstancePath;
	}

	/**
	 * @param m_initInstancePath
	 *            the m_initInstancePath to set
	 */
	public void setM_initInstancePath(String m_initInstancePath) {
		this.m_initInstancePath = m_initInstancePath;
	}

	/**
	 * @return the m_goalInstancePath
	 */
	public String getM_goalInstancePath() {
		return m_goalInstancePath;
	}

	/**
	 * @param m_goalInstancePath
	 *            the m_goalInstancePath to set
	 */
	public void setM_goalInstancePath(String m_goalInstancePath) {
		this.m_goalInstancePath = m_goalInstancePath;
	}

	/**
	 * @return the m_domainPath
	 */
	public String getM_domainPath() {
		return m_domainPath;
	}

	/**
	 * @param m_domainPath
	 *            the m_domainPath to set
	 */
	public void setM_domainPath(String m_domainPath) {
		this.m_domainPath = m_domainPath;
	}

	/**
	 * @return the m_problemPath
	 */
	public String getM_problemPath() {
		return m_problemPath;
	}

	/**
	 * @param m_problemPath
	 *            the m_problemPath to set
	 */
	public void setM_problemPath(String m_problemPath) {
		this.m_problemPath = m_problemPath;
	}

}
