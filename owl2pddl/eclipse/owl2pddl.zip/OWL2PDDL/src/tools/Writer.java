/**
 * 
 */
package tools;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.FunctionOperation;
import knowledge.FunctionToDecimalBool;
import knowledge.FunctionToFunctionBool;
import knowledge.NegativePredicate;
import knowledge.Ontology;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.Soap;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Tools to write the PDDL domain file
 * @author zeid
 * 
 */
public class Writer {
	private Cleaner m_cleaner;

	/**
	 * 
	 */
	public Writer() {
		// TODO Auto-generated constructor stub
		m_cleaner = new Cleaner();
	}

	/**
	 * @brief Write the PDDL 'requirements' section
	 * @param myList
	 *            List of requirements for the current domain
	 * @param myWriter
	 *            An instance of PrintWriter
	 */
	public void writeDomainRequirements(ArrayList<String> myList,
			PrintWriter myWriter) {
		myWriter.print("	(:requirements ");
		for (int i = 0; i < myList.size(); i++) {
			if (i == myList.size() - 1)
				myWriter.print(":" + myList.get(i) + ")");
			else
				myWriter.print(":" + myList.get(i) + " ");
		}
	}

	/**
	 * @brief Write the PDDL 'types' section
	 * @param myList
	 *            List of types for the current domain
	 * @param myWriter
	 *            An instance of PrintWriter
	 */
	public void writeDomainVariables(ArrayList<String> myList,
			PrintWriter myWriter) {
		myWriter.println("\n	(:types ");
		for (int i = 0; i < myList.size(); i++) {
			if (i == myList.size() - 1)
				myWriter.println("		" + myList.get(i) + ")");
			else
				myWriter.println("		" + myList.get(i));
		}
	}

	/**
	 * @brief Write the PDDL 'predicates' section
	 * @param myList
	 *            List of predicates for the current domain
	 * @param myOntology
	 *            Instance of Ontology
	 * @param myWriter
	 *            Instance of PrintWriter
	 */
	public void writeDomainPredicates(ArrayList<PositivePredicate> myList,
			Ontology myOntology, PrintWriter myWriter) {
		myWriter.println("	(:predicates");
		for (int i = 0; i < myList.size(); i++) {
			PositivePredicate positivePredicate = myList.get(i);

			if (!positivePredicate.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					myWriter.println("		"
							+ positivePredicate.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
							+ " ?"
							+ positivePredicate.getM_reference_parameter()
									.toLowerCase()
							+ " - "
							+ positivePredicate.getM_reference_parameter()
							+ " ?"
							+ positivePredicate.getM_target_parameter()
									.toLowerCase() + " - "
							+ positivePredicate.getM_target_parameter() + ")");
				} else {
					myWriter.println("		"
							+ positivePredicate.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
							+ " ?"
							+ positivePredicate.getM_reference_parameter()
									.toLowerCase()
							+ " - "
							+ positivePredicate.getM_reference_parameter()
							+ " ?"
							+ positivePredicate.getM_target_parameter()
									.toLowerCase() + " - "
							+ positivePredicate.getM_target_parameter() + ")\n");
				}
			} else {
				if (i == myList.size() - 1) {
					myWriter.println("		"
							+ positivePredicate.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
							+ " ?"
							+ positivePredicate.getM_reference_parameter()
									.toLowerCase() + " - "
							+ positivePredicate.getM_reference_parameter()
							+ ")");
				} else {
					myWriter.println("		"
							+ positivePredicate.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
							+ " ?"
							+ positivePredicate.getM_reference_parameter()
									.toLowerCase() + " - "
							+ positivePredicate.getM_reference_parameter()
							+ ")\n");
				}
			}
		}
		myWriter.println("	);End of the predicates section");
	}

	/**
	 * @brief Write the PDDL 'functions' section
	 * @param myList
	 *            List of functions for the current domain
	 * @param myOntology
	 *            Instance of Ontology
	 * @param myWriter
	 *            Instance of PrintWriter
	 */
	public void writeDomainFunctions(ArrayList<Function> myList,
			Ontology myOntology, PrintWriter myWriter) {
		myWriter.println("	(:functions");
		for (int i = 0; i < myList.size(); i++) {
			Function function = myList.get(i);

			if (!function.getM_reference_parameter().isEmpty()
					&& !function.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					myWriter.println("		" + function.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ " ?"
							+ function.getM_target_parameter().toLowerCase()
							+ " - " + function.getM_target_parameter() + ")");
				} else {
					myWriter.println("		" + function.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ " ?"
							+ function.getM_target_parameter().toLowerCase()
							+ " - " + function.getM_target_parameter() + ")\n");
				}
			} else if (!function.getM_reference_parameter().isEmpty()
					&& function.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					myWriter.println("		" + function.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter() + ")");
				} else {
					myWriter.println("		" + function.getM_description());
					myWriter.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ ")\n");
				}
			} else if (function.getM_reference_parameter().isEmpty()
					&& function.getM_target_parameter().isEmpty()) {
				myWriter.println("		" + function.getM_description());
				myWriter.println("		("
						+ m_cleaner.cleanIRI(function.getM_individual())
						+ ")\n");
			}
		}
		myWriter.println("	);End of the functions section\n");
	}

	public void writeDomainActions(Domain myDomain, ArrayList<Action> myList,
			Ontology myOntology, PrintWriter myWriter) {

		for (int i = 0; i < myList.size(); i++) {
			Action action = myList.get(i);
			myWriter.println("	(:action "
					+ m_cleaner.cleanIRI(action.getM_individual()));
			myWriter.println("		:parameters(");
			ArrayList<String> parameter_set_list = action.getM_parameter_set();

			for (int j = 0; j < parameter_set_list.size(); j++) {
				if (j == parameter_set_list.size() - 1) {
					myWriter.println("			?"
							+ parameter_set_list.get(j).toLowerCase() + " - "
							+ parameter_set_list.get(j) + ")");
				} else {
					myWriter.println("			?"
							+ parameter_set_list.get(j).toLowerCase() + " - "
							+ parameter_set_list.get(j));
				}
			}
			writeActionPrecondition(myDomain,
					action.getM_action_precondition(), myOntology, myWriter);
			writeActionEffect(myDomain, action.getM_action_effect(),
					myOntology, myWriter);
			// displayEffect(action.getM_action_effect(), myOntology);
			myWriter.println("	)");
		}

	}

	public PositivePredicate lookForPositivePredicate(
			NegativePredicate myNegativePredicate, Ontology myOntology,
			Domain myDomain) {
		ArrayList<PositivePredicate> positive_predicate_list = myDomain
				.getM_positive_predicate_list();
		PositivePredicate positive_predicate = new PositivePredicate();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);
			OWLIndividual positive_predicate_for_negative_predicate = myNegativePredicate
					.getM_positive_predicate();
			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (m_cleaner.cleanIRI(positive_predicate_for_negative_predicate)
					.compareTo(m_cleaner.cleanIRI(tmp_predicate.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
			}
		}
		return positive_predicate;
	}

	public void writeNegativePredicate(PositivePredicate myPredicate,
			Ontology myOntology, Domain myDomain, PrintWriter myWriter,
			Boolean end) {
		if (end) {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				myWriter.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ ")))");
			} else {
				myWriter.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ ")))");

			}
		} else {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				myWriter.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ "))");
			} else {
				myWriter.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ "))");

			}
		}
	}

	public void writePositivePredicate(PositivePredicate myPredicate,
			Ontology myOntology, Domain myDomain, PrintWriter myWriter,
			Boolean end) {

		if (end) {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				myWriter.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ "))");
			} else {
				myWriter.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ "))");

			}
		} else {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				myWriter.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ ")");
			} else {
				myWriter.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ ")");

			}
		}
	}

	/**
	 * 
	 * @param myPredicate
	 * @param myOntology
	 * @param myDomain
	 * @param myWriter
	 * @param end
	 *            Boolean value telling if this is the last predicate to write
	 *            in the precondition, in that case, we add a closing
	 *            parenthesis ')'
	 */
	public void writePreconditionPredicate(String myPredicate,
			Ontology myOntology, Domain myDomain, PrintWriter myWriter,
			Boolean end) {
		PositivePredicate positive_predicate = new PositivePredicate();

		// -- Check the list of negative predicates
		ArrayList<NegativePredicate> negative_predicate_list = myDomain
				.getM_negative_predicate_list();
		for (int i = 0; i < negative_predicate_list.size(); i++) {

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate
					.compareTo(m_cleaner.cleanIRI(negative_predicate_list.get(
							i).getM_individual())) == 0) {
				positive_predicate = lookForPositivePredicate(
						negative_predicate_list.get(i), myOntology, myDomain);
				writeNegativePredicate(positive_predicate, myOntology,
						myDomain, myWriter, end);
			}
		}
		// -- Check the list of positive predicates
		ArrayList<PositivePredicate> positive_predicate_list = myDomain
				.getM_positive_predicate_list();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate.compareTo(m_cleaner.cleanIRI(tmp_predicate
					.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
				writePositivePredicate(positive_predicate, myOntology,
						myDomain, myWriter, end);
			}
		}
	}

	public void writeEffectPredicate(String myPredicate, Ontology myOntology,
			Domain myDomain, PrintWriter myWriter, Boolean end) {
		PositivePredicate positive_predicate = new PositivePredicate();

		// -- Check the list of negative predicates
		ArrayList<NegativePredicate> negative_predicate_list = myDomain
				.getM_negative_predicate_list();
		for (int i = 0; i < negative_predicate_list.size(); i++) {

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate
					.compareTo(m_cleaner.cleanIRI(negative_predicate_list.get(
							i).getM_individual())) == 0) {
				positive_predicate = lookForPositivePredicate(
						negative_predicate_list.get(i), myOntology, myDomain);
				writeNegativePredicate(positive_predicate, myOntology,
						myDomain, myWriter, end);
			}
		}
		// -- Check the list of positive predicates
		ArrayList<PositivePredicate> positive_predicate_list = myDomain
				.getM_positive_predicate_list();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate.compareTo(m_cleaner.cleanIRI(tmp_predicate
					.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
				writePositivePredicate(positive_predicate, myOntology,
						myDomain, myWriter, end);
			}
		}
	}

	public void writeFunctionToFunctionBool(String myF1, String myF2,
			String myExpression, Domain myDomain, Ontology myOntology,
			PrintWriter myWriter) {
		Function f1 = lookForFunction(myF1, myOntology, myDomain);
		Function f2 = lookForFunction(myF2, myOntology, myDomain);

		// -- Write the opening parenthesis
		myWriter.print("			(");
		// -- Write the expression
		myWriter.print(myExpression);
		// -- Write f1
		myWriter.print(buildFunctionStructure(f1));
		// -- Write f2
		myWriter.print(buildFunctionStructure(f2));
		// -- Write closing parenthesis
		myWriter.print(")\n");

	}

	public void writeFunctionToDecimalBool(String myF1, String d,
			String myExpression, Domain myDomain, Ontology myOntology,
			PrintWriter myWriter) {
		Function f1 = lookForFunction(myF1, myOntology, myDomain);

		// -- Write the opening parenthesis
		myWriter.print("			(");
		// -- Write the expression
		myWriter.print(myExpression);
		// -- Write f1
		myWriter.print(buildFunctionStructure(f1));
		// -- Write f2
		myWriter.print(d);
		// -- Write closing parenthesis
		myWriter.print(")\n");
	}

	public Function lookForFunction(String myFunction, Ontology myOntology,
			Domain myDomain) {
		ArrayList<Function> function_list = myDomain.getM_function_list();
		Function function = new Function();
		for (int i = 0; i < function_list.size(); i++) {
			Function tmp_function = function_list.get(i);

			if (m_cleaner.cleanIRI(tmp_function.getM_individual()).compareTo(
					myFunction) == 0) {
				function = tmp_function;
			}
		}
		return function;
	}

	/**
	 * @brief build the structure of a function based on its parameters PDDL
	 *        functions may have 0, 1 (reference), or 2 (reference and target)
	 *        parameters. Based on the number of parameters, this function build
	 *        PDDL functions accordingly. An instance of a PDDL function with 0
	 *        parameter is (part-found-flag).<br>
	 *        An instance of a PDDL function with 1 parameter is
	 *        (final-quantity-of-parts-in-kit ?kit) An instance of a PDDL
	 *        function with 2 parameters is (quantity-of-parts-in-kit
	 *        ?stockkeepingunit ?kit)
	 * @param function
	 * @return The function built
	 */
	private String buildFunctionStructure(Function function) {
		String functionOutput_s = "";
		boolean refParam_bool = true;
		boolean targetParam_bool = true;

		if (function.getM_reference_parameter().isEmpty()) {
			refParam_bool = false;
			targetParam_bool = false;
		}

		if (function.getM_target_parameter().isEmpty()) {
			targetParam_bool = false;
		}

		if (refParam_bool && targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + " ?"
					+ function.getM_reference_parameter().toLowerCase() + " ?"
					+ function.getM_target_parameter().toLowerCase() + ") ";
		} else if (refParam_bool && !targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + " ?"
					+ function.getM_reference_parameter().toLowerCase() + ") ";
		} else if (!refParam_bool && !targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + ") ";
		}

		return functionOutput_s;
	}

	public void writeFunctionOperation(String myFunction, String myExpression,
			Integer myValue, Domain myDomain, Ontology myOntology,
			PrintWriter myWriter) {
		Function function = lookForFunction(myFunction, myOntology, myDomain);

		// -- Write the expression
		myWriter.print("			(" + myExpression);
		// -- Write the function
		myWriter.print(buildFunctionStructure(function));
		// -- Write the value
		myWriter.println(+myValue + ")");
	}

	public void writeActionPrecondition(Domain myDomain,
			Precondition myPrecondition, Ontology myOntology,
			PrintWriter myWriter) {
		// System.out.println("\n +precondition: "+myOntology.cleanIRI(myPrecondition.getM_individual()));
		ArrayList<String> l_predicate_list = myPrecondition
				.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myPrecondition
				.getM_f2f_list();
		ArrayList<FunctionToDecimalBool> l_f2d_list = myPrecondition
				.getM_f2d_list();
		ArrayList<FunctionOperation> l_function_operation_list = myPrecondition
				.getM_function_operation_list();

		if (l_predicate_list.size() > 1 || l_f2f_list.size() > 1
				|| l_function_operation_list.size() > 1)
			myWriter.println("		:precondition(and");
		else
			myWriter.println("		:precondition(");

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				writeFunctionToFunctionBool(f1, f2, expression, myDomain,
						myOntology, myWriter);
			}
		}

		// -- Display all FunctionToDecimalBool
		if (!l_f2d_list.isEmpty()) {
			for (int i = 0; i < l_f2d_list.size(); i++) {
				FunctionToDecimalBool f2d = l_f2d_list.get(i);
				String f = f2d.getF1();
				String d = f2d.getD1();
				String expression = f2d.getExpression();
				writeFunctionToDecimalBool(f, d, expression, myDomain,
						myOntology, myWriter);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				writeFunctionOperation(l_function, l_expression, l_value,
						myDomain, myOntology, myWriter);
			}
		}

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				String predicate_s = l_predicate_list.get(k);
				if (k == l_predicate_list.size() - 1) {
					writePreconditionPredicate(predicate_s, myOntology,
							myDomain, myWriter, true);
				} else
					writePreconditionPredicate(predicate_s, myOntology,
							myDomain, myWriter, false);
			}
		}
	}

	public void writeActionEffect(Domain myDomain, Effect myEffect,
			Ontology myOntology, PrintWriter myWriter) {
		// System.out.println("\n +effect: "+myOntology.cleanIRI(myEffect.getM_individual()));
		ArrayList<String> l_predicate_list = myEffect.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myEffect.getM_f2f_list();
		ArrayList<FunctionToDecimalBool> l_f2d_list = myEffect.getM_f2d_list();
		ArrayList<FunctionOperation> l_function_operation_list = myEffect
				.getM_function_operation_list();

		// if (l_predicate_list.size() > 1 || l_f2f_list.size() > 1
		// || l_function_operation_list.size() > 1)
		myWriter.println("		:effect(and");
		// else
		// myWriter.println("		:effect(");

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				writeFunctionToFunctionBool(f1, f2, expression, myDomain,
						myOntology, myWriter);
			}
		}

		// -- Display all FunctionToDecimalBool
		if (!l_f2d_list.isEmpty()) {
			for (int i = 0; i < l_f2d_list.size(); i++) {
				FunctionToDecimalBool f2d = l_f2d_list.get(i);
				String f = f2d.getF1();
				String d = f2d.getD1();
				String expression = f2d.getExpression();
				writeFunctionToDecimalBool(f, d, expression, myDomain,
						myOntology, myWriter);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				writeFunctionOperation(l_function, l_expression, l_value,
						myDomain, myOntology, myWriter);
			}
		}

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				String predicate_s = l_predicate_list.get(k);
				if (k == l_predicate_list.size() - 1) {
					writeEffectPredicate(predicate_s, myOntology, myDomain,
							myWriter, true);
				} else
					writeEffectPredicate(predicate_s, myOntology, myDomain,
							myWriter, false);
			}
		}
	}

	/**
	 * @brief Read stored information on the domain and write it to a PDDL
	 *        domain file
	 * @param myOntology
	 * @param mySoap
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public void writeDomain(Ontology myOntology, Soap mySoap)
			throws FileNotFoundException, UnsupportedEncodingException {
		String outputFilePath = myOntology.getM_outputPDDLFile();
		PrintWriter myWriter = new PrintWriter(outputFilePath, "UTF-8");
		Domain myDomain = mySoap.getM_domain();

		myWriter.println("(define (domain "
				+ m_cleaner.cleanIRI(myDomain.getM_individual()) + ")");
		writeDomainRequirements(myDomain.getM_requirement_list(), myWriter);
		writeDomainVariables(myDomain.getM_variable_list(), myWriter);
		writeDomainPredicates(myDomain.getM_positive_predicate_list(),
				myOntology, myWriter);
		writeDomainFunctions(myDomain.getM_function_list(), myOntology,
				myWriter);
		writeDomainActions(myDomain, myDomain.getM_action_list(), myOntology,
				myWriter);
		myWriter.println(")");
		myWriter.close();
	}

	public void writeProblem(String problem, String problemFilePath)
			throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter myWriter = new PrintWriter(problemFilePath, "UTF-8");
		// System.out.println(problem);
		myWriter.println(problem);
		myWriter.close();
	}

}
