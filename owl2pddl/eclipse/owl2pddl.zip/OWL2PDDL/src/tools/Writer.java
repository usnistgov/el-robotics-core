/*****************************************************************************
   DISCLAIMER:
   This software was produced by the National Institute of Standards
   and Technology (NIST), an agency of the U.S. government, and by 
statute is
   not subject to copyright in the United States.  Recipients of this 
software
   assume all responsibility associated with its operation, modification,
   maintenance, and subsequent redistribution.

   See NIST Administration Manual 4.09.07 b and Appendix I.
 *****************************************************************************/
package tools;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.FunctionOperation;
import knowledge.FunctionToDecimalBool;
import knowledge.FunctionToFunctionBool;
import knowledge.NegativePredicate;
import knowledge.Ontology;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.Soap;
import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @brief Writes the PDDL domain and problem files
 * @author Zeid Kootbally \a zeid.kootbally\@nist.gov
 * @version 1.0
 * @date 26 Jan 2014
 * 
 * @details This class is used to write the domain and problem files.
 */
public class Writer {
	/**
	 * @brief instance of the class Cleaner.
	 * 
	 * This variable is used to clean the IRI of object and data properties
	 */
	private Cleaner m_cleaner;
	private PrintWriter m_writer;
	private Domain m_domain;
	private Ontology m_Ontology;

	/**
	 * @brief customized class constructor
	 * <ul>
	 * <li>initialize an instance of the class Cleaner
	 * </ul>
	 */
	public Writer() {
		m_cleaner = new Cleaner();
	}

	/**
	 * @brief Write the PDDL 'requirements' section
	 * @param myList
	 *            List of requirements for the current domain
	 */
	private void writeDomainRequirements(ArrayList<String> myList) {
		m_writer.print("	(:requirements ");
		for (int i = 0; i < myList.size(); i++) {
			if (i == myList.size() - 1)
				m_writer.print(":" + myList.get(i) + ")");
			else
				m_writer.print(":" + myList.get(i) + " ");
		}
	}

	/**
	 * @brief Write the PDDL 'types' section
	 * @param myList
	 *            List of types for the current domain
	 */
	private void writeDomainVariables(ArrayList<String> myList) {
		m_writer.println("\n	(:types ");
		for (int i = 0; i < myList.size(); i++) {
			if (i == myList.size() - 1)
				m_writer.println("		" + myList.get(i) + ")");
			else
				m_writer.println("		" + myList.get(i));
		}
	}

	/**
	 * @brief Writes the PDDL (:predicates...) section in the domain file
	 * <ul>
	 * <li>reads a list of predicates
	 * <li>for each predicate in the list
	 * <ul>
	 * <li>gets the name of the predicate: predicateName
	 * <li>gets the reference parameter: referenceParameter
	 * <li>gets the target parameter if it exists: targetParameter
	 * <li>writes (predicateName ?referenceParameter ?targetParameter)
	 * </ul>
	 * </ul>
	 * @param myList
	 *            List of predicates for the current domain
	 */
	private void writeDomainPredicates(ArrayList<PositivePredicate> myList	) {
		m_writer.println("	(:predicates");
		for (int i = 0; i < myList.size(); i++) {
			PositivePredicate positivePredicate = myList.get(i);

			if (!positivePredicate.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					m_writer.println("		"
							+ positivePredicate.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
									+ " ?"
									+ positivePredicate.getM_reference_parameter()
									.toLowerCase()
									+ " - "
									+ positivePredicate.getM_reference_parameter()
									+ " ?"
									+ positivePredicate.getM_target_parameter()
									.toLowerCase() + " - "
									+ positivePredicate.getM_target_parameter() + ")");
				} else {
					m_writer.println("		"
							+ positivePredicate.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
									+ " ?"
									+ positivePredicate.getM_reference_parameter()
									.toLowerCase()
									+ " - "
									+ positivePredicate.getM_reference_parameter()
									+ " ?"
									+ positivePredicate.getM_target_parameter()
									.toLowerCase() + " - "
									+ positivePredicate.getM_target_parameter() + ")\n");
				}
			} else {
				if (i == myList.size() - 1) {
					m_writer.println("		"
							+ positivePredicate.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
									+ " ?"
									+ positivePredicate.getM_reference_parameter()
									.toLowerCase() + " - "
									+ positivePredicate.getM_reference_parameter()
									+ ")");
				} else {
					m_writer.println("		"
							+ positivePredicate.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(positivePredicate
									.getM_individual())
									+ " ?"
									+ positivePredicate.getM_reference_parameter()
									.toLowerCase() + " - "
									+ positivePredicate.getM_reference_parameter()
									+ ")\n");
				}
			}
		}
		m_writer.println("	);End of the predicates section");
	}

	/**
	 * @brief Writes the PDDL '(:function ...)' section in the domain file
	 * <ul>
	 * <li>reads a list of functions
	 * <li>for each function in the list
	 * <ul>
	 * <li>gets the name of the function: functionName
	 * <li>gets the reference parameter if it exists: referenceParameter
	 * <li>gets the target parameter if it exists: targetParameter
	 * <li>writes (functionName ?referenceParameter ?targetParameter)
	 * </ul>
	 * </ul>
	 * @param myList
	 *            List of predicates for the current domain
	 */
	private void writeDomainFunctions(ArrayList<Function> myList) {
		m_writer.println("	(:functions");
		for (int i = 0; i < myList.size(); i++) {
			Function function = myList.get(i);

			if (!function.getM_reference_parameter().isEmpty()
					&& !function.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					m_writer.println("		" + function.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ " ?"
							+ function.getM_target_parameter().toLowerCase()
							+ " - " + function.getM_target_parameter() + ")");
				} else {
					m_writer.println("		" + function.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ " ?"
							+ function.getM_target_parameter().toLowerCase()
							+ " - " + function.getM_target_parameter() + ")\n");
				}
			} else if (!function.getM_reference_parameter().isEmpty()
					&& function.getM_target_parameter().isEmpty()) {
				if (i == myList.size() - 1) {
					m_writer.println("		" + function.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter() + ")");
				} else {
					m_writer.println("		" + function.getM_description());
					m_writer.println("		("
							+ m_cleaner.cleanIRI(function.getM_individual())
							+ " ?"
							+ function.getM_reference_parameter().toLowerCase()
							+ " - " + function.getM_reference_parameter()
							+ ")\n");
				}
			} else if (function.getM_reference_parameter().isEmpty()
					&& function.getM_target_parameter().isEmpty()) {
				m_writer.println("		" + function.getM_description());
				m_writer.println("		("
						+ m_cleaner.cleanIRI(function.getM_individual())
						+ ")\n");
			}
		}
		m_writer.println("	);End of the functions section\n");
	}
	/**
	 * @brief Writes PDDL actions '(:action ...)' in the domain file
	 * <ul>
	 * <li>reads a list of actions: myList
	 * <li>for each action in the list
	 * <ul>
	 * <li>gets the parameters
	 * <ul>
	 * <li>For each parameter
	 * <ul>
	 * <li>writes ?type - Type (type is a lower case string of Type)
	 * </ul> 
	 * </ul>
	 * <li>writes the preconditions with writeActionPrecondition
	 * <li>writes the effects with writeActionEffect
	 * </ul>
	 * </ul>
	 * @param myList
	 *            List of actions for the current domain
	 */
	private void writeDomainActions(ArrayList<Action> myList) {

		for (int i = 0; i < myList.size(); i++) {
			Action action = myList.get(i);
			m_writer.println("	(:action "
					+ m_cleaner.cleanIRI(action.getM_individual()));
			m_writer.println("		:parameters(");
			ArrayList<String> parameter_set_list = action.getM_parameter_set();

			for (int j = 0; j < parameter_set_list.size(); j++) {
				if (j == parameter_set_list.size() - 1) {
					m_writer.println("			?"
							+ parameter_set_list.get(j).toLowerCase() + " - "
							+ parameter_set_list.get(j) + ")");
				} else {
					m_writer.println("			?"
							+ parameter_set_list.get(j).toLowerCase() + " - "
							+ parameter_set_list.get(j));
				}
			}
			writeActionPrecondition(action.getM_action_precondition());
			writeActionEffect(action.getM_action_effect());
			// displayEffect(action.getM_action_effect(), myOntology);
			m_writer.println("	)");
		}

	}
	/**
	 * @brief Finds and returns the positive predicate given a negative predicate
	 * @param myNegativePredicate A negative predicate
	 * @return The positive predicate given a negative predicate
	 */
	private PositivePredicate lookForPositivePredicate(
			NegativePredicate myNegativePredicate) {
		ArrayList<PositivePredicate> positive_predicate_list = m_domain
				.getM_positive_predicate_list();
		PositivePredicate positive_predicate = new PositivePredicate();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);
			OWLIndividual positive_predicate_for_negative_predicate = myNegativePredicate
					.getM_positive_predicate();
			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (m_cleaner.cleanIRI(positive_predicate_for_negative_predicate)
					.compareTo(m_cleaner.cleanIRI(tmp_predicate.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
			}
		}
		return positive_predicate;
	}
	/**
	 * @brief Writes a negative predicate when encountered in a precondition or effect
	 * @param myPredicate A negative predicate
	 * @param end Boolean value informing if this negative predicate is the last one in the precondition or
	 * effect
	 */
	private void writeNegativePredicate(PositivePredicate myPredicate,Boolean end) {
		if (end) {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				m_writer.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ ")))");
			} else {
				m_writer.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ ")))");

			}
		} else {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				m_writer.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ "))");
			} else {
				m_writer.println("			(not("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ "))");

			}
		}
	}
	/**
	 * @brief Writes a positive predicate when encountered in a precondition or effect
	 * @param myPredicate A positive predicate
	 * @param end Boolean value informing if this negative predicate is the last one in the precondition or
	 * effect
	 */
	private void writePositivePredicate(PositivePredicate myPredicate,Boolean end) {

		if (end) {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				m_writer.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ "))");
			} else {
				m_writer.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ "))");

			}
		} else {
			if (!myPredicate.getM_target_parameter().isEmpty()) {
				m_writer.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ " ?"
						+ myPredicate.getM_target_parameter().toLowerCase()
						+ ")");
			} else {
				m_writer.println("			("
						+ m_cleaner.cleanIRI(myPredicate.getM_individual())
						+ " ?"
						+ myPredicate.getM_reference_parameter().toLowerCase()
						+ ")");

			}
		}
	}

	/**
	 * @brief writes a predicate in the precondition section of an action
	 * @param myPredicate Predicate to write in the precondition section
	 * @param end
	 *            Boolean value telling if this is the last predicate to write
	 *            in the precondition, in that case, we add a closing
	 *            parenthesis ')'
	 */
	private void writePreconditionPredicate(String myPredicate,Boolean end) {
		PositivePredicate positive_predicate = new PositivePredicate();

		// -- Check the list of negative predicates
		ArrayList<NegativePredicate> negative_predicate_list = m_domain
				.getM_negative_predicate_list();
		for (int i = 0; i < negative_predicate_list.size(); i++) {

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate
					.compareTo(m_cleaner.cleanIRI(negative_predicate_list.get(
							i).getM_individual())) == 0) {
				positive_predicate = lookForPositivePredicate(negative_predicate_list.get(i));
				writeNegativePredicate(positive_predicate, end);
			}
		}
		// -- Check the list of positive predicates
		ArrayList<PositivePredicate> positive_predicate_list = m_domain
				.getM_positive_predicate_list();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate.compareTo(m_cleaner.cleanIRI(tmp_predicate
					.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
				writePositivePredicate(positive_predicate,end);
			}
		}
	}
	/**
	 * @brief writes a predicate in the effect section of an action
	 * @param myPredicate Predicate to write in the precondition section
	 * @param end
	 *            Boolean value telling if this is the last predicate to write
	 *            in the precondition, in that case, we add a closing
	 *            parenthesis ')'
	 */
	private void writeEffectPredicate(String myPredicate, Boolean end) {
		PositivePredicate positive_predicate = new PositivePredicate();

		// -- Check the list of negative predicates
		ArrayList<NegativePredicate> negative_predicate_list = m_domain
				.getM_negative_predicate_list();
		for (int i = 0; i < negative_predicate_list.size(); i++) {

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate
					.compareTo(m_cleaner.cleanIRI(negative_predicate_list.get(
							i).getM_individual())) == 0) {
				positive_predicate = lookForPositivePredicate(
						negative_predicate_list.get(i));
				writeNegativePredicate(positive_predicate,end);
			}
		}
		// -- Check the list of positive predicates
		ArrayList<PositivePredicate> positive_predicate_list = m_domain
				.getM_positive_predicate_list();
		for (int i = 0; i < positive_predicate_list.size(); i++) {
			PositivePredicate tmp_predicate = positive_predicate_list.get(i);

			// --check myPredicate against predicate's name, i.e., predicate's
			// m_individual
			if (myPredicate.compareTo(m_cleaner.cleanIRI(tmp_predicate
					.getM_individual())) == 0) {
				positive_predicate = tmp_predicate;
				writePositivePredicate(positive_predicate, end);
			}
		}
	}
	/**
	 * @brief writes a FunctionToFunctionBool type
	 * 
	 * A FunctionToFunctionBool type has the following structure: (expression (function1 function2))
	 * @param myF1 The first function
	 * @param myF2 The second function
	 * @param myExpression The expression for the FunctionToFunctionBool 
	 */
	private void writeFunctionToFunctionBool(String myF1, String myF2, String myExpression) {
		Function f1 = lookForFunction(myF1);
		Function f2 = lookForFunction(myF2);

		// -- Write the opening parenthesis
		m_writer.print("			(");
		// -- Write the expression
		m_writer.print(myExpression);
		// -- Write f1
		m_writer.print(buildFunctionStructure(f1));
		// -- Write f2
		m_writer.print(buildFunctionStructure(f2));
		// -- Write closing parenthesis
		m_writer.print(")\n");

	}
	/**
	 * @brief writes a FunctionToDecimalnBool type
	 * 
	 * A FunctionToDecimalBool type has the following structure: (expression (function decimal))
	 * @param myF1 The function
	 * @param d A decimal value
	 * @param myExpression The expression for the FunctionToDecimalBool 
	 */
	private void writeFunctionToDecimalBool(String myF1, String d, String myExpression) {
		Function f1 = lookForFunction(myF1);

		// -- Write the opening parenthesis
		m_writer.print("			(");
		// -- Write the expression
		m_writer.print(myExpression);
		// -- Write f1
		m_writer.print(buildFunctionStructure(f1));
		// -- Write f2
		m_writer.print(d);
		// -- Write closing parenthesis
		m_writer.print(")\n");
	}
	/**
	 * @brief Returns a Function type given the name of the function as a string
	 * @param myFunction The function string used to find the Function type
	 * @return a Function type
	 */
	private Function lookForFunction(String myFunction) {
		ArrayList<Function> function_list = m_domain.getM_function_list();
		Function function = new Function();
		for (int i = 0; i < function_list.size(); i++) {
			Function tmp_function = function_list.get(i);

			if (m_cleaner.cleanIRI(tmp_function.getM_individual()).compareTo(
					myFunction) == 0) {
				function = tmp_function;
			}
		}
		return function;
	}

	/**
	 * @brief build the structure of a function based on its parameters. 
	 * 
	 * PDDL functions may have 0, 1 (reference), or 2 (reference and target) parameters. 
	 * Based on the number of parameters, this function build PDDL functions accordingly. 
	 * 
	 * An instance of a PDDL function with 0 parameter is (part-found-flag)<br>
	 * An instance of a PDDL function with 1 parameter is (final-quantity-of-parts-in-kit ?kit)<br> 
	 * An instance of a PDDL function with 2 parameters is (quantity-of-parts-in-kit ?stockkeepingunit ?kit)
	 * @param function The function to build
	 * @return The function built
	 */
	private String buildFunctionStructure(Function function) {
		String functionOutput_s = "";
		boolean refParam_bool = true;
		boolean targetParam_bool = true;

		if (function.getM_reference_parameter().isEmpty()) {
			refParam_bool = false;
			targetParam_bool = false;
		}

		if (function.getM_target_parameter().isEmpty()) {
			targetParam_bool = false;
		}

		if (refParam_bool && targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + " ?"
					+ function.getM_reference_parameter().toLowerCase() + " ?"
					+ function.getM_target_parameter().toLowerCase() + ") ";
		} else if (refParam_bool && !targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + " ?"
					+ function.getM_reference_parameter().toLowerCase() + ") ";
		} else if (!refParam_bool && !targetParam_bool) {
			functionOutput_s += " ("
					+ m_cleaner.cleanIRI(function.getM_individual()) + ") ";
		}

		return functionOutput_s;
	}
	/**
	 * @brief writes a FunctionOperation type
	 * 
	 * A FunctionOperation type has the following structure: (expression (function value))
	 * @param myFunction The function
	 * @param myExpression The expression
	 * @param myValue The value
	 */
	private void writeFunctionOperation(String myFunction, String myExpression,
			Integer myValue) {
		Function function = lookForFunction(myFunction);

		// -- Write the expression
		m_writer.print("			(" + myExpression);
		// -- Write the function
		m_writer.print(buildFunctionStructure(function));
		// -- Write the value
		m_writer.println(+myValue + ")");
	}
	/**
	 * @brief writes the precondition section of an action
	 * 
	 * This functions writes FunctionToFunctionBool, FunctionToDecimalBool, FunctionOperation, and predicates
	 * for the precondition @a myPrecondition
	 * @param myPrecondition The precondition to write
	 */
	private void writeActionPrecondition(Precondition myPrecondition) {
		// System.out.println("\n +precondition: "+myOntology.cleanIRI(myPrecondition.getM_individual()));
		ArrayList<String> l_predicate_list = myPrecondition
				.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myPrecondition
				.getM_f2f_list();
		ArrayList<FunctionToDecimalBool> l_f2d_list = myPrecondition
				.getM_f2d_list();
		ArrayList<FunctionOperation> l_function_operation_list = myPrecondition
				.getM_function_operation_list();

		if (l_predicate_list.size() > 1 || l_f2f_list.size() > 1
				|| l_function_operation_list.size() > 1)
			m_writer.println("		:precondition(and");
		else
			m_writer.println("		:precondition(");

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				writeFunctionToFunctionBool(f1, f2, expression);
			}
		}

		// -- Display all FunctionToDecimalBool
		if (!l_f2d_list.isEmpty()) {
			for (int i = 0; i < l_f2d_list.size(); i++) {
				FunctionToDecimalBool f2d = l_f2d_list.get(i);
				String f = f2d.getF1();
				String d = f2d.getD1();
				String expression = f2d.getExpression();
				writeFunctionToDecimalBool(f, d, expression);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				writeFunctionOperation(l_function, l_expression, l_value);
			}
		}

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				String predicate_s = l_predicate_list.get(k);
				if (k == l_predicate_list.size() - 1) {
					writePreconditionPredicate(predicate_s, true);
				} else
					writePreconditionPredicate(predicate_s, false);
			}
		}
	}
	/**
	 * @brief writes the effect section of an action
	 * 
	 * This functions writes FunctionToFunctionBool, FunctionToDecimalBool, FunctionOperation, and predicates
	 * for the effect @a myEffect
	 * @param myEffect The effect to write
	 */
	private void writeActionEffect(Effect myEffect) {
		// System.out.println("\n +effect: "+myOntology.cleanIRI(myEffect.getM_individual()));
		ArrayList<String> l_predicate_list = myEffect.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myEffect.getM_f2f_list();
		ArrayList<FunctionToDecimalBool> l_f2d_list = myEffect.getM_f2d_list();
		ArrayList<FunctionOperation> l_function_operation_list = myEffect
				.getM_function_operation_list();
		m_writer.println("		:effect(and");

		// -- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()) {
			for (int i = 0; i < l_f2f_list.size(); i++) {
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				writeFunctionToFunctionBool(f1, f2, expression);
			}
		}

		// -- Display all FunctionToDecimalBool
		if (!l_f2d_list.isEmpty()) {
			for (int i = 0; i < l_f2d_list.size(); i++) {
				FunctionToDecimalBool f2d = l_f2d_list.get(i);
				String f = f2d.getF1();
				String d = f2d.getD1();
				String expression = f2d.getExpression();
				writeFunctionToDecimalBool(f, d, expression);
			}
		}

		// -- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()) {
			for (int i = 0; i < l_function_operation_list.size(); i++) {
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				writeFunctionOperation(l_function, l_expression, l_value);
			}
		}

		// -- Display all the predicates
		if (!l_predicate_list.isEmpty()) {
			for (int k = 0; k < l_predicate_list.size(); k++) {
				String predicate_s = l_predicate_list.get(k);
				if (k == l_predicate_list.size() - 1) {
					writeEffectPredicate(predicate_s, true);
				} else
					writeEffectPredicate(predicate_s, false);
			}
		}
	}

	/**
	 * @brief Reads stored information on the domain and writes it to the PDDL
	 *        domain file
	 * @param myOntology
	 * @param mySoap
	 * @throws FileNotFoundException
	 * @throws UnsupportedEncodingException
	 */
	public void writeDomainFile(Ontology myOntology, Soap mySoap)
			throws FileNotFoundException, UnsupportedEncodingException {
		String outputFilePath = myOntology.getM_outputPDDLFile();
		PrintWriter myWriter = new PrintWriter(outputFilePath, "UTF-8");
		setM_writer(myWriter);
		Domain myDomain = mySoap.getM_domain();
		setM_domain(myDomain);
		setM_Ontology(myOntology);

		m_writer.println("(define (domain "
				+ m_cleaner.cleanIRI(myDomain.getM_individual()) + ")");
		writeDomainRequirements(myDomain.getM_requirement_list());
		writeDomainVariables(myDomain.getM_variable_list());
		writeDomainPredicates(myDomain.getM_positive_predicate_list());
		writeDomainFunctions(myDomain.getM_function_list());
		writeDomainActions(myDomain.getM_action_list());
		m_writer.println(")");
		m_writer.close();

		File file = new File(outputFilePath); 
		boolean empty = file.length() == 0;
		if (!empty)
			System.out.println("---------------------------------------------------------------------\n"+
					"             Domain file successfully generated                     \n" +
					"---------------------------------------------------------------------");
		else
			System.out.println("---------------------------------------------------------------------\n"+
					"           ERROR generating the domain file...exiting                 \n" +
					"---------------------------------------------------------------------");
	}
	/**
	 * @brief Writes the PDDL problem file
	 * @param problem String that contains the whole problem file to write
	 * @param problemFilePath File used to write the problem file
	 */
	public void writeProblemFile(String problem, String problemFilePath)
			throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter myWriter = new PrintWriter(problemFilePath, "UTF-8");
		setM_writer(myWriter);
		// System.out.println(problem);
		m_writer.println(problem);
		m_writer.close();
		//-- check that the problem file exists and is not empty
		File file = new File(problemFilePath); 
		boolean empty = file.length() == 0;
		if (!empty)
			System.out.println("---------------------------------------------------------------------\n"+
					"             Problem file successfully generated                     \n" +
					"---------------------------------------------------------------------");
		else
			System.out.println("---------------------------------------------------------------------\n"+
					"               ERROR generating the problem file...exiting           \n" +
					"---------------------------------------------------------------------");

	}

	/**
	 * @return the m_writer
	 */
	public PrintWriter getM_writer() {
		return m_writer;
	}

	/**
	 * @param m_writer the m_writer to set
	 */
	public void setM_writer(PrintWriter m_writer) {
		this.m_writer = m_writer;
	}

	/**
	 * @return the m_domain
	 */
	public Domain getM_domain() {
		return m_domain;
	}

	/**
	 * @param m_domain the m_domain to set
	 */
	public void setM_domain(Domain m_domain) {
		this.m_domain = m_domain;
	}

	/**
	 * @return the m_Ontology
	 */
	public Ontology getM_Ontology() {
		return m_Ontology;
	}

	/**
	 * @param m_Ontology the m_Ontology to set
	 */
	public void setM_Ontology(Ontology m_Ontology) {
		this.m_Ontology = m_Ontology;
	}

}
