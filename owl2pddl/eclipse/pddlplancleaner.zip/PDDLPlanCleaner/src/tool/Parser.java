/**
 * 
 */
package tool;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author zeid
 *
 */
public class Parser {

	private String m_filePath;
	private String m_outputPddlString;
	
	private String m_inputPddlPlanPath = "";
	private String m_outputPddlPlanPath = "";
	/**
	 * 
	 */
	public Parser() {
		// TODO Auto-generated constructor stub
	}
	
	
	public void parseKittingConfig(){
		String filePath = new File("").getAbsolutePath();
		String configFilePath = getM_filePath();
		File file = new File(filePath.concat("/" + configFilePath));
		
		try {
			Scanner scanner = new Scanner(file);

			// now read the file line by line...
			int lineNum = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				lineNum++;
				// -- Look for PDDL_Input
				if (line.contains("PDDL_Input") && !line.contains("#")) {

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String inputPddlPlanPath = line.substring(colonPosition + 1,
							closingBracketPosition).replaceAll("\\s+", "");
					setM_inputPddlPlanPath(inputPddlPlanPath);
					// System.out.println("SOAP_Instance: " +soapInstancePath);
				}
				// -- Look for PDDL_Output
				else if (line.contains("PDDL_Output") && !line.contains("#")) {

					int colonPosition = line.indexOf(":");
					int closingBracketPosition = line.indexOf("]");
					String outputPddlPlanPath = line.substring(colonPosition + 1,
							closingBracketPosition).replaceAll("\\s+", "");
					setM_outputPddlPlanPath(outputPddlPlanPath);
					// System.out.println("INIT_Instance: " +initInstancePath);
				}
			}
		} catch (FileNotFoundException e) {
			// handle this
		}
		// -- Check that the results are not empty
				checkParsedResult();
	}
	
	public void parsePddlInputFile(String myPath){
		String filePath = new File("").getAbsolutePath();
		File file = new File(filePath.concat("/" +  myPath));
		String cleanedFile="";
		try {
			Scanner scanner = new Scanner(file);
			// now read the file line by line...
			int lineNum = 0;
			while (scanner.hasNextLine()) {
				String line = scanner.nextLine();
				lineNum++;
				// -- If the line contains the ';' character then delete the line
				if (line.contains(";")) {
					//System.out.println("line with ; "+line);
					line=line.replaceAll("(?m)^;.*", "");
					//System.out.println("line cleaned "+line);
				}
				else if (line.contains(":") && !line.contains(";")){
					//System.out.println("line with : "+line);
					int openingParenthesisPosition = line.indexOf(":");
					int closingParenthesisPosition = line.indexOf(")")+1;
					String cleanedLine = line.substring(openingParenthesisPosition+1,
							closingParenthesisPosition);
					cleanedFile = cleanedFile+cleanedLine+"\n";
					//System.out.println("line cleaned "+cleanedLine);
				}
			}
		} catch (FileNotFoundException e) {
			// handle this
		}
		//System.out.println("Final file\n"+cleanedFile);
		setM_outputPddlString(cleanedFile);
	}
	private void checkParsedResult() {
		String l_inputPddlPlanPath = getM_inputPddlPlanPath();
		if (l_inputPddlPlanPath.isEmpty()) {
			System.out
					.println("ERROR: Path not set for PDDL_Input...exiting");
			System.exit(0);
		}
		String l_outputPddlPlanPath = getM_outputPddlPlanPath();
		if (l_outputPddlPlanPath.isEmpty()) {
			System.out
					.println("ERROR: Path not set for PDDL_Output...exiting");
			System.exit(0);
		}
	}
	/**
	 * @return the m_filePath
	 */
	public String getM_filePath() {
		return m_filePath;
	}
	/**
	 * @param m_filePath the m_filePath to set
	 */
	public void setM_filePath(String m_filePath) {
		this.m_filePath = m_filePath;
	}

	/**
	 * @return the m_inputPddlPlanPath
	 */
	public String getM_inputPddlPlanPath() {
		return m_inputPddlPlanPath;
	}


	/**
	 * @param m_inputPddlPlanPath the m_inputPddlPlanPath to set
	 */
	public void setM_inputPddlPlanPath(String m_inputPddlPlanPath) {
		this.m_inputPddlPlanPath = m_inputPddlPlanPath;
	}


	/**
	 * @return the m_outputPddlPlanPath
	 */
	public String getM_outputPddlPlanPath() {
		return m_outputPddlPlanPath;
	}


	/**
	 * @param m_outputPddlPlanPath the m_outputPddlPlanPath to set
	 */
	public void setM_outputPddlPlanPath(String m_outputPddlPlanPath) {
		this.m_outputPddlPlanPath = m_outputPddlPlanPath;
	}


	/**
	 * @return the m_outputPddlString
	 */
	public String getM_outputPddlString() {
		return m_outputPddlString;
	}


	/**
	 * @param m_outputPddlString the m_outputPddlString to set
	 */
	public void setM_outputPddlString(String m_outputPddlString) {
		this.m_outputPddlString = m_outputPddlString;
	}

}
