/**
 * 
 */
package tool;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * @author zeid
 *
 */
public class Writer {

	/**
	 * 
	 */
	public Writer() {
		// TODO Auto-generated constructor stub
	}

	public void writeCleanPddlPlan(String myPddlPlanString, String myPddlPlanOutFile)
			throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter myWriter = new PrintWriter(myPddlPlanOutFile, "UTF-8");
		// System.out.println(problem);
		myWriter.println(myPddlPlanString);
		myWriter.close();
	}
	
}
