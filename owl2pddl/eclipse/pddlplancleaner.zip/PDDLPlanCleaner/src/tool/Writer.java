/**
 * 
 */
package tool;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * @author zeid
 *
 */
public class Writer {

	/**
	 * 
	 */
	public Writer() {
		// TODO Auto-generated constructor stub
	}

	public void writeCleanPddlPlan(String myPddlPlanString, String myPddlPlanOutFile)
			throws FileNotFoundException, UnsupportedEncodingException {
		PrintWriter myWriter = new PrintWriter(myPddlPlanOutFile, "UTF-8");
		// System.out.println(problem);
		myWriter.println(myPddlPlanString);
		myWriter.close();
		
		File file = new File(myPddlPlanOutFile); 
		boolean empty = file.length() == 0;
		if (!empty)
			System.out.println("---------------------------------------------------------------------\n"+
							   "             PDDL plan file successfully cleaned                     \n" +
							   "---------------------------------------------------------------------");
		else
			System.out.println("---------------------------------------------------------------------\n"+
					   		   "               ERROR cleaning the PDDL plan file...exiting           \n" +
					           "---------------------------------------------------------------------");
	}
	
}
