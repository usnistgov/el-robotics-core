var searchData=
[
  ['cleaniri',['cleanIRI',['../classknowledge_1_1_ontology.html#a8c58c73c103da367df35db867a78fec3',1,'knowledge::Ontology']]],
  ['cleaniridataproperty',['cleanIRIDataProperty',['../classknowledge_1_1_ontology.html#a48f190435d72c09270f830ed540f94bf',1,'knowledge::Ontology']]]
];
