var searchData=
[
  ['ontology',['Ontology',['../classknowledge_1_1_ontology.html',1,'knowledge']]],
  ['ontology',['Ontology',['../classknowledge_1_1_ontology.html#a77ade614099bb3844bef894a5bc0a3b7',1,'knowledge::Ontology']]],
  ['ontology_2ejava',['Ontology.java',['../_ontology_8java.html',1,'']]]
];
