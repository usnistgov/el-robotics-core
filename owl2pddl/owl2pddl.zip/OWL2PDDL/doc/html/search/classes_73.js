var searchData=
[
  ['soap',['Soap',['../classknowledge_1_1_soap.html',1,'knowledge']]]
];
