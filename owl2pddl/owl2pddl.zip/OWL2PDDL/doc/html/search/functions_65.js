var searchData=
[
  ['effect',['Effect',['../classknowledge_1_1_effect.html#a5839ee7fbc0c860f8fa0eb31ccb4503b',1,'knowledge::Effect']]]
];
