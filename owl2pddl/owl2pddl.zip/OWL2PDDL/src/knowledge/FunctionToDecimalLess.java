/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToDecimalLess extends FunctionToDecimalBool {

	/**
	 * 
	 */
	public FunctionToDecimalLess() {
		// TODO Auto-generated constructor stub
	}

}
