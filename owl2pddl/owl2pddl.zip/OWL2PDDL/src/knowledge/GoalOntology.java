/**
 * 
 */
package knowledge;

import java.io.File;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

/**
 * @author zeid
 *
 */
public class GoalOntology extends Ontology {
	private static OWLReasoner m_goalOWLReasoner;
	/**
	 * @brief Path to owl goal instance file
	 */
	private static String m_PathToGoalInstanceFile;


	/**
	 * @brief OWLOntology for the goal instance file
	 */
	private static OWLOntology m_OWLGoalInstanceOntology;

	/**
	 * @brief IRI for goal.owl
	 */
	private static String m_goal_IRI="http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";

	/**
	 * 
	 */
	public GoalOntology() {
		// TODO Auto-generated constructor stub
		setM_goal_IRI(m_goal_IRI);

	}

	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		setM_goalOWLReasoner(reasonerFactory.createReasoner(m_OWLGoalInstanceOntology));
	}

	public void loadOntologyFromPath(String myPath)
			throws MalformedURLException, OWLException {
		String filePath = new File("").getAbsolutePath();
		//System.out.println("filepath: "+filePath);
		//String l_OWLOntologyPath=getM_PathToSoapInstanceFile();
		File file = new File(filePath.concat("/"+myPath));

		//-- Set the owl file passed as arguments as the current ontology
		setM_OWLGoalInstanceOntology(getM_OWLOntologyManager().loadOntologyFromOntologyDocument(file));
	}

	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_goal_IRI().concat(myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//progressMonitor);
		return myClass;
	}

	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = getM_OWLOntologyManager().getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(getM_goal_IRI().concat(":" + myClassName)));

		//ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		//OWLReasonerConfiguration config = new SimpleConfiguration(
		//		progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = getM_goalOWLReasoner().getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}

	/**
	 * @return the m_PathToGoalInstanceFile
	 */
	public static String getM_PathToGoalInstanceFile() {
		return m_PathToGoalInstanceFile;
	}
	/**
	 * @param m_PathToGoalInstanceFile the m_PathToGoalInstanceFile to set
	 */
	public void setM_PathToGoalInstanceFile(
			String m_PathToGoalInstanceFile) {
		GoalOntology.m_PathToGoalInstanceFile = m_PathToGoalInstanceFile;
	}
	/**
	 * @return the m_OWLGoalInstanceOntology
	 */
	public OWLOntology getM_OWLGoalInstanceOntology() {
		return m_OWLGoalInstanceOntology;
	}
	/**
	 * @param m_OWLGoalInstanceOntology the m_OWLGoalInstanceOntology to set
	 */
	public static void setM_OWLGoalInstanceOntology(
			OWLOntology m_OWLGoalInstanceOntology) {
		GoalOntology.m_OWLGoalInstanceOntology = m_OWLGoalInstanceOntology;
	}
	/**
	 * @return the m_goal_IRI
	 */
	public String getM_goal_IRI() {
		return m_goal_IRI;
	}
	/**
	 * @param m_goal_IRI the m_goal_IRI to set
	 */
	public static void setM_goal_IRI(String m_goal_IRI) {
		GoalOntology.m_goal_IRI = m_goal_IRI;
	}

	/**
	 * @return the m_goalOWLReasoner
	 */
	public OWLReasoner getM_goalOWLReasoner() {
		return m_goalOWLReasoner;
	}

	/**
	 * @param m_goalOWLReasoner the m_goalOWLReasoner to set
	 */
	public static void setM_goalOWLReasoner(OWLReasoner m_goalOWLReasoner) {
		GoalOntology.m_goalOWLReasoner = m_goalOWLReasoner;
	}

}
