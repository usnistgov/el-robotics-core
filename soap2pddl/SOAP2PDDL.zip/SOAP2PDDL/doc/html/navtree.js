var NAVTREE =
[
  [ "Intention Recognition", "index.html", [
    [ "Intention Recognition", "index.html", null ],
    [ "Modules", "modules.html", [
      [ "Graphical User Interface", "group___g_u_i.html", null ],
      [ "Intention Structure", "group__intention.html", null ]
    ] ],
    [ "Class List", "annotated.html", [
      [ "orderingconstruct.AnyOrder", "classorderingconstruct_1_1_any_order.html", null ],
      [ "gui.Chart", "classgui_1_1_chart.html", null ],
      [ "treecheckbox.CheckTreeCellRenderer", "classtreecheckbox_1_1_check_tree_cell_renderer.html", null ],
      [ "treecheckbox.CheckTreeManager", "classtreecheckbox_1_1_check_tree_manager.html", null ],
      [ "treecheckbox.CheckTreeSelectionModel", "classtreecheckbox_1_1_check_tree_selection_model.html", null ],
      [ "gui.CommonGUIComponents", "classgui_1_1_common_g_u_i_components.html", null ],
      [ "tools.Configuration", "classtools_1_1_configuration.html", null ],
      [ "orderingconstruct.Count", "classorderingconstruct_1_1_count.html", null ],
      [ "gui.Chart.CustomRenderer", "classgui_1_1_chart_1_1_custom_renderer.html", null ],
      [ "gui.Chart.CustomRendererLine", "classgui_1_1_chart_1_1_custom_renderer_line.html", null ],
      [ "gui.DemoPanel", "classgui_1_1_demo_panel.html", null ],
      [ "gui.MainFrame.DisplayMetrics", "classgui_1_1_main_frame_1_1_display_metrics.html", null ],
      [ "DocumentFilter", "class_document_filter.html", null ],
      [ "gui.DrawStringPanel", "classgui_1_1_draw_string_panel.html", null ],
      [ "orderingconstruct.Exist", "classorderingconstruct_1_1_exist.html", null ],
      [ "tools.FileOperator", "classtools_1_1_file_operator.html", null ],
      [ "intention.Intention", "classintention_1_1_intention.html", null ],
      [ "tools.IntFilter", "classtools_1_1_int_filter.html", null ],
      [ "main.Launcher", "classmain_1_1_launcher.html", null ],
      [ "gui.MainFrame", "classgui_1_1_main_frame.html", null ],
      [ "intention.Metric", "classintention_1_1_metric.html", null ],
      [ "gui.OptionFrame.MouseHandler", "classgui_1_1_option_frame_1_1_mouse_handler.html", null ],
      [ "Ontology", "class_ontology.html", null ],
      [ "ontology.Ontology", "classontology_1_1_ontology.html", null ],
      [ "gui.OntologyChooser", "classgui_1_1_ontology_chooser.html", null ],
      [ "gui.OptionFrame", "classgui_1_1_option_frame.html", null ],
      [ "orderingconstruct.OrderedList", "classorderingconstruct_1_1_ordered_list.html", null ],
      [ "gui.PDFChartTransferable", "classgui_1_1_p_d_f_chart_transferable.html", null ],
      [ "gui.OptionFrame.PlanComboBoxListener", "classgui_1_1_option_frame_1_1_plan_combo_box_listener.html", null ],
      [ "predicate.Predicate", "classpredicate_1_1_predicate.html", null ],
      [ "gui.ProgressBar", "classgui_1_1_progress_bar.html", null ],
      [ "treecheckbox.TreeExample", "classtreecheckbox_1_1_tree_example.html", null ],
      [ "treecheckbox.TristateCheckBox", "classtreecheckbox_1_1_tristate_check_box.html", null ],
      [ "treecheckbox.TristateCheckBox.TristateDecorator", "classtreecheckbox_1_1_tristate_check_box_1_1_tristate_decorator.html", null ]
    ] ],
    [ "Class Index", "classes.html", null ],
    [ "Class Members", "functions.html", null ],
    [ "Packages", "namespaces.html", [
      [ "gui", "namespacegui.html", null ],
      [ "intention", "namespaceintention.html", null ],
      [ "main", "namespacemain.html", null ],
      [ "ontology", "namespaceontology.html", null ],
      [ "orderingconstruct", "namespaceorderingconstruct.html", null ],
      [ "predicate", "namespacepredicate.html", null ],
      [ "tools", "namespacetools.html", null ],
      [ "treecheckbox", "namespacetreecheckbox.html", null ]
    ] ],
    [ "File List", "files.html", [
      [ "src/gui/Chart.java", "_chart_8java.html", null ],
      [ "src/gui/CommonGUIComponents.java", "_common_g_u_i_components_8java.html", null ],
      [ "src/gui/DemoPanel.java", "_demo_panel_8java.html", null ],
      [ "src/gui/DrawStringPanel.java", "_draw_string_panel_8java.html", null ],
      [ "src/gui/MainFrame.java", "_main_frame_8java.html", null ],
      [ "src/gui/OntologyChooser.java", "_ontology_chooser_8java.html", null ],
      [ "src/gui/OptionFrame.java", "_option_frame_8java.html", null ],
      [ "src/gui/PDFChartTransferable.java", "_p_d_f_chart_transferable_8java.html", null ],
      [ "src/gui/ProgressBar.java", "_progress_bar_8java.html", null ],
      [ "src/intention/Intention.java", "_intention_8java.html", null ],
      [ "src/intention/Metric.java", "_metric_8java.html", null ],
      [ "src/main/Launcher.java", "_launcher_8java.html", null ],
      [ "src/ontology/Ontology.java", "_ontology_8java.html", null ],
      [ "src/orderingconstruct/AnyOrder.java", "_any_order_8java.html", null ],
      [ "src/orderingconstruct/Count.java", "_count_8java.html", null ],
      [ "src/orderingconstruct/Exist.java", "_exist_8java.html", null ],
      [ "src/orderingconstruct/OrderedList.java", "_ordered_list_8java.html", null ],
      [ "src/orderingconstruct/package-info.java", "orderingconstruct_2package-info_8java.html", null ],
      [ "src/predicate/Predicate.java", "_predicate_8java.html", null ],
      [ "src/tools/Configuration.java", "_configuration_8java.html", null ],
      [ "src/tools/FileOperator.java", "_file_operator_8java.html", null ],
      [ "src/tools/IntFilter.java", "_int_filter_8java.html", null ],
      [ "src/tools/package-info.java", "tools_2package-info_8java.html", null ],
      [ "src/treecheckbox/CheckTreeCellRenderer.java", "_check_tree_cell_renderer_8java.html", null ],
      [ "src/treecheckbox/CheckTreeManager.java", "_check_tree_manager_8java.html", null ],
      [ "src/treecheckbox/CheckTreeSelectionModel.java", "_check_tree_selection_model_8java.html", null ],
      [ "src/treecheckbox/package-info.java", "treecheckbox_2package-info_8java.html", null ],
      [ "src/treecheckbox/TreeExample.java", "_tree_example_8java.html", null ],
      [ "src/treecheckbox/TristateCheckBox.java", "_tristate_check_box_8java.html", null ]
    ] ]
  ] ]
];

function createIndent(o,domNode,node,level)
{
  if (node.parentNode && node.parentNode.parentNode)
  {
    createIndent(o,domNode,node.parentNode,level+1);
  }
  var imgNode = document.createElement("img");
  if (level==0 && node.childrenData)
  {
    node.plus_img = imgNode;
    node.expandToggle = document.createElement("a");
    node.expandToggle.href = "javascript:void(0)";
    node.expandToggle.onclick = function() 
    {
      if (node.expanded) 
      {
        $(node.getChildrenUL()).slideUp("fast");
        if (node.isLast)
        {
          node.plus_img.src = node.relpath+"ftv2plastnode.png";
        }
        else
        {
          node.plus_img.src = node.relpath+"ftv2pnode.png";
        }
        node.expanded = false;
      } 
      else 
      {
        expandNode(o, node, false);
      }
    }
    node.expandToggle.appendChild(imgNode);
    domNode.appendChild(node.expandToggle);
  }
  else
  {
    domNode.appendChild(imgNode);
  }
  if (level==0)
  {
    if (node.isLast)
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2plastnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2lastnode.png";
        domNode.appendChild(imgNode);
      }
    }
    else
    {
      if (node.childrenData)
      {
        imgNode.src = node.relpath+"ftv2pnode.png";
      }
      else
      {
        imgNode.src = node.relpath+"ftv2node.png";
        domNode.appendChild(imgNode);
      }
    }
  }
  else
  {
    if (node.isLast)
    {
      imgNode.src = node.relpath+"ftv2blank.png";
    }
    else
    {
      imgNode.src = node.relpath+"ftv2vertline.png";
    }
  }
  imgNode.border = "0";
}

function newNode(o, po, text, link, childrenData, lastNode)
{
  var node = new Object();
  node.children = Array();
  node.childrenData = childrenData;
  node.depth = po.depth + 1;
  node.relpath = po.relpath;
  node.isLast = lastNode;

  node.li = document.createElement("li");
  po.getChildrenUL().appendChild(node.li);
  node.parentNode = po;

  node.itemDiv = document.createElement("div");
  node.itemDiv.className = "item";

  node.labelSpan = document.createElement("span");
  node.labelSpan.className = "label";

  createIndent(o,node.itemDiv,node,0);
  node.itemDiv.appendChild(node.labelSpan);
  node.li.appendChild(node.itemDiv);

  var a = document.createElement("a");
  node.labelSpan.appendChild(a);
  node.label = document.createTextNode(text);
  a.appendChild(node.label);
  if (link) 
  {
    a.href = node.relpath+link;
  } 
  else 
  {
    if (childrenData != null) 
    {
      a.className = "nolink";
      a.href = "javascript:void(0)";
      a.onclick = node.expandToggle.onclick;
      node.expanded = false;
    }
  }

  node.childrenUL = null;
  node.getChildrenUL = function() 
  {
    if (!node.childrenUL) 
    {
      node.childrenUL = document.createElement("ul");
      node.childrenUL.className = "children_ul";
      node.childrenUL.style.display = "none";
      node.li.appendChild(node.childrenUL);
    }
    return node.childrenUL;
  };

  return node;
}

function showRoot()
{
  var headerHeight = $("#top").height();
  var footerHeight = $("#nav-path").height();
  var windowHeight = $(window).height() - headerHeight - footerHeight;
  navtree.scrollTo('#selected',0,{offset:-windowHeight/2});
}

function expandNode(o, node, imm)
{
  if (node.childrenData && !node.expanded) 
  {
    if (!node.childrenVisited) 
    {
      getNode(o, node);
    }
    if (imm)
    {
      $(node.getChildrenUL()).show();
    } 
    else 
    {
      $(node.getChildrenUL()).slideDown("fast",showRoot);
    }
    if (node.isLast)
    {
      node.plus_img.src = node.relpath+"ftv2mlastnode.png";
    }
    else
    {
      node.plus_img.src = node.relpath+"ftv2mnode.png";
    }
    node.expanded = true;
  }
}

function getNode(o, po)
{
  po.childrenVisited = true;
  var l = po.childrenData.length-1;
  for (var i in po.childrenData) 
  {
    var nodeData = po.childrenData[i];
    po.children[i] = newNode(o, po, nodeData[0], nodeData[1], nodeData[2],
        i==l);
  }
}

function findNavTreePage(url, data)
{
  var nodes = data;
  var result = null;
  for (var i in nodes) 
  {
    var d = nodes[i];
    if (d[1] == url) 
    {
      return new Array(i);
    }
    else if (d[2] != null) // array of children
    {
      result = findNavTreePage(url, d[2]);
      if (result != null) 
      {
        return (new Array(i).concat(result));
      }
    }
  }
  return null;
}

function initNavTree(toroot,relpath)
{
  var o = new Object();
  o.toroot = toroot;
  o.node = new Object();
  o.node.li = document.getElementById("nav-tree-contents");
  o.node.childrenData = NAVTREE;
  o.node.children = new Array();
  o.node.childrenUL = document.createElement("ul");
  o.node.getChildrenUL = function() { return o.node.childrenUL; };
  o.node.li.appendChild(o.node.childrenUL);
  o.node.depth = 0;
  o.node.relpath = relpath;

  getNode(o, o.node);

  o.breadcrumbs = findNavTreePage(toroot, NAVTREE);
  if (o.breadcrumbs == null)
  {
    o.breadcrumbs = findNavTreePage("index.html",NAVTREE);
  }
  if (o.breadcrumbs != null && o.breadcrumbs.length>0)
  {
    var p = o.node;
    for (var i in o.breadcrumbs) 
    {
      var j = o.breadcrumbs[i];
      p = p.children[j];
      expandNode(o,p,true);
    }
    p.itemDiv.className = p.itemDiv.className + " selected";
    p.itemDiv.id = "selected";
    $(window).load(showRoot);
  }
}

