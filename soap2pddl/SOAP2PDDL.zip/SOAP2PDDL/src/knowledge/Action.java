/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

/**
 * @author zeid
 *
 */
public class Action {
	private static OWLNamedIndividual m_precondition;
	private static OWLNamedIndividual m_effect;
	private OWLIndividual m_action_individual;
	private Precondition m_action_precondition;
	private Effect m_action_effect;
	/**
	 * 
	 */
	public Action() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_precondition
	 */
	public static OWLNamedIndividual getM_precondition() {
		return m_precondition;
	}
	/**
	 * @param m_precondition the m_precondition to set
	 */
	public static void setM_precondition(OWLNamedIndividual m_precondition) {
		Action.m_precondition = m_precondition;
	}
	/**
	 * @return the m_effect
	 */
	public static OWLNamedIndividual getM_effect() {
		return m_effect;
	}
	/**
	 * @param m_effect the m_effect to set
	 */
	public static void setM_effect(OWLNamedIndividual m_effect) {
		Action.m_effect = m_effect;
	}
	/**
	 * @return the m_action_individual
	 */
	public OWLIndividual getM_action_individual() {
		return m_action_individual;
	}
	/**
	 * @param m_action_individual the m_action_individual to set
	 */
	public void setM_action_individual(OWLIndividual m_action_individual) {
		this.m_action_individual = m_action_individual;
	}

	/**
	 * @return the m_action_precondition
	 */
	public Precondition getM_action_precondition() {
		return m_action_precondition;
	}
	/**
	 * @param m_action_precondition the m_action_precondition to set
	 */
	public void setM_action_precondition(Precondition m_action_precondition) {
		this.m_action_precondition = m_action_precondition;
	}
	/**
	 * @return the m_action_effect
	 */
	public Effect getM_action_effect() {
		return m_action_effect;
	}
	/**
	 * @param m_action_effect the m_action_effect to set
	 */
	public void setM_action_effect(Effect m_action_effect) {
		this.m_action_effect = m_action_effect;
	}

}
