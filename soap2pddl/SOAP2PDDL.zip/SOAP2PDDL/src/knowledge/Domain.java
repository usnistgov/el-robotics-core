/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Domain {
	private OWLIndividual m_domain_individual;
	
	private static ArrayList<NegativePredicate> m_negative_predicate_list;
	private static ArrayList<PositivePredicate> m_positive_predicate_list;
	private static ArrayList<Function> m_function_list;
	private static ArrayList<Action> m_action_list;
	/**
	 * 
	 */
	public Domain() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_domain_individual
	 */
	public OWLIndividual getM_domain_individual() {
		return m_domain_individual;
	}
	/**
	 * @param m_domain_individual the m_domain_individual to set
	 */
	public void setM_domain_individual(OWLIndividual m_domain_individual) {
		this.m_domain_individual = m_domain_individual;
	}
	
	/**
	 * @return the m_function_list
	 */
	public ArrayList<Function> getM_function_list() {
		return m_function_list;
	}
	/**
	 * @param m_function_list the m_function_list to set
	 */
	public void setM_function_list(ArrayList<Function> m_function_list) {
		Domain.m_function_list = m_function_list;
	}
	/**
	 * @return the m_action_list
	 */
	public static ArrayList<Action> getM_action_list() {
		return m_action_list;
	}
	/**
	 * @param m_action_list the m_action_list to set
	 */
	public void setM_action_list(ArrayList<Action> m_action_list) {
		Domain.m_action_list = m_action_list;
	}
	/**
	 * @return the m_negative_predicate_list
	 */
	public static ArrayList<NegativePredicate> getM_negative_predicate_list() {
		return m_negative_predicate_list;
	}
	/**
	 * @param m_negative_predicate_list the m_negative_predicate_list to set
	 */
	public void setM_negative_predicate_list(
			ArrayList<NegativePredicate> m_negative_predicate_list) {
		Domain.m_negative_predicate_list = m_negative_predicate_list;
	}
	/**
	 * @return the m_positive_predicate_list
	 */
	public static ArrayList<PositivePredicate> getM_positive_predicate_list() {
		return m_positive_predicate_list;
	}
	/**
	 * @param m_positive_predicate_list the m_positive_predicate_list to set
	 */
	public void setM_positive_predicate_list(
			ArrayList<PositivePredicate> m_positive_predicate_list) {
		Domain.m_positive_predicate_list = m_positive_predicate_list;
	}

}
