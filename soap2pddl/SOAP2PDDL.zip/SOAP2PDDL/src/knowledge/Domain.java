/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Domain {
	private OWLIndividual m_domain_individual;
	private static ArrayList<Predicate> m_predicate_list;
	private static ArrayList<Function> m_function_list;
	private static ArrayList<Action> m_action_list;
	/**
	 * 
	 */
	public Domain() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_domain_individual
	 */
	public OWLIndividual getM_domain_individual() {
		return m_domain_individual;
	}
	/**
	 * @param m_domain_individual the m_domain_individual to set
	 */
	public void setM_domain_individual(OWLIndividual m_domain_individual) {
		this.m_domain_individual = m_domain_individual;
	}
	/**
	 * @return the m_predicate_list
	 */
	public static ArrayList<Predicate> getM_predicate_list() {
		return m_predicate_list;
	}
	/**
	 * @param m_predicate_list the m_predicate_list to set
	 */
	public static void setM_predicate_list(ArrayList<Predicate> m_predicate_list) {
		Domain.m_predicate_list = m_predicate_list;
	}
	/**
	 * @return the m_function_list
	 */
	public static ArrayList<Function> getM_function_list() {
		return m_function_list;
	}
	/**
	 * @param m_function_list the m_function_list to set
	 */
	public static void setM_function_list(ArrayList<Function> m_function_list) {
		Domain.m_function_list = m_function_list;
	}
	/**
	 * @return the m_action_list
	 */
	public static ArrayList<Action> getM_action_list() {
		return m_action_list;
	}
	/**
	 * @param m_action_list the m_action_list to set
	 */
	public void setM_action_list(ArrayList<Action> m_action_list) {
		Domain.m_action_list = m_action_list;
	}

}
