/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Effect {
	private OWLIndividual m_effect_individual;
	private ArrayList<Predicate> m_effect_predicate_list = new ArrayList<Predicate>();
	private ArrayList<Function> m_effect_function_list = new ArrayList<Function>();

	/**
	 * 
	 */
	public Effect() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the m_effect_individual
	 */
	public OWLIndividual getM_effect_individual() {
		return m_effect_individual;
	}

	/**
	 * @param m_effect_individual the m_effect_individual to set
	 */
	public void setM_effect_individual(OWLIndividual m_effect_individual) {
		this.m_effect_individual = m_effect_individual;
	}

	/**
	 * @return the m_effect_predicate_list
	 */
	public ArrayList<Predicate> getM_effect_predicate_list() {
		return m_effect_predicate_list;
	}

	/**
	 * @param m_effect_predicate_list the m_effect_predicate_list to set
	 */
	public void setM_effect_predicate_list(ArrayList<Predicate> m_effect_predicate_list) {
		this.m_effect_predicate_list = m_effect_predicate_list;
	}

	/**
	 * @return the m_effect_function_list
	 */
	public ArrayList<Function> getM_effect_function_list() {
		return m_effect_function_list;
	}

	/**
	 * @param m_effect_function_list the m_effect_function_list to set
	 */
	public void setM_effect_function_list(ArrayList<Function> m_effect_function_list) {
		this.m_effect_function_list = m_effect_function_list;
	}

}
