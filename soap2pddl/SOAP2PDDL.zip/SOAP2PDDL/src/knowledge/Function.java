/**
 * 
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Function {
	private OWLIndividual m_individual;
	private String m_reference_parameter;
	private String m_target_parameter;
	private String m_description;
	
	private String m_hasFunction_Description = "hasFunction_Description";
	private String m_hasFunction_ReferenceParameter = "hasFunction_ReferenceParameter";
	private String m_hasFunction_TargetParameter = "hasFunction_TargetParameter";
	/**
	 * 
	 */
	public Function() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}

	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_reference_parameter
	 */
	public String getM_reference_parameter() {
		return m_reference_parameter;
	}
	/**
	 * @param m_reference_parameter the m_reference_parameter to set
	 */
	public void setM_reference_parameter(String m_reference_parameter) {
		this.m_reference_parameter = m_reference_parameter;
	}
	/**
	 * @return the m_target_parameter
	 */
	public String getM_target_parameter() {
		return m_target_parameter;
	}
	/**
	 * @param m_target_parameter the m_target_parameter to set
	 */
	public void setM_target_parameter(String m_target_parameter) {
		this.m_target_parameter = m_target_parameter;
	}
	/**
	 * @return the m_description
	 */
	public String getM_description() {
		return m_description;
	}
	/**
	 * @param m_description the m_description to set
	 */
	public void setM_description(String m_description) {
		this.m_description = m_description;
	}
	/**
	 * @return the m_hasFunction_Description
	 */
	public String getM_hasFunction_Description() {
		return m_hasFunction_Description;
	}
	/**
	 * @param m_hasFunction_Description the m_hasFunction_Description to set
	 */
	public void setM_hasFunction_Description(String m_hasFunction_Description) {
		this.m_hasFunction_Description = m_hasFunction_Description;
	}
	/**
	 * @return the m_hasFunction_ReferenceParameter
	 */
	public String getM_hasFunction_ReferenceParameter() {
		return m_hasFunction_ReferenceParameter;
	}
	/**
	 * @param m_hasFunction_ReferenceParameter the m_hasFunction_ReferenceParameter to set
	 */
	public void setM_hasFunction_ReferenceParameter(
			String m_hasFunction_ReferenceParameter) {
		this.m_hasFunction_ReferenceParameter = m_hasFunction_ReferenceParameter;
	}
	/**
	 * @return the m_hasFunction_TargetParameter
	 */
	public String getM_hasFunction_TargetParameter() {
		return m_hasFunction_TargetParameter;
	}
	/**
	 * @param m_hasFunction_TargetParameter the m_hasFunction_TargetParameter to set
	 */
	public void setM_hasFunction_TargetParameter(
			String m_hasFunction_TargetParameter) {
		this.m_hasFunction_TargetParameter = m_hasFunction_TargetParameter;
	}


}
