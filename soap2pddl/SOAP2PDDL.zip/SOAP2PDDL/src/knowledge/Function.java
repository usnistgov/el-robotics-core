/**
 * 
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Function {
	private OWLIndividual m_function_individual;
	/**
	 * 
	 */
	public Function() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_function_individual
	 */
	public OWLIndividual getM_function_individual() {
		return m_function_individual;
	}

	/**
	 * @param m_function_individual the m_function_individual to set
	 */
	public void setM_function_individual(OWLIndividual m_function_individual) {
		this.m_function_individual = m_function_individual;
	}

}
