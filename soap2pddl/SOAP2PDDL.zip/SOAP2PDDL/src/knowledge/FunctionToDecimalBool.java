/**
 * 
 */
package knowledge;


/**
 * @author zeid
 *
 */
public class FunctionToDecimalBool {
	private String F1;
	private String A1;
	private String expression;

	/**
	 * 
	 */
	public FunctionToDecimalBool() {
		// TODO Auto-generated constructor stub
	}


	/**
	 * @return the expression
	 */
	public String getExpression() {
		return expression;
	}

	/**
	 * @param expression the expression to set
	 */
	public void setExpression(String expression) {
		this.expression = expression;
	}


	/**
	 * @return the f1
	 */
	public String getF1() {
		return F1;
	}


	/**
	 * @param f1 the f1 to set
	 */
	public void setF1(String f1) {
		F1 = f1;
	}


	/**
	 * @return the a1
	 */
	public String getA1() {
		return A1;
	}


	/**
	 * @param a1 the a1 to set
	 */
	public void setA1(String a1) {
		A1 = a1;
	}
}	


	


