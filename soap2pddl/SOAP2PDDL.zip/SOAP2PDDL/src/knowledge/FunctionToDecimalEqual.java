/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToDecimalEqual extends FunctionToDecimalBool {

	/**
	 * 
	 */
	public FunctionToDecimalEqual() {
		// TODO Auto-generated constructor stub
	}

}
