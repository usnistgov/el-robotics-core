/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToDecimalGreaterOrEqual extends FunctionToDecimalBool {

	/**
	 * 
	 */
	public FunctionToDecimalGreaterOrEqual() {
		// TODO Auto-generated constructor stub
	}

}
