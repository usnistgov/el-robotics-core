/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToFunctionGreater extends FunctionToFunctionBool {

	/**
	 * 
	 */
	public FunctionToFunctionGreater() {
		// TODO Auto-generated constructor stub
	}

}
