/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class FunctionToFunctionLessOrEqual extends FunctionToFunctionBool {

	/**
	 * 
	 */
	public FunctionToFunctionLessOrEqual() {
		// TODO Auto-generated constructor stub
	}

}
