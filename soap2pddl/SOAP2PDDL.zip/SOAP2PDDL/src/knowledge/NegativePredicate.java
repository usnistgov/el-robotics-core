/**
 * 
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLNamedIndividual;

/**
 * @author zeid
 *
 */
public class NegativePredicate extends Predicate {
	private OWLIndividual m_individual;
	private OWLNamedIndividual m_positive_predicate;
	/**
	 * 
	 */
	public NegativePredicate() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}
	/**
	 * @return the m_positive_predicate
	 */
	public OWLIndividual getM_positive_predicate() {
		return m_positive_predicate;
	}
	/**
	 * @param m_positive_predicate the m_positive_predicate to set
	 */
	public void setM_positive_predicate(OWLNamedIndividual m_positive_predicate) {
		this.m_positive_predicate = m_positive_predicate;
	}

}
