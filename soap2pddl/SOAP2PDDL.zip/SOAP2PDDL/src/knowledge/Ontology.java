package knowledge;

import java.io.File;
import java.net.MalformedURLException;
import java.text.Normalizer;
import java.text.Normalizer.Form;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Ontology {
	private static OWLDataFactory m_OWLDataFactory;
	private static OWLReasoner m_OWLReasoner;
	private static OWLOntologyManager m_OWLOntologyManager;
	private static OWLOntology m_OWLOntology;
	private static String m_OWLOntologyPath;
	private String m_SoapClass, m_DomainClass, m_ActionBaseClass, m_PositivePredicateClass, m_NegativePredicateClass, m_FunctionClass;
	private String m_FunctionToDecimalEqual, m_FunctionToDecimalGreater, m_FunctionToDecimalGreaterOrEqual, m_FunctionToDecimalLess, m_FunctionToDecimalLessOrEqual;
	private String m_FunctionToFunctionEqual, m_FunctionToFunctionGreater, m_FunctionToFunctionGreaterOrEqual, m_FunctionToFunctionLess, m_FunctionToFunctionLessOrEqual;
	private String m_FunctionOperation;
	private String m_soapClasses_IRI;
	private String m_soapInstances_IRI;
	private String m_kittingWorkstationClasses_IRI;


	private static final char m_SEPARATOR = '#';
	private static final char m_SEPARATOR_DATAPROPERTY = '"';
	
	public Ontology() {
		m_OWLOntologyPath="soapInstances.owl";
		m_SoapClass="SOAP";
		m_DomainClass="Domain";
		setM_PositivePredicateClass("PositivePredicate"); 
		setM_NegativePredicateClass("NegativePredicate");
		setM_FunctionClass("Function");
		setM_ActionBaseClass("ActionBase");
		setM_FunctionToFunctionEqual("FunctionToFunctionEqual");
		setM_FunctionToFunctionLessOrEqual("FunctionToFunctionLessOrEqual");
		setM_FunctionToFunctionGreaterOrEqual("FunctionToFunctionGreaterOrEqual");
		setM_FunctionToFunctionGreater("FunctionToFunctionGreater");
		setM_FunctionToFunctionLess("FunctionToFunctionLess");
		setM_FunctionOperation("FunctionOperation");
		m_soapClasses_IRI = "http://www.nist.gov/el/ontologies/soapClasses.owl#";
		m_soapInstances_IRI = "http://www.nist.gov/el/ontologies/soapInstances.owl#";
		m_kittingWorkstationClasses_IRI = "http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";
	}
	
	/**
	 * @brief Creates an OWL Ontology manager that is configured with standard parsers, storers, etc.
	 */
	public void setManager() {
		this.m_OWLOntologyManager = OWLManager.createOWLOntologyManager();
	}

	public static String getM_OWLOntologyPath() {
		return m_OWLOntologyPath;
	}

	public static void setM_OWLOntologyPath(String m_OWLOntologyPath) {
		Ontology.m_OWLOntologyPath = m_OWLOntologyPath;
	}
	
	public void loadOntologyFromPath()
			throws MalformedURLException, OWLException {
		String l_OWLOntologyPath=getM_OWLOntologyPath();
		File file = new File(l_OWLOntologyPath);
		OWLOntology l_OWLOntology;
		l_OWLOntology = m_OWLOntologyManager.loadOntologyFromOntologyDocument(file);
		setM_OWLOntology(l_OWLOntology);
	}

	public OWLOntology getM_OWLOntology() {
		return m_OWLOntology;
	}

	public static void setM_OWLOntology(OWLOntology m_OWLOntology) {
		Ontology.m_OWLOntology = m_OWLOntology;
	}

	public OWLDataFactory getM_OWLDataFactory() {
		return m_OWLDataFactory;
	}

	public static void setM_OWLDataFactory(OWLDataFactory m_OWLDataFactory) {
		Ontology.m_OWLDataFactory = m_OWLDataFactory;
	}
	
	public void setM_OWLDataFactory() {
		Ontology.m_OWLDataFactory = m_OWLOntologyManager.getOWLDataFactory();
	}

	public OWLReasoner getM_OWLReasoner() {
		return m_OWLReasoner;
	}

	public static void setM_OWLReasoner(OWLReasoner m_OWLReasoner) {
		Ontology.m_OWLReasoner = m_OWLReasoner;
	}
	
	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		setM_OWLReasoner(reasonerFactory.createReasoner(m_OWLOntology, config));
	}

	
	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = m_OWLOntologyManager.getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(m_soapClasses_IRI.concat(":" + myClassName)));

		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = m_OWLReasoner.getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}
	
	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = m_OWLOntologyManager.getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(m_soapClasses_IRI.concat(myClassName)));

		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		return myClass;
	}
	
	/**
	 * \brief Return the name of the entity without the IRI
	 * 
	 * For example, if @a entity =
	 * [<http://www.semanticweb.org/ontologies/2013/0/soap.owl#Kitting>], this
	 * function returns @a Kitting. This function operates as follows: -
	 * Identify the index of the separator @a SEPARATOR - Keep only what is
	 * after the SEPARATOR - Remove characters that are not alphanumeric \param
	 * entity Entity to be trimmed \return The name of the entity without the
	 * IRI
	 */
	public String cleanIRI(Object entity) {
		int index = entity.toString().indexOf(m_SEPARATOR);
		String new_entity = entity.toString().substring(index + 1);
		String normalized = Normalizer.normalize(new_entity.toString(),
				Form.NFD);
		String result = normalized.replaceAll("[^A-Za-z0-9-_]", "");

		return (result);
	}
	
	public String cleanIRIDataProperty(Object entity) {
		int firstOccurrence = entity.toString().indexOf(m_SEPARATOR_DATAPROPERTY);
		int lastOccurrence = entity.toString().lastIndexOf(m_SEPARATOR_DATAPROPERTY);
		String new_entity = entity.toString().substring(firstOccurrence+1,lastOccurrence);
		return (new_entity);
	}


	public String getM_soapInstances_IRI() {
		return m_soapInstances_IRI;
	}

	public void setM_soapInstances_IRI(String m_soapInstances_IRI) {
		this.m_soapInstances_IRI = m_soapInstances_IRI;
	}

	public String getM_kittingWorkstationClasses_IRI() {
		return m_kittingWorkstationClasses_IRI;
	}

	public void setM_kittingWorkstationClasses_IRI(
			String m_kittingWorkstationClasses_IRI) {
		this.m_kittingWorkstationClasses_IRI = m_kittingWorkstationClasses_IRI;
	}

	public String getM_soapClasses_IRI() {
		return m_soapClasses_IRI;
	}

	public void setM_soapClasses_IRI(String m_soapClasses_IRI) {
		this.m_soapClasses_IRI = m_soapClasses_IRI;
	}

	/**
	 * @return the m_DomainClass
	 */
	public String getM_DomainClass() {
		return m_DomainClass;
	}

	/**
	 * @param m_DomainClass the m_DomainClass to set
	 */
	public void setM_DomainClass(String m_DomainClass) {
		this.m_DomainClass = m_DomainClass;
	}

	/**
	 * @return the m_ActionBaseClass
	 */
	public String getM_ActionBaseClass() {
		return m_ActionBaseClass;
	}

	/**
	 * @param m_ActionBaseClass the m_ActionBaseClass to set
	 */
	public void setM_ActionBaseClass(String m_ActionBaseClass) {
		this.m_ActionBaseClass = m_ActionBaseClass;
	}


	/**
	 * @return the m_FunctionClass
	 */
	public String getM_FunctionClass() {
		return m_FunctionClass;
	}

	/**
	 * @param m_FunctionClass the m_FunctionClass to set
	 */
	public void setM_FunctionClass(String m_FunctionClass) {
		this.m_FunctionClass = m_FunctionClass;
	}

	/**
	 * @return the m_PositivePredicateClass
	 */
	public String getM_PositivePredicateClass() {
		return m_PositivePredicateClass;
	}

	/**
	 * @param m_PositivePredicateClass the m_PositivePredicateClass to set
	 */
	public void setM_PositivePredicateClass(String m_PositivePredicateClass) {
		this.m_PositivePredicateClass = m_PositivePredicateClass;
	}

	/**
	 * @return the m_NegativePredicateClass
	 */
	public String getM_NegativePredicateClass() {
		return m_NegativePredicateClass;
	}

	/**
	 * @param m_NegativePredicateClass the m_NegativePredicateClass to set
	 */
	public void setM_NegativePredicateClass(String m_NegativePredicateClass) {
		this.m_NegativePredicateClass = m_NegativePredicateClass;
	}

	/**
	 * @return the m_SoapClass
	 */
	public String getM_SoapClass() {
		return m_SoapClass;
	}

	/**
	 * @param m_SoapClass the m_SoapClass to set
	 */
	public void setM_SoapClass(String m_SoapClass) {
		this.m_SoapClass = m_SoapClass;
	}

	/**
	 * @return the m_FunctionToDecimalLess
	 */
	public String getM_FunctionToDecimalLess() {
		return m_FunctionToDecimalLess;
	}

	/**
	 * @param m_FunctionToDecimalLess the m_FunctionToDecimalLess to set
	 */
	public void setM_FunctionToDecimalLess(String m_FunctionToDecimalLess) {
		this.m_FunctionToDecimalLess = m_FunctionToDecimalLess;
	}

	/**
	 * @return the m_FunctionToDecimalLessOrEqual
	 */
	public String getM_FunctionToDecimalLessOrEqual() {
		return m_FunctionToDecimalLessOrEqual;
	}

	/**
	 * @param m_FunctionToDecimalLessOrEqual the m_FunctionToDecimalLessOrEqual to set
	 */
	public void setM_FunctionToDecimalLessOrEqual(
			String m_FunctionToDecimalLessOrEqual) {
		this.m_FunctionToDecimalLessOrEqual = m_FunctionToDecimalLessOrEqual;
	}

	/**
	 * @return the m_FunctionToDecimalEqual
	 */
	public String getM_FunctionToDecimalEqual() {
		return m_FunctionToDecimalEqual;
	}

	/**
	 * @param m_FunctionToDecimalEqual the m_FunctionToDecimalEqual to set
	 */
	public void setM_FunctionToDecimalEqual(String m_FunctionToDecimalEqual) {
		this.m_FunctionToDecimalEqual = m_FunctionToDecimalEqual;
	}

	/**
	 * @return the m_FunctionToDecimalGreaterOrEqual
	 */
	public String getM_FunctionToDecimalGreaterOrEqual() {
		return m_FunctionToDecimalGreaterOrEqual;
	}

	/**
	 * @param m_FunctionToDecimalGreaterOrEqual the m_FunctionToDecimalGreaterOrEqual to set
	 */
	public void setM_FunctionToDecimalGreaterOrEqual(
			String m_FunctionToDecimalGreaterOrEqual) {
		this.m_FunctionToDecimalGreaterOrEqual = m_FunctionToDecimalGreaterOrEqual;
	}

	/**
	 * @return the m_FunctionToDecimalGreater
	 */
	public String getM_FunctionToDecimalGreater() {
		return m_FunctionToDecimalGreater;
	}

	/**
	 * @param m_FunctionToDecimalGreater the m_FunctionToDecimalGreater to set
	 */
	public void setM_FunctionToDecimalGreater(String m_FunctionToDecimalGreater) {
		this.m_FunctionToDecimalGreater = m_FunctionToDecimalGreater;
	}

	/**
	 * @return the m_FunctionToFunctionGreaterOrEqual
	 */
	public String getM_FunctionToFunctionGreaterOrEqual() {
		return m_FunctionToFunctionGreaterOrEqual;
	}

	/**
	 * @param m_FunctionToFunctionGreaterOrEqual the m_FunctionToFunctionGreaterOrEqual to set
	 */
	public void setM_FunctionToFunctionGreaterOrEqual(
			String m_FunctionToFunctionGreaterOrEqual) {
		this.m_FunctionToFunctionGreaterOrEqual = m_FunctionToFunctionGreaterOrEqual;
	}

	/**
	 * @return the m_FunctionToFunctionEqual
	 */
	public String getM_FunctionToFunctionEqual() {
		return m_FunctionToFunctionEqual;
	}

	/**
	 * @param m_FunctionToFunctionEqual the m_FunctionToFunctionEqual to set
	 */
	public void setM_FunctionToFunctionEqual(String m_FunctionToFunctionEqual) {
		this.m_FunctionToFunctionEqual = m_FunctionToFunctionEqual;
	}

	/**
	 * @return the m_FunctionToFunctionGreater
	 */
	public String getM_FunctionToFunctionGreater() {
		return m_FunctionToFunctionGreater;
	}

	/**
	 * @param m_FunctionToFunctionGreater the m_FunctionToFunctionGreater to set
	 */
	public void setM_FunctionToFunctionGreater(
			String m_FunctionToFunctionGreater) {
		this.m_FunctionToFunctionGreater = m_FunctionToFunctionGreater;
	}

	/**
	 * @return the m_FunctionToFunctionLess
	 */
	public String getM_FunctionToFunctionLess() {
		return m_FunctionToFunctionLess;
	}

	/**
	 * @param m_FunctionToFunctionLess the m_FunctionToFunctionLess to set
	 */
	public void setM_FunctionToFunctionLess(String m_FunctionToFunctionLess) {
		this.m_FunctionToFunctionLess = m_FunctionToFunctionLess;
	}

	/**
	 * @return the m_FunctionToFunctionLessOrEqual
	 */
	public String getM_FunctionToFunctionLessOrEqual() {
		return m_FunctionToFunctionLessOrEqual;
	}

	/**
	 * @param m_FunctionToFunctionLessOrEqual the m_FunctionToFunctionLessOrEqual to set
	 */
	public void setM_FunctionToFunctionLessOrEqual(
			String m_FunctionToFunctionLessOrEqual) {
		this.m_FunctionToFunctionLessOrEqual = m_FunctionToFunctionLessOrEqual;
	}

	/**
	 * @return the m_FunctionOperation
	 */
	public String getM_FunctionOperation() {
		return m_FunctionOperation;
	}

	/**
	 * @param m_FunctionOperation the m_FunctionOperation to set
	 */
	public void setM_FunctionOperation(String m_FunctionOperation) {
		this.m_FunctionOperation = m_FunctionOperation;
	}
}
