package knowledge;

import java.io.File;
import java.net.MalformedURLException;
import java.text.Normalizer;
import java.text.Normalizer.Form;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.ConsoleProgressMonitor;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerConfiguration;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.reasoner.structural.StructuralReasonerFactory;

public class Ontology {
	private static OWLDataFactory m_OWLDataFactory;
	private static OWLReasoner m_OWLReasoner;
	private static OWLOntologyManager m_OWLOntologyManager;
	private static OWLOntology m_OWLOntology;
	private static String m_OWLOntologyPath;
	private String m_RootClass;
	private String m_DomainClass, m_ActionBaseClass, m_PositivePredicateClass, m_NegativePredicateClass, m_FunctionClass;
	private String m_soapClasses_IRI;
	private String m_soapInstances_IRI;
	private String m_kittingWorkstationClasses_IRI;


	private static final char m_SEPARATOR = '#';
	private static final char m_SEPARATOR_DATAPROPERTY = '"';
	
	public Ontology() {
		m_OWLOntologyPath="soapInstances.owl";
		m_RootClass="SOAP";
		m_DomainClass="Domain";
		m_ActionBaseClass = "ActionBase";
		setM_PositivePredicateClass("PositivePredicate"); 
		setM_NegativePredicateClass("NegativePredicate");
		m_FunctionClass="Function";
		m_soapClasses_IRI = "http://www.nist.gov/el/ontologies/soapClasses.owl#";
		m_soapInstances_IRI = "http://www.nist.gov/el/ontologies/soapInstances.owl#";
		m_kittingWorkstationClasses_IRI = "http://www.nist.gov/el/ontologies/kittingWorkstationClasses.owl#";
	}
	
	/**
	 * @brief Creates an OWL Ontology manager that is configured with standard parsers, storers, etc.
	 */
	public void setManager() {
		this.m_OWLOntologyManager = OWLManager.createOWLOntologyManager();
	}

	public static String getM_OWLOntologyPath() {
		return m_OWLOntologyPath;
	}

	public static void setM_OWLOntologyPath(String m_OWLOntologyPath) {
		Ontology.m_OWLOntologyPath = m_OWLOntologyPath;
	}
	
	public void loadOntologyFromPath()
			throws MalformedURLException, OWLException {
		String l_OWLOntologyPath=getM_OWLOntologyPath();
		File file = new File(l_OWLOntologyPath);
		OWLOntology l_OWLOntology;
		l_OWLOntology = m_OWLOntologyManager.loadOntologyFromOntologyDocument(file);
		setM_OWLOntology(l_OWLOntology);
	}

	public OWLOntology getM_OWLOntology() {
		return m_OWLOntology;
	}

	public static void setM_OWLOntology(OWLOntology m_OWLOntology) {
		Ontology.m_OWLOntology = m_OWLOntology;
	}

	public OWLDataFactory getM_OWLDataFactory() {
		return m_OWLDataFactory;
	}

	public static void setM_OWLDataFactory(OWLDataFactory m_OWLDataFactory) {
		Ontology.m_OWLDataFactory = m_OWLDataFactory;
	}
	
	public void setM_OWLDataFactory() {
		Ontology.m_OWLDataFactory = m_OWLOntologyManager.getOWLDataFactory();
	}

	public OWLReasoner getM_OWLReasoner() {
		return m_OWLReasoner;
	}

	public static void setM_OWLReasoner(OWLReasoner m_OWLReasoner) {
		Ontology.m_OWLReasoner = m_OWLReasoner;
	}
	
	public void setReasoner() {
		OWLReasonerFactory reasonerFactory = new StructuralReasonerFactory();
		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		setM_OWLReasoner(reasonerFactory.createReasoner(m_OWLOntology, config));
	}

	public String getM_RootClass() {
		return m_RootClass;
	}

	public void setM_RootClass(String m_RootClass) {
		this.m_RootClass = m_RootClass;
	}
	
	public NodeSet<OWLClass> getSubclasses(String myClassName) {
		OWLDataFactory factory = m_OWLOntologyManager.getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(m_soapClasses_IRI.concat(":" + myClassName)));

		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);

		NodeSet<OWLClass> subclasses_of_myClass = m_OWLReasoner.getSubClasses(myClass, true);

		return subclasses_of_myClass;
	}
	
	public OWLClass getClass(String myClassName) {
		OWLDataFactory factory = m_OWLOntologyManager.getOWLDataFactory();
		OWLClass myClass = factory.getOWLClass(IRI.create(m_soapClasses_IRI.concat(myClassName)));

		ConsoleProgressMonitor progressMonitor = new ConsoleProgressMonitor();
		OWLReasonerConfiguration config = new SimpleConfiguration(
				progressMonitor);
		return myClass;
	}
	
	/**
	 * \brief Return the name of the entity without the IRI
	 * 
	 * For example, if @a entity =
	 * [<http://www.semanticweb.org/ontologies/2013/0/soap.owl#Kitting>], this
	 * function returns @a Kitting. This function operates as follows: -
	 * Identify the index of the separator @a SEPARATOR - Keep only what is
	 * after the SEPARATOR - Remove characters that are not alphanumeric \param
	 * entity Entity to be trimmed \return The name of the entity without the
	 * IRI
	 */
	public String cleanIRI(Object entity) {
		int index = entity.toString().indexOf(m_SEPARATOR);
		String new_entity = entity.toString().substring(index + 1);
		String normalized = Normalizer.normalize(new_entity.toString(),
				Form.NFD);
		String result = normalized.replaceAll("[^A-Za-z0-9-_]", "");

		return (result);
	}
	
	public String cleanIRIDataProperty(Object entity) {
		int firstOccurrence = entity.toString().indexOf(m_SEPARATOR_DATAPROPERTY);
		int lastOccurrence = entity.toString().lastIndexOf(m_SEPARATOR_DATAPROPERTY);
		String new_entity = entity.toString().substring(firstOccurrence+1,lastOccurrence);
		return (new_entity);
	}


	public String getM_soapInstances_IRI() {
		return m_soapInstances_IRI;
	}

	public void setM_soapInstances_IRI(String m_soapInstances_IRI) {
		this.m_soapInstances_IRI = m_soapInstances_IRI;
	}

	public String getM_kittingWorkstationClasses_IRI() {
		return m_kittingWorkstationClasses_IRI;
	}

	public void setM_kittingWorkstationClasses_IRI(
			String m_kittingWorkstationClasses_IRI) {
		this.m_kittingWorkstationClasses_IRI = m_kittingWorkstationClasses_IRI;
	}

	public String getM_soapClasses_IRI() {
		return m_soapClasses_IRI;
	}

	public void setM_soapClasses_IRI(String m_soapClasses_IRI) {
		this.m_soapClasses_IRI = m_soapClasses_IRI;
	}

	/**
	 * @return the m_DomainClass
	 */
	public String getM_DomainClass() {
		return m_DomainClass;
	}

	/**
	 * @param m_DomainClass the m_DomainClass to set
	 */
	public void setM_DomainClass(String m_DomainClass) {
		this.m_DomainClass = m_DomainClass;
	}

	/**
	 * @return the m_ActionBaseClass
	 */
	public String getM_ActionBaseClass() {
		return m_ActionBaseClass;
	}

	/**
	 * @param m_ActionBaseClass the m_ActionBaseClass to set
	 */
	public void setM_ActionBaseClass(String m_ActionBaseClass) {
		this.m_ActionBaseClass = m_ActionBaseClass;
	}


	/**
	 * @return the m_FunctionClass
	 */
	public String getM_FunctionClass() {
		return m_FunctionClass;
	}

	/**
	 * @param m_FunctionClass the m_FunctionClass to set
	 */
	public void setM_FunctionClass(String m_FunctionClass) {
		this.m_FunctionClass = m_FunctionClass;
	}

	/**
	 * @return the m_PositivePredicateClass
	 */
	public String getM_PositivePredicateClass() {
		return m_PositivePredicateClass;
	}

	/**
	 * @param m_PositivePredicateClass the m_PositivePredicateClass to set
	 */
	public void setM_PositivePredicateClass(String m_PositivePredicateClass) {
		this.m_PositivePredicateClass = m_PositivePredicateClass;
	}

	/**
	 * @return the m_NegativePredicateClass
	 */
	public String getM_NegativePredicateClass() {
		return m_NegativePredicateClass;
	}

	/**
	 * @param m_NegativePredicateClass the m_NegativePredicateClass to set
	 */
	public void setM_NegativePredicateClass(String m_NegativePredicateClass) {
		this.m_NegativePredicateClass = m_NegativePredicateClass;
	}
}
