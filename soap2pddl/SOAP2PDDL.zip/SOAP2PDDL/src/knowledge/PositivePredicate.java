/**
 * 
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class PositivePredicate extends Predicate {
	private OWLIndividual m_individual;
	/**
	 * 
	 */
	public PositivePredicate() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_individual
	 */
	public OWLIndividual getM_individual() {
		return m_individual;
	}
	/**
	 * @param m_individual the m_individual to set
	 */
	public void setM_individual(OWLIndividual m_individual) {
		this.m_individual = m_individual;
	}

}
