/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Precondition {
	private OWLIndividual m_precondition_individual;
	private ArrayList<Predicate> m_precondition_predicate_list = new ArrayList<Predicate>();
	private ArrayList<Function> m_precondition_function_list = new ArrayList<Function>();

	/**
	 * 
	 */
	public Precondition() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the m_precondition_individual
	 */
	public OWLIndividual getM_precondition_individual() {
		return m_precondition_individual;
	}

	/**
	 * @param m_precondition_individual the m_precondition_individual to set
	 */
	public void setM_precondition_individual(OWLIndividual m_precondition_individual) {
		this.m_precondition_individual = m_precondition_individual;
	}

	/**
	 * @return the m_precondition_predicate_list
	 */
	public ArrayList<Predicate> getM_precondition_predicate_list() {
		return m_precondition_predicate_list;
	}

	/**
	 * @param m_precondition_predicate_list the m_precondition_predicate_list to set
	 */
	public void setM_precondition_predicate_list(
			ArrayList<Predicate> m_precondition_predicate_list) {
		this.m_precondition_predicate_list = m_precondition_predicate_list;
	}

	/**
	 * @return the m_precondition_function_list
	 */
	public ArrayList<Function> getM_precondition_function_list() {
		return m_precondition_function_list;
	}

	/**
	 * @param m_precondition_function_list the m_precondition_function_list to set
	 */
	public void setM_precondition_function_list(
			ArrayList<Function> m_precondition_function_list) {
		this.m_precondition_function_list = m_precondition_function_list;
	}

}
