/**
 * 
 */
package knowledge;

import java.util.ArrayList;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Predicate {

	private String m_reference_parameter;
	private String m_target_parameter;
	private String m_description;
	private ArrayList<PredicateGroup> m_predicateGroup_list;
	/**
	 * 
	 */
	public Predicate() {
		// TODO Auto-generated constructor stub
	}
	
	/**
	 * @return the m_reference_parameter
	 */
	public String getM_reference_parameter() {
		return m_reference_parameter;
	}
	/**
	 * @param m_reference_parameter the m_reference_parameter to set
	 */
	public void setM_reference_parameter(String m_reference_parameter) {
		this.m_reference_parameter = m_reference_parameter;
	}
	/**
	 * @return the m_target_parameter
	 */
	public String getM_target_parameter() {
		return m_target_parameter;
	}
	/**
	 * @param m_target_parameter the m_target_parameter to set
	 */
	public void setM_target_parameter(String m_target_parameter) {
		this.m_target_parameter = m_target_parameter;
	}
	/**
	 * @return the m_predicateGroup_list
	 */
	public ArrayList<PredicateGroup> getM_predicateGroup_list() {
		return m_predicateGroup_list;
	}
	/**
	 * @param m_predicateGroup_list the m_predicateGroup_list to set
	 */
	public void setM_predicateGroup_list(ArrayList<PredicateGroup> m_predicateGroup_list) {
		this.m_predicateGroup_list = m_predicateGroup_list;
	}

	/**
	 * @return the m_description
	 */
	public String getM_description() {
		return m_description;
	}

	/**
	 * @param m_description the m_description to set
	 */
	public void setM_description(String m_description) {
		this.m_description = m_description;
	}


}
