/**
 * 
 */
package knowledge;

/**
 * @author zeid
 *
 */
public class PredicateGroup {

	/**
	 * 
	 */
	public PredicateGroup() {
		// TODO Auto-generated constructor stub
	}

}
