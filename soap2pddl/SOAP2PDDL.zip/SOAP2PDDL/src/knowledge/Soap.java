/**
 * 
 */
package knowledge;

import org.semanticweb.owlapi.model.OWLIndividual;

/**
 * @author zeid
 *
 */
public class Soap {
	private OWLIndividual m_soap_individual;
	private Domain m_domain;
	/**
	 * 
	 */
	public Soap() {
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the m_soap_individual
	 */
	public OWLIndividual getM_soap_individual() {
		return m_soap_individual;
	}
	/**
	 * @param m_soap_individual the m_soap_individual to set
	 */
	public void setM_soap_individual(OWLIndividual m_soap_individual) {
		this.m_soap_individual = m_soap_individual;
	}
	/**
	 * @return the m_domain
	 */
	public Domain getM_domain() {
		return m_domain;
	}
	/**
	 * @param m_domain the m_domain to set
	 */
	public void setM_domain(Domain m_domain) {
		this.m_domain = m_domain;
	}

}
