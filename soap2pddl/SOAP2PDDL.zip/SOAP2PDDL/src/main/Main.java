package main;

import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.NodeSet;

import tools.Reader;
import tools.Writer;

import knowledge.Domain;
import knowledge.Ontology;
import knowledge.Soap;

public class Main {
	public static void main (String[] args) throws MalformedURLException, OWLException, FileNotFoundException, UnsupportedEncodingException {
		final Ontology myOntology = new Ontology();
		final Reader myReader = new Reader();
		final Writer myWriter = new Writer();

		myOntology.setManager();
		myOntology.loadOntologyFromPath();
		myOntology.setReasoner();
		myOntology.setM_OWLDataFactory();
		OWLClass SoapOWLClass = myOntology.getClass(myOntology.getM_SoapClass()); 
		//-- Parse the Soap ontology starting at SoapClass
		Soap mySoap = myReader.parseSOAP(SoapOWLClass, myOntology);
		//-- Display what we have parsed
		myReader.displaySoap(myOntology, mySoap);
		
		myWriter.writeDomain(myOntology, mySoap);
	}
}
