package main;

import java.net.MalformedURLException;

import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLException;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.reasoner.NodeSet;

import tools.Reader;

import knowledge.Domain;
import knowledge.Ontology;

public class Main {
	 public static void main (String[] args) throws MalformedURLException, OWLException {
		 final Ontology myOntology = new Ontology();
		 final Reader myReader = new Reader();
		 Domain domain = new Domain();
		 //myOntology.setM_OWLOntology(null);
		 myOntology.setManager();
		 myOntology.loadOntologyFromPath();
		 myOntology.setReasoner();
		 myOntology.setM_OWLDataFactory();
		 //String rootClass = myOntology.getM_RootClass();
		 String ActionBaseClass = myOntology.getM_ActionBaseClass();
		 String PredicateClass = myOntology.getM_PredicateClass();
		 //OWLClass rootOWLClass = myOntology.getClass(rootClass);
		 OWLClass ActionBaseOWLClass = myOntology.getClass(ActionBaseClass);
		 OWLClass PredicateOWLClass = myOntology.getClass(PredicateClass);
		 //myReader.parseDomain(ActionBaseOWLClass,myOntology);
		 //-- Retrieve all the actions
//		 /myReader.parseActionBase(ActionBaseOWLClass,myOntology, domain);
		 myReader.parsePredicate(PredicateOWLClass,myOntology, domain);
		 //myReader.parseOntology(rootOWLClass,myOntology);
	    }
}
