package tools;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.NegativePredicate;
import knowledge.Ontology;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.Predicate;
import knowledge.Soap;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLDatatype;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

public class Reader {
	private static String m_hasSOAP_Domain;
	private static String m_hasDomain_Predicate;
	private static String m_hasDomain_Function;

	public Reader() {
		m_hasSOAP_Domain = "hasSOAP_Domain";
		m_hasDomain_Predicate = "hasDomain_Predicate";
		m_hasDomain_Function = "hasDomain_Function";
	}

	public void parsePredicate(OWLClass myPositivePredicateClass, OWLClass myNegativePredicateClass, Ontology myOntology, Domain domain){

		parsePositivePredicate(myPositivePredicateClass, myOntology, domain);
		parseNegativePredicate(myNegativePredicateClass, myOntology, domain);

	}

	public void parsePositivePredicate(OWLClass myPositivePredicateClass, Ontology myOntology, Domain domain){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<PositivePredicate> l_positive_predicate_list = new ArrayList<PositivePredicate>();

		//-- Instances of the class PositivePredicate
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> positivePredicateNodeSet = l_OWLReasoner.getInstances(myPositivePredicateClass, false);
		for (OWLNamedIndividual predicateInstance : positivePredicateNodeSet.getFlattened()) {
			PositivePredicate positivePredicate = new PositivePredicate();
			positivePredicate.setM_individual(predicateInstance);

			//-- Get the parent OWL class for the predicate
			Set<OWLClassExpression> predicateClass = predicateInstance.getTypes(myOntology.getM_OWLOntology());

			//-- Get reference parameter
			OWLDataProperty OWLDP_hasPositivePredicate_ReferenceParameter = l_OWLDataFactory.getOWLDataProperty(IRI.create(l_soapClasses_IRI
					+ "hasPositivePredicate_ReferenceParameter"));
			//-- Get target parameter
			OWLDataProperty OWLDP_hasPositivePredicate_TargetParameter = l_OWLDataFactory.getOWLDataProperty(IRI.create(l_soapClasses_IRI
					+ "hasPositivefPredicate_TargetParameter"));
			//-- Get description
			OWLDataProperty OWLDP_hasPositivePredicate_Description = l_OWLDataFactory.getOWLDataProperty(IRI.create(l_soapClasses_IRI
					+ "hasPositivefPredicate_Description"));

			Set<OWLLiteral> predicate_reference_parameter = l_OWLReasoner.getDataPropertyValues(predicateInstance,
					OWLDP_hasPositivePredicate_ReferenceParameter);

			positivePredicate.setM_reference_parameter(myOntology.cleanIRIDataProperty(predicate_reference_parameter));

			Set<OWLLiteral> predicate_description = l_OWLReasoner.getDataPropertyValues(predicateInstance,
					OWLDP_hasPositivePredicate_Description);
			if (!predicate_description.isEmpty()){
				System.out.println("description: "+myOntology.cleanIRI(predicate_description));
				positivePredicate.setM_description(myOntology.cleanIRIDataProperty(predicate_description).toString());
			}

			Set<OWLLiteral> predicate_target_parameter = l_OWLReasoner.getDataPropertyValues(predicateInstance,
					OWLDP_hasPositivePredicate_TargetParameter);

			//System.out.println("predicate: "+myOntology.cleanIRI(predicateInstance));
			//System.out.println("predicate: "+myOntology.cleanIRI(predicateInstance)+"\n class: "
			//+myOntology.cleanIRI(predicateClass)+"\n reference:"
			//+myOntology.cleanIRIDataProperty(predicate_reference_parameter));
			if (!predicate_target_parameter.isEmpty()){
				positivePredicate.setM_target_parameter(myOntology.cleanIRIDataProperty(predicate_target_parameter));
				//System.out.println(" target: "+myOntology.cleanIRIDataProperty(predicate_target_parameter));	
			}
			l_positive_predicate_list.add(positivePredicate);
			System.out.println("positive predicate: "+myOntology.cleanIRI(predicateInstance)+" : "+myOntology.cleanIRI(predicateClass));	
		}
		domain.setM_positive_predicate_list(l_positive_predicate_list);
	}

	public void parseNegativePredicate(OWLClass myNegativePredicateClass, Ontology myOntology, Domain domain){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<NegativePredicate> l_negative_predicate_list = new ArrayList<NegativePredicate>();
		OWLNamedIndividual positivePredicate = null;
		//-- Instances of the class NegativePredicate
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> negativePredicateNodeSet = l_OWLReasoner.getInstances(myNegativePredicateClass, false);
		for (OWLNamedIndividual predicateInstance : negativePredicateNodeSet.getFlattened()) {
			NegativePredicate predicate = new NegativePredicate();
			predicate.setM_individual(predicateInstance);
			//System.out.println(myOntology.cleanIRI(predicateInstance));

			//-- Get the parent OWL class for the predicate
			Set<OWLClassExpression> predicateClass = predicateInstance.getTypes(myOntology.getM_OWLOntology());

			//-- Get the positive predicate for which this negative predicate is the negation
			OWLObjectProperty OWLOP_hasPredicateClass_PositivePredicate = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI + 
					"has"+myOntology.cleanIRI(predicateClass)+"_PositivePredicate"));
			//System.out.println(myOntology.cleanIRI(predicateClass));
			NodeSet<OWLNamedIndividual> positivePredicateNodeSet = l_OWLReasoner.getObjectPropertyValues(predicateInstance,OWLOP_hasPredicateClass_PositivePredicate);
			for (OWLNamedIndividual PositivePredicateIndividual : positivePredicateNodeSet.getFlattened()) {
				positivePredicate = PositivePredicateIndividual;
				predicate.setM_positive_predicate(positivePredicate);
				System.out.println("negative predicate: "+myOntology.cleanIRI(predicateInstance)+" has positive predicate: "+myOntology.cleanIRI(positivePredicate));	

			}
			l_negative_predicate_list.add(predicate);
			//System.out.println("predicate: "+myOntology.cleanIRI(predicateInstance)+" : "+myOntology.cleanIRI(predicateClass));	
		}
		domain.setM_negative_predicate_list(l_negative_predicate_list);
	}


	public void parseFunction(OWLClass myClass, Ontology myOntology, Domain domain){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<Function> l_function_list = new ArrayList<Function>();
		OWLNamedIndividual positivePredicate = null;

		//-- Instances of the class Function
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> functionNodeSet = l_OWLReasoner.getInstances(myClass, false);
		for (OWLNamedIndividual functionInstance : functionNodeSet.getFlattened()) {
			Function function = new Function();
			function.setM_individual(functionInstance);	
			//-- Set the default target to empty
			//-- This way allows us to have a target parameter, even if it's empty
			function.setM_target_parameter("");
			//-- Set the default description to empty
			//-- This way allows us to have a description, even if it's empty
			function.setM_description("");
			
			
			functionInstance.getDataPropertyValues(myOntology.getM_OWLOntology());
			Map<OWLDataPropertyExpression,Set<OWLLiteral>> functionDataPropertyValues = functionInstance.getDataPropertyValues(myOntology.getM_OWLOntology());
			//printDataPropertyValuesMap(functionDataPropertyValues, myOntology);
			Iterator<Entry<OWLDataPropertyExpression, Set<OWLLiteral>>> it = functionDataPropertyValues.entrySet().iterator();
			while (it.hasNext()) {
				Map.Entry pairs = (Map.Entry)it.next();
				if (myOntology.cleanIRI(pairs.getKey()).compareTo(function.getM_hasFunction_Description())==0)
					function.setM_description(myOntology.cleanIRIDataProperty(pairs.getValue()));
				else if (myOntology.cleanIRI(pairs.getKey()).compareTo(function.getM_hasFunction_ReferenceParameter())==0)
					function.setM_reference_parameter(myOntology.cleanIRIDataProperty(pairs.getValue()));
				else if (myOntology.cleanIRI(pairs.getKey()).compareTo(function.getM_hasFunction_TargetParameter())==0)
					function.setM_target_parameter(myOntology.cleanIRIDataProperty(pairs.getValue()));
				//System.out.println(myOntology.cleanIRI(pairs.getKey()) + " = " + myOntology.cleanIRIDataProperty(pairs.getValue()));
				it.remove(); // avoids a ConcurrentModificationException
			}
			l_function_list.add(function);
			//System.out.println("function data property values: "+functionInstance.getDataPropertyValues(myOntology.getM_OWLOntology()));	
			//Set<OWLDatatype> datatype = functionInstance.getDatatypesInSignature();

			//-- Get reference parameter
			//OWLDataProperty OWLDP_hasFunction_ReferenceParameter = l_OWLDataFactory.getOWLDataProperty(IRI.create(l_soapClasses_IRI
			//		+ "hasFunction_ReferenceParameter"));
			//-- Get target parameter
			//OWLDataProperty OWLDP_hasFunction_TargetParameter = l_OWLDataFactory.getOWLDataProperty(IRI.create(l_soapClasses_IRI
			//		+ "hasFunction_TargetParameter"));

			//Set<OWLLiteral> function_reference_parameter = l_OWLReasoner.getDataPropertyValues(functionInstance,
			//		OWLDP_hasFunction_ReferenceParameter);
			//function.setM_reference_parameter(myOntology.cleanIRIDataProperty(function_reference_parameter));

			//Set<OWLLiteral> function_target_parameter = l_OWLReasoner.getDataPropertyValues(functionInstance,
			//		OWLDP_hasFunction_TargetParameter);
			//if (!function_target_parameter.isEmpty()){
			//function.setM_target_parameter(myOntology.cleanIRIDataProperty(function_target_parameter));
			//}
			//l_function_list.add(function);
		}
		domain.setM_function_list(l_function_list);
	}

	public void readFunctionList(Ontology myOntology, Domain myDomain){
		ArrayList<Function> l_function_list = myDomain.getM_function_list();
		
		for( int x = 0 ; x < l_function_list.size() ; x++ ) { // start from index 0
			Function function = l_function_list.get(x);
			System.out.println("Function: "+myOntology.cleanIRI(function.getM_individual()));
			if (!function.getM_description().isEmpty())
				System.out.println("Description: "+function.getM_description());
			if (!function.getM_reference_parameter().isEmpty())
			System.out.println("Reference: "+function.getM_reference_parameter());
			if (!function.getM_target_parameter().isEmpty())
				System.out.println("Target: "+function.getM_target_parameter());
	    }
	}
	
	public void printDataPropertyValuesMap(Map mp,Ontology myOntology){
		Iterator it = mp.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry)it.next();
			System.out.println(myOntology.cleanIRI(pairs.getKey()) + " = " + myOntology.cleanIRIDataProperty(pairs.getValue()));
			it.remove(); // avoids a ConcurrentModificationException
		}
	}

	public void parseActionBase(OWLClass myClass, Ontology myOntology, Domain domain){
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<Action> l_action_list = new ArrayList<Action>();

		//-- Instances of the class ActionBase
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> ActionBaseNodeSet = l_OWLReasoner.getInstances(myClass, false);
		for (OWLNamedIndividual ActionBaseInstance : ActionBaseNodeSet.getFlattened()) {
			//-- Get the direct class of ActionBaseInstance
			//-- This is used to build the object property "has_<Class of ActionBaseInstance>_Precondition and
			//-- "has_<Class of ActionBaseInstance>_Effect			

			OWLNamedIndividual OWLprecondition = findPrecondition(ActionBaseInstance, myOntology);
			OWLNamedIndividual OWLeffect = findEffect(ActionBaseInstance, myOntology);

			Action action = new Action();
			action.setM_action_individual(ActionBaseInstance);
			Precondition precondition = new Precondition();
			precondition.setM_precondition_individual(OWLprecondition);
			Effect effect = new Effect();
			effect.setM_effect_individual(OWLeffect);
			action.setM_action_precondition(precondition);
			action.setM_action_effect(effect);
			l_action_list.add(action);
		}

		domain.setM_action_list(l_action_list);
	}

	/**
	 * Retrieve the precondition OWLNamedIndividual for the action @a action
	 * @param myAction
	 * @param myOntology
	 * @return The precondition for the action @a myAction
	 */
	public OWLNamedIndividual findPrecondition(OWLNamedIndividual myAction, Ontology myOntology){
		Set<OWLClassExpression> actionClass = myAction.getTypes(myOntology.getM_OWLOntology());
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		OWLNamedIndividual precondition = null;

		String l_hasAction_Precondition = "has"+myOntology.cleanIRI(actionClass)+"_Precondition";
		OWLObjectProperty OWLOP_hasAction_Precondition = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI + l_hasAction_Precondition));
		//System.out.println("Action: "+l_hasAction_Precondition);	

		//-- Individuals for "hasDomain_CreateKit"
		NodeSet<OWLNamedIndividual> ActionPreconditionNodeSet = l_OWLReasoner.getObjectPropertyValues(myAction,OWLOP_hasAction_Precondition);
		for (OWLNamedIndividual PreconditionIndividual : ActionPreconditionNodeSet.getFlattened()) {
			precondition = PreconditionIndividual;
			System.out.println("precondition: "+myOntology.cleanIRI(PreconditionIndividual));	

		}
		return precondition;
	}

	/**
	 * Retrieve the effect OWLNamedIndividual for the action @a myAction
	 * @param myAction
	 * @param myOntology
	 * @return The effect for the action @a myAction
	 */
	public OWLNamedIndividual findEffect(OWLNamedIndividual myAction, Ontology myOntology){
		Set<OWLClassExpression> actionClass = myAction.getTypes(myOntology.getM_OWLOntology());
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		OWLNamedIndividual effect = null;

		String l_hasAction_Effect = "has"+myOntology.cleanIRI(actionClass)+"_Effect";
		OWLObjectProperty OWLOP_hasAction_Effect = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI + l_hasAction_Effect));
		//System.out.println("Action: "+l_hasAction_Precondition);	

		//-- Individuals for "hasDomain_CreateKit"
		NodeSet<OWLNamedIndividual> ActionEffectNodeSet = l_OWLReasoner.getObjectPropertyValues(myAction,OWLOP_hasAction_Effect);
		for (OWLNamedIndividual EffectIndividual : ActionEffectNodeSet.getFlattened()) {
			effect = EffectIndividual;
			System.out.println("effect: "+myOntology.cleanIRI(EffectIndividual));	

		}
		return effect;
	}

	public void findEffect(OWLClass myClass, Ontology myOntology, Domain domain){
		String m_hasAction_Effect;
	}

	public void parseOntology(OWLClass myClass, Ontology myOntology){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();

		//-- Building Object properties
		OWLObjectProperty OWLOP_hasSOAP_Domain = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI+ m_hasSOAP_Domain));	
		OWLObjectProperty OWLOP_hasDomain_Predicate = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI+ m_hasDomain_Predicate));	
		OWLObjectProperty OWLOP_hasDomain_Function = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI+ m_hasDomain_Function));	
		//-- Building Data properties


		ArrayList<Predicate> l_predicate_list= new ArrayList<Predicate>();
		ArrayList<Function> l_function_list = new ArrayList<Function>();
		ArrayList<Action> l_action_list=new ArrayList<Action>();

		//-- Instance of the class SOAP
		NodeSet<OWLNamedIndividual> soapNodeSet = l_OWLReasoner.getInstances(myClass, true);
		for (OWLNamedIndividual soapInstance : soapNodeSet.getFlattened()) {
			System.out.println(soapInstance);
			Soap soap = new Soap();
			soap.setM_soap_individual(soapInstance);


			//-- Individuals for "hasSOAP_Domain"
			NodeSet<OWLNamedIndividual> domainNodeSet = l_OWLReasoner.getObjectPropertyValues(soapInstance,OWLOP_hasSOAP_Domain);
			for (OWLNamedIndividual domainIndividual : domainNodeSet.getFlattened()) {
				System.out.println(domainIndividual);
				Domain domain = new Domain();
				domain.setM_domain_individual(domainIndividual);
				soap.setM_domain(domain);

				//-- Individuals for "hasDomain_Predicate"
				//NodeSet<OWLNamedIndividual> predicateNodeSet = l_OWLReasoner.getObjectPropertyValues(domainIndividual,OWLOP_hasDomain_Predicate);
				//for (OWLNamedIndividual predicateIndividual : predicateNodeSet.getFlattened()) {
				//Predicate predicate = new Predicate();
				//predicate.setM_predicate_individual(predicateIndividual);
				//l_predicate_list.add(predicate);
				//System.out.println("Predicate: "+myOntology.cleanIRI(predicateIndividual));	
				//	}

				//-- Individuals for "hasDomain_Function"
				NodeSet<OWLNamedIndividual> functionNodeSet = l_OWLReasoner.getObjectPropertyValues(domainIndividual,OWLOP_hasDomain_Function);
				for (OWLNamedIndividual functionIndividual : functionNodeSet.getFlattened()) {
					Function function = new Function();
					function.setM_individual(functionIndividual);
					l_function_list.add(function);
					//System.out.println("Function: "+myOntology.cleanIRI(functionIndividual));	
				}
			}


		}
		//System.out.println(myOntology.cleanIRI(soap));

	}

	/**
	 * @return the m_hasDomain_Predicate
	 */
	public static String getM_hasDomain_Predicate() {
		return m_hasDomain_Predicate;
	}

	/**
	 * @param m_hasDomain_Predicate the m_hasDomain_Predicate to set
	 */
	public static void setM_hasDomain_Predicate(String m_hasDomain_Predicate) {
		Reader.m_hasDomain_Predicate = m_hasDomain_Predicate;
	}
}
