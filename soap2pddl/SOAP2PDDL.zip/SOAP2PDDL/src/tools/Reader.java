package tools;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import knowledge.Action;
import knowledge.Domain;
import knowledge.Effect;
import knowledge.Function;
import knowledge.FunctionOperation;
import knowledge.FunctionToFunctionBool;
import knowledge.FunctionToFunctionEqual;
import knowledge.FunctionToFunctionGreater;
import knowledge.FunctionToFunctionGreaterOrEqual;
import knowledge.FunctionToFunctionLess;
import knowledge.FunctionToFunctionLessOrEqual;
import knowledge.NegativePredicate;
import knowledge.Ontology;
import knowledge.PositivePredicate;
import knowledge.Precondition;
import knowledge.Soap;

import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLClassExpression;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLDataProperty;
import org.semanticweb.owlapi.model.OWLDataPropertyExpression;
import org.semanticweb.owlapi.model.OWLIndividual;
import org.semanticweb.owlapi.model.OWLLiteral;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLObjectPropertyExpression;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;

public class Reader {

	public Reader() {
	}

	/**
	 * @brief Retrieve the positive predicates for a given domain
	 * @param myPositivePredicateClass The class of positive predicates
	 * @param myOntology The current ontology
	 * @return A list of positive predicates
	 */
	public ArrayList<PositivePredicate> parsePositivePredicate(OWLClass myPositivePredicateClass, Ontology myOntology){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<PositivePredicate> l_positive_predicate_list = new ArrayList<PositivePredicate>();

		//-- Instances of the class PositivePredicate
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true retrieves only instances of the class (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> owlni_positive_predicate_nodeset = l_OWLReasoner.getInstances(myPositivePredicateClass, false);

		for (OWLNamedIndividual owlni_positive_predicate : owlni_positive_predicate_nodeset.getFlattened()) {
			//-- Create an instance of PositivePredicate
			PositivePredicate positivePredicate = new PositivePredicate();
			//-- Set the OWLIndividual
			positivePredicate.setM_individual(owlni_positive_predicate);
			//-- Set the default reference to empty
			//-- This way allows us to have a value set for the reference parameter
			positivePredicate.setM_reference_parameter("");
			//-- Set the default target to empty
			//-- This way allows us to have a value set for the target parameter
			positivePredicate.setM_target_parameter("");
			//-- Set the default description to empty
			//-- This way allows us to have a value set for the description
			positivePredicate.setM_description("");

			//-- Get all the data properties for each positive predicate
			Map<OWLDataPropertyExpression,Set<OWLLiteral>> positive_predicate_map = 
					owlni_positive_predicate.getDataPropertyValues(myOntology.getM_OWLOntology());

			//-- build the data properties we need to look for
			OWLDataProperty owldp_reference = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
					concat(positivePredicate.getM_hasPositivePredicate_ReferenceParameter())));
			OWLDataProperty owldp_target = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
					concat(positivePredicate.getM_hasPositivePredicate_TargetParameter())));
			OWLDataProperty owldp_description = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
					concat(positivePredicate.getM_hasPositivePredicate_Description())));

			//-- Assign the reference parameter
			if(positive_predicate_map.get(owldp_reference) != null) {
				for(OWLLiteral d : positive_predicate_map.get(owldp_reference)) {
					positivePredicate.setM_reference_parameter(d.getLiteral().toString());
				}
			}

			//-- Assign the target parameter
			if(positive_predicate_map.get(owldp_target) != null) {
				for(OWLLiteral d : positive_predicate_map.get(owldp_target)) {
					positivePredicate.setM_target_parameter(d.getLiteral().toString());
				}
			}

			//-- Assign the description
			if(positive_predicate_map.get(owldp_description) != null) {
				for(OWLLiteral d : positive_predicate_map.get(owldp_description)) {
					positivePredicate.setM_description(d.getLiteral().toString());
				}
			}
			l_positive_predicate_list.add(positivePredicate);
		}
		return l_positive_predicate_list;
	}

	/**
	 * @brief Retrieve the negative predicates for a given domain
	 * @param myNegativePredicateClass The class of negative predicates
	 * @param myOntology The current ontology
	 * @return A list of negative predicates
	 */
	public ArrayList<NegativePredicate> parseNegativePredicate(OWLClass myNegativePredicateClass, Ontology myOntology){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<NegativePredicate> l_negative_predicate_list = new ArrayList<NegativePredicate>();

		//-- Instances of the class NegativePredicate
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> owlni_negative_predicate_nodeset = l_OWLReasoner.getInstances(myNegativePredicateClass, false);
		for (OWLNamedIndividual owlni_negative_predicate : owlni_negative_predicate_nodeset.getFlattened()) {
			//-- Create an instance of NegativePredicate
			NegativePredicate predicate = new NegativePredicate();
			//-- Set the OWLIndividual
			predicate.setM_individual(owlni_negative_predicate);

			//-- Get the parent OWL class for owlni_negative_predicate
			//-- This is necessary to build the object property
			Set<OWLClassExpression> predicateClass = owlni_negative_predicate.getTypes(myOntology.getM_OWLOntology());

			//-- build the object property based on the class of predicateInstance
			OWLObjectProperty owl_op_positivePredicate = l_OWLDataFactory.getOWLObjectProperty(IRI.create(myOntology.getM_soapClasses_IRI() + 
					"has"+myOntology.cleanIRI(predicateClass)+"_PositivePredicate"));

			NodeSet<OWLNamedIndividual> owlni_positive_predicate_nodeset = l_OWLReasoner.
					getObjectPropertyValues(owlni_negative_predicate,owl_op_positivePredicate);
			for (OWLNamedIndividual owlni_positive_predicate : owlni_positive_predicate_nodeset.getFlattened()) 
				predicate.setM_positive_predicate(owlni_positive_predicate);

			l_negative_predicate_list.add(predicate);
			//System.out.println("predicate: "+myOntology.cleanIRI(predicateInstance)+" : "+myOntology.cleanIRI(predicateClass));	
		}
		return l_negative_predicate_list;
	}


	public ArrayList<Function> parseFunction(OWLClass myFunctionClass, Ontology myOntology){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<Function> l_function_list = new ArrayList<Function>();

		//-- Instances of the class NegativePredicate
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> functionNodeSet = l_OWLReasoner.getInstances(myFunctionClass, false);
		for (OWLNamedIndividual functionInstance : functionNodeSet.getFlattened()) {
			//-- Create an instance of Function
			Function function = new Function();
			//-- Set the OWLIndividual for function
			function.setM_individual(functionInstance);
			//-- Set the default reference to empty
			//-- This way allows us to have a reference parameter, even if it's empty
			function.setM_reference_parameter("");
			//-- Set the default target to empty
			//-- This way allows us to have a target parameter, even if it's empty
			function.setM_target_parameter("");
			//-- Set the default description to empty
			//-- This way allows us to have a description, even if it's empty
			function.setM_description("");

			//-- Get all the data properties for each function
			Map<OWLDataPropertyExpression,Set<OWLLiteral>> function_map = 
					functionInstance.getDataPropertyValues(myOntology.getM_OWLOntology());

			//-- build the data properties we need to look for
			//-- Data property to get the reference parameter
			OWLDataProperty reference_dp = l_OWLDataFactory.getOWLDataProperty(IRI.
					create(myOntology.getM_soapClasses_IRI().
							concat(function.getM_hasFunction_ReferenceParameter())));
			//-- Data property to get the target parameter
			OWLDataProperty target_dp = l_OWLDataFactory.getOWLDataProperty(IRI.
					create(myOntology.getM_soapClasses_IRI().
							concat(function.getM_hasFunction_TargetParameter())));
			//-- Data property to get the description
			OWLDataProperty description_dp = l_OWLDataFactory.getOWLDataProperty(IRI.
					create(myOntology.getM_soapClasses_IRI().
							concat(function.getM_hasFunction_Description())));
			//-- Find and Assign the reference parameter
			if(function_map.get(reference_dp) != null) {
				for(OWLLiteral d : function_map.get(reference_dp)) {
					function.setM_reference_parameter(d.getLiteral().toString());
				}
			}
			//-- Find and assign the target parameter
			if(function_map.get(target_dp) != null) {
				for(OWLLiteral d : function_map.get(target_dp)) {
					function.setM_target_parameter(d.getLiteral().toString());
				}
			}
			//-- Find and assign the description
			if(function_map.get(description_dp) != null) {
				for(OWLLiteral d : function_map.get(description_dp)) {
					function.setM_description(d.getLiteral().toString());
				}
			}
			l_function_list.add(function);
		}
		return l_function_list;
	}

	/**
	 * @brief Find all the requirements for a given Domain
	 * @param myOntology The current ontology
	 * @param myDomain The domain for which we are looking the requirements
	 * @return A list of requirements
	 */
	public ArrayList<String> parseDomainRequirement(Ontology myOntology, Domain myDomain){
		ArrayList<String> l_requirement = new ArrayList<String>();
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLDataProperty requirement_dp = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
				concat(myDomain.getM_DPhasDomain_Requirement())));

		OWLIndividual domainIndividual = myDomain.getM_individual();
		Map<OWLDataPropertyExpression,Set<OWLLiteral>> domainDataPropertyValues = domainIndividual.
				getDataPropertyValues(myOntology.getM_OWLOntology());

		if(domainDataPropertyValues.get(requirement_dp) != null) {
			for(OWLLiteral d : domainDataPropertyValues.get(requirement_dp)) {
				//System.out.println(d.getLiteral());
				l_requirement.add(d.getLiteral().toString());
			}
		}
		return l_requirement;
	}

	/**
	 * @brief Find all the variables for a given Domain
	 * @param myOntology The current ontology
	 * @param myDomain The domain for which we are looking the variables
	 * @return A list of variables
	 */
	public ArrayList<String> parseDomainVariable(Ontology myOntology, Domain myDomain){
		ArrayList<String> l_variable = new ArrayList<String>();
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLDataProperty variable = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().concat(myDomain.getM_DPhasDomain_Variable())));


		OWLIndividual domainIndividual = myDomain.getM_individual();
		Map<OWLDataPropertyExpression,Set<OWLLiteral>> domainDataPropertyValues = domainIndividual.getDataPropertyValues(myOntology.getM_OWLOntology());

		if(domainDataPropertyValues.get(variable) != null) {
			for(OWLLiteral d : domainDataPropertyValues.get(variable)) {
				//System.out.println(d.getLiteral());
				l_variable.add(d.getLiteral().toString());
			}
		}
		return l_variable;
	}

	/**
	 * @brief Parse the domain and retrieve all the object and data properties
	 * @param mySoap
	 * @param mySoapInstance
	 * @param myOntology
	 * @return
	 */
	public Domain parseDomain(Soap mySoap, OWLNamedIndividual mySoapInstance, Ontology myOntology){
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		OWLClass positivePredicateOWLClass = myOntology.getClass(myOntology.getM_PositivePredicateClass());
		OWLClass negativePredicateOWLClass = myOntology.getClass(myOntology.getM_NegativePredicateClass());
		OWLClass functionOWLClass = myOntology.getClass(myOntology.getM_FunctionClass());
		OWLClass actionBaseOWLClass = myOntology.getClass(myOntology.getM_ActionBaseClass());
		Domain domain = new Domain();

		String l_OPhasSOAP_Domain = mySoap.getM_OPhasSOAP_Domain();
		OWLObjectProperty owlObjectProperty = l_OWLDataFactory.getOWLObjectProperty(IRI.create(myOntology.getM_soapClasses_IRI() + l_OPhasSOAP_Domain));
		//System.out.println("Action: "+l_hasAction_Precondition);	

		//-- Individuals for "hasDomain_CreateKit"
		NodeSet<OWLNamedIndividual> DomainNodeSet = l_OWLReasoner.getObjectPropertyValues(mySoapInstance,owlObjectProperty);
		for (OWLNamedIndividual domainIndividual : DomainNodeSet.getFlattened()) {
			//System.out.println("domain: "+myOntology.cleanIRI(domainIndividual));	
			domain.setM_individual(domainIndividual);
			//-- Get the requirements for the domain
			//parseDomainRequirement(myOntology, domain);
			domain.setM_requirement_list(parseDomainRequirement(myOntology, domain));
			//-- Get the variables for the domain
			domain.setM_variable_list(parseDomainVariable(myOntology, domain));
			//-- Get the positive predicates
			domain.setM_positive_predicate_list(parsePositivePredicate(positivePredicateOWLClass, myOntology));
			//-- Get the negative predicates
			domain.setM_negative_predicate_list(parseNegativePredicate(negativePredicateOWLClass, myOntology));
			//-- Get the functions
			domain.setM_function_list(parseFunction(functionOWLClass, myOntology));
			//-- Get the actions
			domain.setM_action_list(parseActionBase(actionBaseOWLClass, myOntology, domain));
			//parseActionBase(actionBaseOWLClass, myOntology, domain);

		}
		return domain;
	}

	/**
	 * @brief Parse the soap ontology starting from the OWL class SOAP.
	 * @param myClass
	 * @param myOntology
	 */
	public Soap parseSOAP(OWLClass myClass, Ontology myOntology){
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Soap soap = new Soap();

		//-- Instances of the class SOAP
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> owlni_soap_nodeset = l_OWLReasoner.getInstances(myClass, true);

		for (OWLNamedIndividual owlni_soap : owlni_soap_nodeset.getFlattened()) {
			soap.setM_individual(owlni_soap);
			//-- Get the domain for soapInstance
			soap.setM_domain(parseDomain(soap, owlni_soap,myOntology));
		}
		return soap;
	}

	public void displayVariables(ArrayList<String> myList){
		System.out.println("\n-----------------Domain Variables ----------------");
		for( int i=0; i<myList.size(); i++ )
			System.out.println("  "+myList.get(i));
	}

	public void displayRequirements(ArrayList<String> myList){
		System.out.println("\n-----------------Domain Requirements ----------------");
		for( int i=0; i<myList.size(); i++ )
			System.out.println("  "+myList.get(i));
	}

	public void displayFunctions(ArrayList<Function> myList,Ontology myOntology){
		System.out.println("\n-----------------Functions ----------------");
		for( int i=0; i<myList.size(); i++ ){
			Function function = myList.get(i);

			if (!function.getM_target_parameter().isEmpty()){
				System.out.println(" "+function.getM_description()+
						"\n "+myOntology.cleanIRI(function.getM_individual())+
						"("+function.getM_reference_parameter()+
						","+function.getM_target_parameter()+
						")");
			}
			else{
				System.out.println(" "+function.getM_description()+
						"\n "+myOntology.cleanIRI(function.getM_individual())+
						"("+function.getM_reference_parameter()+")");
			}
		}
	}

	public void displayPositivePredicates(ArrayList<PositivePredicate> myList,Ontology myOntology){
		System.out.println("\n-----------------Positive Predicates ----------------");
		for( int i=0; i<myList.size(); i++ ){
			PositivePredicate positivePredicate = myList.get(i);

			if (!positivePredicate.getM_target_parameter().isEmpty()){
				System.out.println(" "+positivePredicate.getM_description()+
						"\n  "+myOntology.cleanIRI(positivePredicate.getM_individual())+
						"("+positivePredicate.getM_reference_parameter()+
						","+positivePredicate.getM_target_parameter()+
						")");
			}
			else{
				System.out.println(" "+positivePredicate.getM_description()+
						"\n  "+myOntology.cleanIRI(positivePredicate.getM_individual())+
						"("+positivePredicate.getM_reference_parameter()+
						")");
			}
		}
	}
	public void displaySoap(Ontology myOntology, Soap mySoap){
		OWLIndividual soapIndividual = mySoap.getM_individual(); 
		System.out.println("Soap: "+myOntology.cleanIRI(soapIndividual));
		Domain domain = mySoap.getM_domain();
		System.out.println(" +Domain: "+myOntology.cleanIRI(domain.getM_individual()));

		displayVariables(domain.getM_variable_list());
		displayRequirements(domain.getM_requirement_list());
		displayFunctions(domain.getM_function_list(),myOntology);
		displayPositivePredicates(domain.getM_positive_predicate_list(),myOntology);
		displayAction(myOntology,domain);
	}

	public void displayPrecondition(Precondition myPrecondition, Ontology myOntology){
		System.out.println("\n +precondition: "+myOntology.cleanIRI(myPrecondition.getM_individual()));
		ArrayList<String> l_predicate_list = myPrecondition.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myPrecondition.getM_f2f_list();
		ArrayList<FunctionOperation> l_function_operation_list = myPrecondition.getM_function_operation_list();

		//-- Display all the predicates
		if (!l_predicate_list.isEmpty()){
			for (int k=0; k<l_predicate_list.size(); k++){
				System.out.println("   +predicate: "+l_predicate_list.get(k));
			}
		}

		//-- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()){
			for (int i=0; i<l_f2f_list.size(); i++){
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				System.out.println("   +f2fbool: "+f1+" "+expression+" "+f2);
			}
		}


		//-- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()){
			for (int i=0; i<l_function_operation_list.size(); i++){
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				System.out.println("   +fop: "+l_expression+" "+l_function+" "+l_value);
			}
		}
	}

	public void displayEffect(Effect myEffect, Ontology myOntology){
		System.out.println("+effect: "+myOntology.cleanIRI(myEffect.getM_individual()));
		ArrayList<String> l_predicate_list = myEffect.getM_predicate_list();
		ArrayList<FunctionToFunctionBool> l_f2f_list = myEffect.getM_f2f_list();
		ArrayList<FunctionOperation> l_function_operation_list = myEffect.getM_function_operation_list();

		//-- Display all the predicates
		if (!l_predicate_list.isEmpty()){
			for (int k=0; k<l_predicate_list.size(); k++){
				System.out.println("   +predicate: "+l_predicate_list.get(k));
			}
		}

		//-- Display all FunctionToFunctionBool
		if (!l_f2f_list.isEmpty()){
			for (int i=0; i<l_f2f_list.size(); i++){
				FunctionToFunctionBool f2f = l_f2f_list.get(i);
				String f1 = f2f.getF1();
				String f2 = f2f.getF2();
				String expression = f2f.getExpression();
				System.out.println("   +f2fbool: "+f1+" "+expression+" "+f2);
			}
		}


		//-- Display all FunctionOperation
		if (!l_function_operation_list.isEmpty()){
			for (int i=0; i<l_function_operation_list.size(); i++){
				FunctionOperation fop = l_function_operation_list.get(i);
				String l_function = fop.getM_function();
				String l_expression = fop.getM_expression();
				Integer l_value = fop.getM_value();
				System.out.println("   +fop: "+l_expression+" "+l_function+" "+l_value);
			}
		}
	}
	/**
	 * @brief Display actions
	 * @param myOntology
	 * @param myDomain
	 */
	public void displayAction(Ontology myOntology, Domain myDomain){
		System.out.print("\n-----------------Actions----------------");
		//-- Display the list of parameters
		ArrayList<Action> l_action_list = myDomain.getM_action_list();
		for(int i=0; i<l_action_list.size(); i++ ){
			Action action = l_action_list.get(i);
			System.out.print("\n"+myOntology.cleanIRI(action.getM_individual())+"(");
			ArrayList<String> parameter_set_list = action.getM_parameter_set();
			//System.out.println("(");
			for (int j=0; j<parameter_set_list.size(); j++){
				if (j==parameter_set_list.size()-1)
					System.out.print(parameter_set_list.get(j)+")");
				else
					System.out.print(parameter_set_list.get(j)+",");
			}
			displayPrecondition(action.getM_action_precondition(), myOntology);
			displayEffect(action.getM_action_effect(), myOntology);
		}
	}


	public void printDataPropertyValuesMap(Map mp,Ontology myOntology){
		Iterator it = mp.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pairs = (Map.Entry)it.next();
			System.out.println(myOntology.cleanIRI(pairs.getKey()) + " = " + myOntology.cleanIRIDataProperty(pairs.getValue()));
			it.remove(); // avoids a ConcurrentModificationException
		}
	}

	public ArrayList<Action> parseActionBase(OWLClass myClass, Ontology myOntology, Domain domain){
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		ArrayList<Action> l_action_list = new ArrayList<Action>();

		//-- Instances of the class ActionBase
		//-- Setting the flag to false in getInstances(myClass, false) retrieves instances in subclasses of myClass
		//-- setting the flag to true only retrieves direct instances (not the ones in subclasses)
		NodeSet<OWLNamedIndividual> ActionBaseNodeSet = l_OWLReasoner.getInstances(myClass, false);

		for (OWLNamedIndividual owlni_action : ActionBaseNodeSet.getFlattened()) {
			Action action = new Action();
			action.setM_individual(owlni_action);
			//-- Get the direct class of ActionBaseInstance
			//-- This is used to build the object property "has_<Class of ActionBaseInstance>_Precondition and
			//-- "has_<Class of ActionBaseInstance>_Effect			
			Precondition precondition = findPrecondition(owlni_action, myOntology);
			Effect effect = findEffect(owlni_action, myOntology);
			ArrayList<String> l_parameter_set=findActionParameterSet(myOntology, action);

			//-- Set action's parameter_set
			action.setM_parameter_set(l_parameter_set);
			//-- Set action's precondition
			action.setM_action_precondition(precondition);
			//-- Set action's effect
			action.setM_action_effect(effect);
			//-- Add current action to l_action_list
			l_action_list.add(action);
		}
		return l_action_list;
	}

	public ArrayList<String> findActionParameterSet(Ontology myOntology, Action myAction){
		Map<Integer, String> parameterSet_map = new HashMap<Integer, String>();

		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Set<OWLClassExpression> actionClass = myAction.getM_individual().getTypes(myOntology.getM_OWLOntology());
		OWLNamedIndividual action_individual = myAction.getM_individual();

		String l_hasAction_ParameterSet = "has"+myOntology.cleanIRI(actionClass)+"_ActionParameterSet";
		//System.out.println("l_hasAction_ParameterSet: "+l_hasAction_ParameterSet);	
		OWLObjectProperty owl_op_parameter_set = l_OWLDataFactory.getOWLObjectProperty(IRI.create(myOntology.getM_soapClasses_IRI() + l_hasAction_ParameterSet));


		NodeSet<OWLNamedIndividual> ActionParameterSetNodeSet = l_OWLReasoner.getObjectPropertyValues(action_individual,owl_op_parameter_set);

		//-- For each action parameter set for the current action
		for (OWLNamedIndividual oni_parameter_set : ActionParameterSetNodeSet.getFlattened()) {

			//System.out.println("action parameter set: "+myOntology.cleanIRI(oni_parameter_set));	
			//-- Retrieve the parameter
			//-- Get all the data properties for each function
			Map<OWLDataPropertyExpression,Set<OWLLiteral>> dataPropertyValues = oni_parameter_set.getDataPropertyValues(myOntology.getM_OWLOntology());

			//-- build the data properties we need to look for
			OWLDataProperty odp_parameter = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
					concat(myAction.getM_OP_hasActionParameterSet_ActionParameter())));
			OWLDataProperty odp_position = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
					concat(myAction.getM_OP_hasActionParameterSet_ActionParameterPosition())));

			//-- store the parameter and its position in a Map<Integer,String>
			//-- The map will be read later to place the parameter at the right position in a list
			if(dataPropertyValues.get(odp_parameter) != null) {
				for(OWLLiteral d : dataPropertyValues.get(odp_parameter)) {
					//System.out.println("  +parameter: "+d.getLiteral().toString());
					//-- Get the position
					if(dataPropertyValues.get(odp_position) != null) {
						for(OWLLiteral d1 : dataPropertyValues.get(odp_position)) {
							String positionString = d1.getLiteral().toString();
							//-- Convert the string into Integer
							int positionInt=Integer.parseInt(positionString);
							//System.out.println("  +position: "+positionInt);
							parameterSet_map.put(positionInt, d.getLiteral().toString());
							//l_parameter_set.add(positionInt-1,d.getLiteral().toString());

						}
					}

				}
			}

		}
		//return parameterSet_map;

		int map_size=parameterSet_map.size();

		//-- Create an arraylist of size map_size
		ArrayList<String> parameter_list = new ArrayList<String>(map_size);
		//-- Initialize this list
		//for (int i=0; i<map_size; i++){
		//System.out.println("i:"+i);
		//	parameter_list.add("");
		//}
		//System.out.println("Size of list 1: "+parameter_list.size());
		//-- Iterate through parameterSet_map and place each parameter at its position in parameter_list
		Iterator it = parameterSet_map.entrySet().iterator();
		while (it.hasNext()) {

			Map.Entry pairs = (Map.Entry)it.next();
			parameter_list.add((String) pairs.getValue());
			it.remove(); // avoids a ConcurrentModificationException
		}

		//-- Set action's parameter list
		return(parameter_list);
	}
	/**
	 * Retrieve the precondition OWLNamedIndividual for the action @a action
	 * @param myAction
	 * @param myOntology
	 * @return The precondition for the action @a myAction
	 */
	public Precondition findPrecondition(OWLNamedIndividual myAction, Ontology myOntology){
		Set<OWLClassExpression> actionClass = myAction.getTypes(myOntology.getM_OWLOntology());
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Precondition precondition = new Precondition();

		//-- Build the object property that points to the precondition
		String l_hasAction_precondition = "has"+myOntology.cleanIRI(actionClass)+"_Precondition";
		OWLObjectProperty op_precondition = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI + l_hasAction_precondition));


		//-- Individuals for "hasAction_Precondition"
		NodeSet<OWLNamedIndividual> ActionPreconditionNodeSet = l_OWLReasoner.getObjectPropertyValues(myAction,op_precondition);
		for (OWLNamedIndividual named_indiv_precondition : ActionPreconditionNodeSet.getFlattened()) {

			precondition.setM_individual(named_indiv_precondition);
			//-- Get the object property values for named_indiv_precondition
			parsePreconditionObjectPropertyValues(precondition, myOntology);

		}
		return precondition;
	}

	public void parsePreconditionObjectPropertyValues(Precondition myPrecondition, Ontology myOntology){
		ArrayList<String> l_predicate_list = new ArrayList<String>();
		ArrayList<FunctionToFunctionBool> l_f2f_list = new ArrayList<FunctionToFunctionBool>();
		ArrayList<FunctionOperation> l_function_operation_list = new ArrayList<FunctionOperation>();

		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Map<OWLObjectPropertyExpression,Set<OWLIndividual>> precondition_opv = myPrecondition.getM_individual().getObjectPropertyValues(myOntology.getM_OWLOntology());

		//-- Get all the object property values for precondition_opv
		for(OWLObjectPropertyExpression prop: precondition_opv.keySet()) {

			for(OWLIndividual d : precondition_opv.get(prop)) {
				//Set<OWLClassExpression> myClass = d.getTypes(myOntology.getM_OWLOntology());
				//System.out.println("\nobject property: "+d.toStringID());

				// get types
				for(OWLClassExpression c: d.getTypes(myOntology.getM_OWLOntology())) {
					OWLClass currentClass = c.asOWLClass();
					String currentClass_s = myOntology.cleanIRI(c.asOWLClass());
					NodeSet<OWLClass> superClassesNodeSet = l_OWLReasoner.getSuperClasses(currentClass, true);

					//System.out.println("class: "+c.asOWLClass().toStringID());
					for (OWLClass oc : superClassesNodeSet.getFlattened()){
						String superClass_s = myOntology.cleanIRI(oc.toStringID());

						//System.out.println("super class: "+superClass_s);

						//-----------------------------------------------------
						//-- Add the predicates to l_predicate_list
						//-----------------------------------------------------
						if (superClass_s.compareTo(myOntology.getM_PositivePredicateClass())==0 
								|| superClass_s.compareTo(myOntology.getM_NegativePredicateClass())==0){
							l_predicate_list.add(myOntology.cleanIRI(d.toStringID()));
						}

						//-----------------------------------------------------
						//-- Look for FunctionOperation
						//-----------------------------------------------------
						if (superClass_s.compareTo(myOntology.getM_FunctionOperation())==0){
							FunctionOperation function_operation = new FunctionOperation();

							function_operation.setM_individual(d);

							//--Get the function
							//-- Build object predicate hasFunctionOperation_Function
							String oop_s="has"+currentClass_s+"_Function";
							OWLObjectProperty oop = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + oop_s));
							NodeSet<OWLNamedIndividual> oni_function_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,oop);
							for (OWLNamedIndividual oni_function : oni_function_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								function_operation.setM_function(myOntology.cleanIRI(oni_function));
							}

							//-- Get all the data properties for 
							Map<OWLDataPropertyExpression,Set<OWLLiteral>> dp_values = 
									d.getDataPropertyValues(myOntology.getM_OWLOntology());

							//--Get the Value
							//-- build the data properties for Value
							OWLDataProperty dp_value = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
									concat(function_operation.getM_hasFunctionOperation_Value())));
							//-- Retrieve the value
							if(dp_values.get(dp_value) != null) {
								for(OWLLiteral owl_literal : dp_values.get(dp_value)) {
									String value_s = owl_literal.getLiteral().toString();
									int value_i =Integer.parseInt(value_s);
									function_operation.setM_value(value_i);
								}
							}

							//--Get the Expression
							//-- build the data properties for Expression
							OWLDataProperty dp_expression = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
									concat(function_operation.getM_hasFunctionOperation_Expression())));
							//-- Retrieve the expression
							if(dp_values.get(dp_expression) != null) {
								for(OWLLiteral owl_literal : dp_values.get(dp_expression)) {
									String expression_s = owl_literal.getLiteral().toString();
									function_operation.setM_expression(expression_s);
								}
							}

							l_function_operation_list.add(function_operation);
						}

						//-----------------------------------------------------
						//-- Add the f2f to l_f2f_list
						//-----------------------------------------------------
						//-- Check if the class is of type FunctionToFunctionLess
						if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionLess())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionLess f2fLess = new FunctionToFunctionLess();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								f2fLess.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								//System.out.println(oni_f2);
								f2fLess.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression="<";
							f2fLess.setExpression(expression);

							//-- Add f2fLess to l_f2f_list
							l_f2f_list.add(f2fLess);
						}

						//-- Check if the class is of type FunctionToFunctionLessOrEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionLessOrEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionLessOrEqual f2fLessOrEqual = new FunctionToFunctionLessOrEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								f2fLessOrEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								//System.out.println(oni_f2);
								f2fLessOrEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression="<=";
							f2fLessOrEqual.setExpression(expression);

							//-- Add f2fLessOrEqual to l_f2f_list
							l_f2f_list.add(f2fLessOrEqual);
						}

						//-- Check if the class is of type FunctionToFunctionGreater
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionGreater())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionGreater f2fGreater = new FunctionToFunctionGreater();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								f2fGreater.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								//System.out.println(oni_f2);
								f2fGreater.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression=">";
							f2fGreater.setExpression(expression);

							//-- Add f2fGreater to l_f2f_list
							l_f2f_list.add(f2fGreater);
						}

						//-- Check if the class is of type FunctionToFunctionGreaterOrEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionGreaterOrEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionGreaterOrEqual f2fGreaterOrEqual = new FunctionToFunctionGreaterOrEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								f2fGreaterOrEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								//System.out.println(oni_f2);
								f2fGreaterOrEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression=">=";
							f2fGreaterOrEqual.setExpression(expression);

							//-- Add f2fGreaterOrEqual to l_f2f_list
							l_f2f_list.add(f2fGreaterOrEqual);
						}

						//-- Check if the class is of type FunctionToFunctionEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionEqual f2fEqual = new FunctionToFunctionEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								f2fEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								//System.out.println(oni_f2);
								f2fEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression="=";
							f2fEqual.setExpression(expression);

							//-- Add f2fEqual to l_f2f_list
							l_f2f_list.add(f2fEqual);
						}
					}
				}
			}
		}
		myPrecondition.setM_predicate_list(l_predicate_list);
		myPrecondition.setM_f2f_list(l_f2f_list);
		myPrecondition.setM_function_operation_list(l_function_operation_list);
	}





	/**
	 * Retrieve the precondition OWLNamedIndividual for the action @a action
	 * @param myAction
	 * @param myOntology
	 * @return The precondition for the action @a myAction
	 */
	public Effect findEffect(OWLNamedIndividual myAction, Ontology myOntology){
		Set<OWLClassExpression> actionClass = myAction.getTypes(myOntology.getM_OWLOntology());
		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		String l_soapClasses_IRI = myOntology.getM_soapClasses_IRI();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Effect effect = new Effect();

		//-- Build the object property that points to the effect
		String l_hasAction_effect = "has"+myOntology.cleanIRI(actionClass)+"_Effect";
		OWLObjectProperty op_effect = l_OWLDataFactory.getOWLObjectProperty(IRI.create(l_soapClasses_IRI + l_hasAction_effect));


		//-- Individuals for "hasAction_Effect"
		NodeSet<OWLNamedIndividual> ActionEffectNodeSet = l_OWLReasoner.getObjectPropertyValues(myAction,op_effect);
		for (OWLNamedIndividual named_indiv_effect : ActionEffectNodeSet.getFlattened()) {

			effect.setM_individual(named_indiv_effect);
			//-- Get the object property values for named_indiv_effect
			parseEffectObjectPropertyValues(effect, myOntology);

		}
		return effect;
	}

	public void parseEffectObjectPropertyValues(Effect myEffect, Ontology myOntology){
		ArrayList<String> l_predicate_list = new ArrayList<String>();
		ArrayList<FunctionToFunctionBool> l_f2f_list = new ArrayList<FunctionToFunctionBool>();
		ArrayList<FunctionOperation> l_function_operation_list = new ArrayList<FunctionOperation>();

		OWLDataFactory l_OWLDataFactory = myOntology.getM_OWLDataFactory();
		OWLReasoner l_OWLReasoner = myOntology.getM_OWLReasoner();
		Map<OWLObjectPropertyExpression,Set<OWLIndividual>> effect_opv = 
				myEffect.getM_individual().getObjectPropertyValues(myOntology.getM_OWLOntology());

		//-- Get all the object property values for effect_opv
		for(OWLObjectPropertyExpression prop: effect_opv.keySet()) {

			for(OWLIndividual d : effect_opv.get(prop)) {
				//Set<OWLClassExpression> myClass = d.getTypes(myOntology.getM_OWLOntology());
				//System.out.println("\nobject property: "+d.toStringID());

				// get types
				for(OWLClassExpression c: d.getTypes(myOntology.getM_OWLOntology())) {
					OWLClass currentClass = c.asOWLClass();
					String currentClass_s = myOntology.cleanIRI(c.asOWLClass());
					NodeSet<OWLClass> superClassesNodeSet = l_OWLReasoner.getSuperClasses(currentClass, true);

					//System.out.println("class: "+c.asOWLClass().toStringID());
					for (OWLClass oc : superClassesNodeSet.getFlattened()){
						String superClass_s = myOntology.cleanIRI(oc.toStringID());

						//System.out.println("super class: "+superClass_s);

						//-----------------------------------------------------
						//-- Add the predicates to l_predicate_list
						//-----------------------------------------------------
						if (superClass_s.compareTo(myOntology.getM_PositivePredicateClass())==0 
								|| superClass_s.compareTo(myOntology.getM_NegativePredicateClass())==0){
							l_predicate_list.add(myOntology.cleanIRI(d.toStringID()));
						}

						//-----------------------------------------------------
						//-- Look for FunctionOperation
						//-----------------------------------------------------
						if (superClass_s.compareTo(myOntology.getM_FunctionOperation())==0){
							FunctionOperation function_operation = new FunctionOperation();

							function_operation.setM_individual(d);

							//--Get the function
							//-- Build object predicate hasFunctionOperation_Function
							String oop_s="has"+currentClass_s+"_Function";
							OWLObjectProperty oop = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + oop_s));
							NodeSet<OWLNamedIndividual> oni_function_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,oop);
							for (OWLNamedIndividual oni_function : oni_function_nodeset.getFlattened()){
								//System.out.println(oni_f1);
								function_operation.setM_function(myOntology.cleanIRI(oni_function));
							}

							//-- Get all the data properties for 
							Map<OWLDataPropertyExpression,Set<OWLLiteral>> dp_values = 
									d.getDataPropertyValues(myOntology.getM_OWLOntology());

							//--Get the Value
							//-- build the data properties for Value
							OWLDataProperty dp_value = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
									concat(function_operation.getM_hasFunctionOperation_Value())));
							//-- Retrieve the value
							if(dp_values.get(dp_value) != null) {
								for(OWLLiteral owl_literal : dp_values.get(dp_value)) {
									String value_s = owl_literal.getLiteral().toString();
									int value_i =Integer.parseInt(value_s);
									function_operation.setM_value(value_i);
								}
							}

							//--Get the Expression
							//-- build the data properties for Expression
							OWLDataProperty dp_expression = l_OWLDataFactory.getOWLDataProperty(IRI.create(myOntology.getM_soapClasses_IRI().
									concat(function_operation.getM_hasFunctionOperation_Expression())));
							//-- Retrieve the expression
							if(dp_values.get(dp_expression) != null) {
								for(OWLLiteral owl_literal : dp_values.get(dp_expression)) {
									String expression_s = owl_literal.getLiteral().toString();
									function_operation.setM_expression(expression_s);
								}
							}

							l_function_operation_list.add(function_operation);
						}

						//-----------------------------------------------------
						//-- Add the f2f to l_f2f_list
						//-----------------------------------------------------
						//-- Check if the class is of type FunctionToFunctionLess
						if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionLess())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionLess f2fLess = new FunctionToFunctionLess();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								System.out.println(oni_f1);
								f2fLess.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								System.out.println(oni_f2);
								f2fLess.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression="=";
							f2fLess.setExpression(expression);

							//-- Add f2fLess to l_f2f_list
							l_f2f_list.add(f2fLess);
						}

						//-- Check if the class is of type FunctionToFunctionLessOrEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionLessOrEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionLessOrEqual f2fLessOrEqual = new FunctionToFunctionLessOrEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								System.out.println(oni_f1);
								f2fLessOrEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								System.out.println(oni_f2);
								f2fLessOrEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression="<=";
							f2fLessOrEqual.setExpression(expression);

							//-- Add f2fLessOrEqual to l_f2f_list
							l_f2f_list.add(f2fLessOrEqual);
						}

						//-- Check if the class is of type FunctionToFunctionGreater
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionGreater())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionGreater f2fGreater = new FunctionToFunctionGreater();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								System.out.println(oni_f1);
								f2fGreater.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								System.out.println(oni_f2);
								f2fGreater.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression=">";
							f2fGreater.setExpression(expression);

							//-- Add f2fGreater to l_f2f_list
							l_f2f_list.add(f2fGreater);
						}

						//-- Check if the class is of type FunctionToFunctionGreaterOrEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionGreaterOrEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionGreaterOrEqual f2fGreaterOrEqual = new FunctionToFunctionGreaterOrEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								System.out.println(oni_f1);
								f2fGreaterOrEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								System.out.println(oni_f2);
								f2fGreaterOrEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression=">=";
							f2fGreaterOrEqual.setExpression(expression);

							//-- Add f2fGreaterOrEqual to l_f2f_list
							l_f2f_list.add(f2fGreaterOrEqual);
						}

						//-- Check if the class is of type FunctionToFunctionEqual
						else if (superClass_s.compareTo(myOntology.getM_FunctionToFunctionEqual())==0){
							//System.out.println(d.toStringID());
							FunctionToFunctionEqual f2fEqual = new FunctionToFunctionEqual();
							//-- get the first function
							String op1="has"+currentClass_s+"_F1";
							OWLObjectProperty op_f1 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op1));
							NodeSet<OWLNamedIndividual> oni_f1_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f1);
							for (OWLNamedIndividual oni_f1 : oni_f1_nodeset.getFlattened()){
								System.out.println(oni_f1);
								f2fEqual.setF1(myOntology.cleanIRI(oni_f1));
							}
							//-- get the second function
							String op2="has"+currentClass_s+"_F2";
							OWLObjectProperty op_f2 = l_OWLDataFactory.getOWLObjectProperty
									(IRI.create(myOntology.getM_soapClasses_IRI() + op2));
							NodeSet<OWLNamedIndividual> oni_f2_nodeset = l_OWLReasoner.getObjectPropertyValues((OWLNamedIndividual) d,op_f2);
							for (OWLNamedIndividual oni_f2 : oni_f2_nodeset.getFlattened()){
								System.out.println(oni_f2);
								f2fEqual.setF2(myOntology.cleanIRI(oni_f2));
							}
							//-- create the expression
							String expression=">=";
							f2fEqual.setExpression(expression);

							//-- Add f2fEqual to l_f2f_list
							l_f2f_list.add(f2fEqual);
						}
					}
				}
			}
		}
		myEffect.setM_predicate_list(l_predicate_list);
		myEffect.setM_f2f_list(l_f2f_list);
		myEffect.setM_function_operation_list(l_function_operation_list);
	}
}
