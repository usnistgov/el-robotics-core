#include <stdio.h>
#include <string.h>            // for strcmp
#include <string>            // for string
#include <stdlib.h>            // 
#include <set>

int main(int argc, char * argv[])
{
  FILE * file1;
  FILE * file2;
  char buffer[200];
  std::set<std::string> set1;
  std::set<std::string> set2;
  std::set<std::string>::iterator iter1;
  std::set<std::string>::iterator iter2;

  file1 = fopen(argv[1], "r");
  file2 = fopen(argv[2], "r");
  for (; fgets(buffer, 199, file1); )
    set1.insert(buffer);
  for (; fgets(buffer, 199, file2); )
    set2.insert(buffer);
  for (iter1 = set1.begin(), iter2 = set2.begin();
       ((iter1 != set1.end()) && (iter2 != set2.end()));
       iter1++, iter2++)
    if (strcmp((*iter1).c_str(), (*iter2).c_str()))
      {
	printf("%s%s", (*iter1).c_str(), (*iter2).c_str());
	return 1;
      }
  return 0;
}
